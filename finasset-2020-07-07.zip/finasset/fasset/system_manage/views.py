from fasset.system_manage import system_manage
from flask import render_template, request
from fasset.system_manage.SqlConfig import *
from utils.DbUtils import DbUtil
from sqlalchemy import text
from fasset import db
from utils.DataTypeEncoder import DecimalEncoder
from fasset.system_manage.models import FAS_ESCROW_BANK_INFO
import json



# 开户行信息维护界面
@system_manage.route("/escrow_bank_info",methods=['POST','GET'])
def escrow_bank_info():

    if request.method == 'GET':
        return render_template("system_manage/escrow_bank_info.html")


    # 界面初始化
    if request.method == 'POST':
        _json_ebcode = json.loads(request.get_data(as_text=True))  # 载入json对象
        _eb_code = _json_ebcode['eb_code']
        _pageSize = _json_ebcode['pageSize']  # 分页-数据
        _pageNumber = _json_ebcode['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)
        _sql_escrowebank_info_query = SQL_ESCROW_BANK_INFO_QUERY  # 产品信息查询sql
        _sql_count_query = SQL_ESCROW_BANK_INFO_COUNT_QUERY  # 产品信息数量count
        _sql_condition = ""

        # 拼接[托管行代码]参数条件
        if _eb_code == '%':
            _sql_condition = _sql_condition + ' where eb_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' where eb_code=:eb_code '

        # 分页SQL语句-详细信息
        _sql_prod_info_query_all = """select * from (select * from (""" \
                                   + _sql_escrowebank_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_count_query + _sql_condition

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_prod_info_query_all), {"eb_code": _eb_code})
            resulttotal = session.execute(text(_sql_count_query_all), {"eb_code": _eb_code})

        except Exception as e:
            print(e)

        _results_prod_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        resList = []
        # 将明细数压入List
        for _rpiq in _results_prod_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
            resList.append(rowDict_info)

        _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

        _result_json = json.dumps(_return_dict)

        print('----------------------------------------------最终查询返回的结果为：' + _result_json)

        return _result_json


# 删除开户行信息
@system_manage.route("/delete_ecrowe_bank_info",methods=['POST','GET'])
def delete_ecrowe_bank_info():

    if request.method == 'POST':

        _primary_key = json.loads(request.get_data(as_text=True))# 载入json对象
        _pk = _primary_key['primary_key']
        try:
            db.create_all()  # 创建数据库
            _obj = FAS_ESCROW_BANK_INFO.query.filter(FAS_ESCROW_BANK_INFO.eb_code == _pk).first()
            db.session.delete(_obj)
            db.session.commit()  # 提交到数据库 -->执行
            print('--------------------删除开户行信息成功'+_pk)
            return "200"
        except:
            db.session.rollback()  # 回滚数据  -->执行
            print('--------------------删除开户行信息失败' + _pk)
            return "300"


# 新增托管行信息
@system_manage.route("/add_escrow_bank_info",methods=['POST','GET'])
def add_escrow_bank_info():
    if request.method == 'GET':
        return render_template("system_manage/add_escrow_bank_info.html")

    if request.method == 'POST':
        _escrow_form = json.loads(request.get_data(as_text=True))  # 载入json对象
        _eb_code = _escrow_form['eb_code']
        _ebname = _escrow_form['ebname']
        _ebopen_name = _escrow_form['ebopen_name']
        _ebopen_mc = _escrow_form['ebopen_mc']
        _ebopen_no = _escrow_form['ebopen_no']
        _ebaraer = _escrow_form['ebaraer']

        items = _escrow_form.items()
        for key, value in items:
            print('-----前台传递过来的参数：' + str(key) + '=' + str(value))

        fas_escrow_bank_info = FAS_ESCROW_BANK_INFO(_eb_code, _ebname, _ebopen_name, _ebopen_mc, _ebopen_no, _ebaraer)

        # 创建数据库
        db.create_all()

        # 插入对象
        db.session.add(fas_escrow_bank_info)
        # 处理异常
        try:
            db.session.commit()  # 提交到数据库 -->执行
            return "托管行信息录入成功!"
        except Exception as e:
            db.session.rollback()  # 回滚数据  -->执行
            print(e)
            return "托管行信息录入失败!"


# 更新托管行信息
@system_manage.route("/update_escrow_bank_info",methods=['POST','GET'])
def update_escrow_bank_info():

    if request.method == 'GET':
        _pk = request.args.get("primary_key")
        _update_escrow_bank_sql = SQL_UPDATE_ESCROW_BANK_QUERY + ' and eb_code=:eb_code '

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_update_escrow_bank_sql), {"eb_code": _pk})

        except Exception as e:
            print(e)

        # 获取所有的数据，返回类型  RowProxy 数组（即列表），列表示例：[RowProxy-obj1,RowProxy-obj2,RowProxy-obj3,RowProxy-obj4.....]
        _results_details_info = resultproxy.fetchall()

        #开始迭代RowProxy数组，读取每一行RowProxy进行按字段加工。注：RowProxy.key() 提供所有 column_name 的数组，如：[colname1,colname2,colname3,.....]
        for _rt in _results_details_info:
            # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}
            _return_escrow_bank_dict = dict(zip(_rt.keys(),_rt))

        # dumps函数是将dict数据转化为str数据,但是dict数据中若包含byte数据、Decimal数据、date数据，就会导致json.dumps()转换为JSON格式对象时报错：
        # TypeError: Object of type Decimal is not JSON serializable
        # 新建一个DecimalEncoder类来格式化
        _result_json = json.dumps(_return_escrow_bank_dict,cls=DecimalEncoder)

        print('--------------------------------更新托管行信息返回数据为:' + _result_json)

        return render_template("system_manage/update_escrow_bank_info.html",_result_json = _result_json)


    if request.method == 'POST':
        _escrow_form = json.loads(request.get_data(as_text=True))  # 载入json对象
        _eb_code = _escrow_form['eb_code']
        _ebname = _escrow_form['ebname']
        _ebopen_name = _escrow_form['ebopen_name']
        _ebopen_mc = _escrow_form['ebopen_mc']
        _ebopen_no = _escrow_form['ebopen_no']
        _ebaraer = _escrow_form['ebaraer']

        FAS_ESCROW_BANK_INFO.query.filter(FAS_ESCROW_BANK_INFO.eb_code == _eb_code).update(
            {"eb_name": _ebname,
             "eb_open_bank_name": _ebopen_name,
             "eb_account_name": _ebopen_mc,
             "eb_account_no": _ebopen_no,
             "eb_area": _ebaraer})

        # 处理异常
        try:
            db.session.commit()  # 提交到数据库 -->执行
            return "更新成功!"
        except Exception as e:
            db.session.rollback()  # 回滚数据  -->执行
            print(e)
            return "更新失败!"










        return render_template("system_manage/update_escrow_bank_info.html")

















