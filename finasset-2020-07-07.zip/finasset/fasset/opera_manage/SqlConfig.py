


#1.档案信息查询SQL
SQL_ARCHIVES_INFO_QUERY = """
                select rownum as rowno,
                       t.pd_code, --产品代码
                       t.pd_name, --产品名称
                       t.pd_profit_type || '-' || a5.item_value as pd_profit_type,--收益特征
                       t.pd_fx_b_date,--成立日
                       t.pd_ov_date,--到期日
                       t2.pd_colect_money,--实际规模
                       t.pd_base_rate,--预期收益率
                       null as pd_asset_rate,--资产端收益率
                       null as pd_asset_tx,--资产投向
                       t3.eb_name, --托管行 
                       t1.archi_a, --划款通知单
                       t1.archi_b, --对账单
                       t1.archi_c, --起始运作书
                       t1.archi_d, --产品说明书
                       t1.archi_e, --认购/申请/补充协议
                       t1.archi_f, --资产底层表
                       t1.archi_g, --来账通知单
                       t1.archi_h  --来账对账凭证
                  from fas_prod_info t, --产品信息表
                       fas_prod_archives_info t1,--档案信息表
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_profit_type') a5,--收益特点
                       fas_prod_sale_info t2,  --产品销售信息表
                       fas_escrow_bank_info t3   --托管行信息表
                 where t.pd_code = t1.pd_code(+)
                   and t.pd_profit_type = a5.item_key(+)
                   and t.pd_code = t2.pd_code(+)
                   and t.jianguan_tuoguan_jnei_mc = t3.eb_code(+)
                          """


#2.档案信息查询-总数-分页用
SQL_ARCHIVES_INFO_COUNT_QUERY = """
                select count(1) as total
                  from fas_prod_info t, --产品信息表
                       fas_prod_archives_info t1,--档案信息表
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_profit_type') a5,--收益特点
                       fas_prod_sale_info t2,  --产品销售信息表
                       fas_escrow_bank_info t3   --托管行信息表
                 where t.pd_code = t1.pd_code(+)
                   and t.pd_profit_type = a5.item_key(+)
                   and t.pd_code = t2.pd_code(+)
                   and t.jianguan_tuoguan_jnei_mc = t3.eb_code(+)
                                """