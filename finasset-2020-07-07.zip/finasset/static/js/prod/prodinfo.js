//配置formatter
function myformatter(date) {
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    var d = date.getDate();
    return y + '' + (m < 10 ? ('0' + m) : m) + '' + (d < 10 ? ('0' + d) : d);
}

//配置parser，返回选择的日期
function myparser(s) {
    if (!s) {
        return new Date();
    }
    var ss = (s.split(''));
    var y = parseInt(ss[0], 10);
    var m = parseInt(ss[1], 10);
    var d = parseInt(ss[2], 10);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
        new Date(y, m - 1, d);
    } else {
        return new Date();
    }
}


/*ajax获得下拉框组件数据*/
/*
*var sdata = [
*    {id: 1, text:'OPS-COFFEE-1'},
*    {id: 2, text:'OPS-COFFEE-2'},
*    {id: 3, text:'OPS-COFFEE-3'}
*   ]
* 使用select2组件，select2能够加载的数据格式如上，需要两个数据属性id和text
*
* */
function get_sel_data(id,dict_code) {
    //清空select框中数据
   $('#'+id+'').empty();
   $.ajax({
       url: "/prod_manage/get_sel_data",
       type: "get",
       data:{'dict_code':dict_code},//发送到服务器的数据。
       dataType: "json",//预期服务器返回的数据类型。
       success: function (json) {
            $('#'+id+'').select2({
                data : json,
                minimumResultsForSearch:-1,//设置支持搜索的最小集合，设置为负数，隐藏搜索框
                allowClear:true,//设置allowClear为true，将会在select后加一个X号，可用于快速清空已选项
                placeholder:''
           });
       },
       error: function () {
           alert("获取下拉框数据失败");
       }
   });

}


/*ajax-post表单数据*/
function commit_product_info() {

    var _prod_form = new Map();
    //产品模式
    var _prod_mode = $('#prod_mode').val();
    if(_prod_mode == null || _prod_mode == ''){
        $.messager.alert({title:"错误提示",msg:"产品模式为必选项",icon:"warning"});
        return;
    }else{
        _prod_form.set('prod_mode',_prod_mode);
    }

    //产品代码
    var _prod_code = $('#prod_code').val();
    if(_prod_code == null || _prod_code == ''){
        $.messager.alert({title:"错误提示",msg:"产品代码为必输项",icon:"warning"});
        return;
    }else{
        _prod_form.set('prod_code',_prod_code);
    }
    //中债编码
    var _zz_code = $('#zz_code').val();
    if(_zz_code == null || _zz_code == ''){
        $.messager.alert({title:"错误提示",msg:"中债登编码为必输项",icon:"warning"});
        return;
    }else{
        _prod_form.set('zz_code',_zz_code);
    }
    //产品名称
    var _prod_name = $('#prod_name').val();
    if(_prod_name == null || _prod_name == ''){
        $.messager.alert({title:"错误提示",msg:"产品名称为必输项",icon:"warning"});
        return;
    }else{
        _prod_form.set('prod_name',_prod_name);
    }
    //产品类型 - 若为空置为空字符串
    _prod_form.set('prod_type', $('#prod_type').val()==null || $('#prod_type').val() == ''?'':$('#prod_type').val());
    //募集币种 - 若为空置为空字符串
    _prod_form.set('collect_bz', $('#collect_bz').val()==null || $('#collect_bz').val() == ''?'':$('#collect_bz').val());
    //风险等级 - 若为空置为空字符串
    _prod_form.set('fx_dj', $('#fx_dj').val()==null || $('#fx_dj').val() == ''?'':$('#fx_dj').val());

    _prod_form.set('sy_td',$('#sy_td').val()==null || $('#sy_td').val() == ''?'':$('#sy_td').val());
    _prod_form.set('hs_fs',$('#hs_fs').val()==null || $('#hs_fs').val() == ''?'':$('#hs_fs').val());
    _prod_form.set('jx_js',$('#jx_js').val()==null || $('#jx_js').val() == ''?'':$('#jx_js').val());
    _prod_form.set('prod_life_statu',$('#prod_life_statu').val()==null || $('#prod_life_statu').val() == ''?'':$('#prod_life_statu').val());
    _prod_form.set('rg_b_date',$('#rg_b_date').val()==null || $('#rg_b_date').val() == ''?'':$('#rg_b_date').val());
    _prod_form.set('rg_o_date',$('#rg_o_date').val()==null || $('#rg_o_date').val() == ''?'':$('#rg_o_date').val());
    _prod_form.set('fx_b_date',$('#fx_b_date').val()==null || $('#fx_b_date').val() == ''?'':$('#fx_b_date').val());
    _prod_form.set('sy_b_date',$('#sy_b_date').val()==null || $('#sy_b_date').val() == ''?'':$('#sy_b_date').val());
    _prod_form.set('open_b_date',$('#open_b_date').val()==null || $('#open_b_date').val() == ''?'':$('#open_b_date').val());
    _prod_form.set('open_o_date',$('#open_o_date').val()==null || $('#open_o_date').val() == ''?'':$('#open_o_date').val());
    _prod_form.set('prod_o_date',$('#prod_o_date').val()==null || $('#prod_o_date').val() == ''?'':$('#prod_o_date').val());
    _prod_form.set('prod_df_date',$('#prod_df_date').val()==null || $('#prod_df_date').val() == ''?'':$('#prod_df_date').val());
    _prod_form.set('pd_verify_person',$('#pd_verify_person').val()==null || $('#pd_verify_person').val() == ''?'':$('#pd_verify_person').val());
    _prod_form.set('spr_zj',$('#spr_zj').val()==null || $('#spr_zj').val() == ''?'':$('#spr_zj').val());
    _prod_form.set('pd_desiner_name',$('#pd_desiner_name').val()==null || $('#pd_desiner_name').val() == ''?'':$('#pd_desiner_name').val());
    _prod_form.set('design_zj',$('#design_zj').val()==null || $('#design_zj').val() == ''?'':$('#design_zj').val());
    _prod_form.set('investmanage_name',$('#investmanage_name').val()==null || $('#investmanage_name').val() == ''?'':$('#investmanage_name').val());
    _prod_form.set('investmanage_zj',$('#investmanage_zj').val()==null || $('#investmanage_zj').val() == ''?'':$('#investmanage_zj').val());
    _prod_form.set('ywry_name',$('#ywry_name').val()==null || $('#ywry_name').val() == ''?'':$('#ywry_name').val());
    _prod_form.set('ywry_zj_phone',$('#ywry_zj_phone').val()==null || $('#ywry_zj_phone').val() == ''?'':$('#ywry_zj_phone').val());
    _prod_form.set('ywry_yd_phone',$('#ywry_yd_phone').val()==null || $('#ywry_yd_phone').val() == ''?'':$('#ywry_yd_phone').val());
    _prod_form.set('ywry_mail',$('#ywry_mail').val()==null || $('#ywry_mail').val() == ''?'':$('#ywry_mail').val());
    _prod_form.set('zj_tx',$('#zj_tx').val()==null || $('#zj_tx').val() == ''?'':$('#zj_tx').val());
    _prod_form.set('lc_fw_type',$('#lc_fw_type').val()==null || $('#lc_fw_type').val() == ''?'':$('#lc_fw_type').val());
    _prod_form.set('prod_manager_mode',$('#prod_manager_mode').val()==null || $('#prod_manager_mode').val() == ''?'':$('#prod_manager_mode').val());
    _prod_form.set('invest_pz_type',$('#invest_pz_type').val()==null || $('#invest_pz_type').val() == ''?'':$('#invest_pz_type').val());
    _prod_form.set('dj_fs',$('#dj_fs').val()==null || $('#dj_fs').val() == ''?'':$('#dj_fs').val());
    _prod_form.set('tz_zc_type',$('#tz_zc_type').val()==null || $('#tz_zc_type').val() == ''?'':$('#tz_zc_type').val());
    _prod_form.set('hezuo_mode',$('#hezuo_mode').val()==null || $('#hezuo_mode').val() == ''?'':$('#hezuo_mode').val());
    _prod_form.set('prod_zengxin_flag',$('#prod_zengxin_flag').val()==null || $('#prod_zengxin_flag').val() == ''?'':$('#prod_zengxin_flag').val());
    _prod_form.set('prod_zengxin_comp',$('#prod_zengxin_comp').val()==null || $('#prod_zengxin_comp').val() == ''?'':$('#prod_zengxin_comp').val());
    _prod_form.set('prod_zengxin_xingshi',$('#prod_zengxin_xingshi').val()==null || $('#prod_zengxin_xingshi').val() == ''?'':$('#prod_zengxin_xingshi').val());
    _prod_form.set('prod_pingpai',$('#prod_pingpai').val()==null || $('#prod_pingpai').val() == ''?'':$('#prod_pingpai').val());
    _prod_form.set('prod_qishu',$('#prod_qishu').val()==null || $('#prod_qishu').val() == ''?'':$('#prod_qishu').val());
    _prod_form.set('sale_channel_dif',$('#sale_channel_dif').val()==null || $('#sale_channel_dif').val() == ''?'':$('#sale_channel_dif').val());
    _prod_form.set('touzi_zhonglei_bili',$('#touzi_zhonglei_bili').val()==null || $('#touzi_zhonglei_bili').val() == ''?'':$('#touzi_zhonglei_bili').val());
    _prod_form.set('jianguan_guanli_fs',$('#jianguan_guanli_fs').val()==null || $('#jianguan_guanli_fs').val() == ''?'':$('#jianguan_guanli_fs').val());
    _prod_form.set('jianguan_muji_fs',$('#jianguan_muji_fs').val()==null || $('#jianguan_muji_fs').val() == ''?'':$('#jianguan_muji_fs').val());
    _prod_form.set('jianguan_kuaijihesuan_fs',$('#jianguan_kuaijihesuan_fs').val()==null || $('#jianguan_kuaijihesuan_fs').val() == ''?'':$('#jianguan_kuaijihesuan_fs').val());
    _prod_form.set('jianguan_shouyi_bz',$('#jianguan_shouyi_bz').val()==null || $('#jianguan_shouyi_bz').val() == ''?'':$('#jianguan_shouyi_bz').val());
    _prod_form.set('jianguan_benjinbz_bz',$('#jianguan_benjinbz_bz').val()==null || $('#jianguan_benjinbz_bz').val() == ''?'':$('#jianguan_benjinbz_bz').val());
    _prod_form.set('jianguan_tiqianzhongzhi_bz',$('#jianguan_tiqianzhongzhi_bz').val()==null || $('#jianguan_tiqianzhongzhi_bz').val() == ''?'':$('#jianguan_tiqianzhongzhi_bz').val());
    _prod_form.set('jianguan_shuhui_bz',$('#jianguan_shuhui_bz').val()==null || $('#jianguan_shuhui_bz').val() == ''?'':$('#jianguan_shuhui_bz').val());
    _prod_form.set('jianguan_tuoguan_jwai_daima',$('#jianguan_tuoguan_jwai_daima').val()==null || $('#jianguan_tuoguan_jwai_daima').val() == ''?'':$('#jianguan_tuoguan_jwai_daima').val());
    _prod_form.set('jianguan_tuoguan_jnei_mc',$('#jianguan_tuoguan_jnei_mc').val()==null || $('#jianguan_tuoguan_jnei_mc').val() == ''?'':$('#jianguan_tuoguan_jnei_mc').val());
    _prod_form.set('jianguan_tuoguan_jwai_gb',$('#jianguan_tuoguan_jwai_gb').val()==null || $('#jianguan_tuoguan_jwai_gb').val() == ''?'':$('#jianguan_tuoguan_jwai_gb').val());
    _prod_form.set('jianguan_tuoguan_jwai_mc',$('#jianguan_tuoguan_jwai_mc').val()==null || $('#jianguan_tuoguan_jwai_mc').val() == ''?'':$('#jianguan_tuoguan_jwai_mc').val());

    //2020-06-30新增13个字段
    _prod_form.set('pd_cpqx',$('#pd_cpqx').val()==null || $('#pd_cpqx').val() == ''?'':$('#pd_cpqx').val());
    _prod_form.set('pd_tongyezs',$('#pd_tongyezs').val()==null || $('#pd_tongyezs').val() == ''?'':$('#pd_tongyezs').val());
    _prod_form.set('pd_setholdtime',$('#pd_setholdtime').val()==null || $('#pd_setholdtime').val() == ''?'':$('#pd_setholdtime').val());
    _prod_form.set('pd_holddate',$('#pd_holddate').val()==null || $('#pd_holddate').val() == ''?0:$('#pd_holddate').val());
    _prod_form.set('pd_tzshouy_dzr',$('#pd_tzshouy_dzr').val()==null || $('#pd_tzshouy_dzr').val() == ''?'':$('#pd_tzshouy_dzr').val());
    _prod_form.set('pd_xjmanagertype',$('#pd_xjmanagertype').val()==null || $('#pd_xjmanagertype').val() == ''?'':$('#pd_xjmanagertype').val());
    _prod_form.set('pd_beginsalemoney',$('#pd_beginsalemoney').val()==null || $('#pd_beginsalemoney').val() == ''?0.00:$('#pd_beginsalemoney').val());
    _prod_form.set('pd_salerate',$('#pd_salerate').val()==null || $('#pd_salerate').val() == ''?0.00:$('#pd_salerate').val());
    _prod_form.set('pd_tuoguangrate',$('#pd_tuoguangrate').val()==null || $('#pd_tuoguangrate').val() == ''?0.00:$('#pd_tuoguangrate').val());
    _prod_form.set('pd_plancolectmoney',$('#pd_plancolectmoney').val()==null || $('#pd_plancolectmoney').val() == ''?0.00:$('#pd_plancolectmoney').val());
    _prod_form.set('pd_investmanagerate',$('#pd_investmanagerate').val()==null || $('#pd_investmanagerate').val() == ''?0.00:$('#pd_investmanagerate').val());
    _prod_form.set('pd_tzbenjin_dzr',$('#pd_tzbenjin_dzr').val()==null || $('#pd_tzbenjin_dzr').val() == ''?'':$('#pd_tzbenjin_dzr').val());
    _prod_form.set('pd_freeback',$('#pd_freeback').val()==null || $('#pd_freeback').val() == ''?'':$('#pd_freeback').val());

    //2020-07-3新增1个字段
    _prod_form.set('pd_base_rate',$('#pd_base_rate').val()==null || $('#pd_base_rate').val() == ''?0.00:$('#pd_base_rate').val());


    let obj = Object.create(null);
    for (let[k,v] of _prod_form) {
        obj[k] = v;
    }

   $.post({
        'url': '/prod_manage/commit_product_info',
        'data':JSON.stringify(obj),
        'success':function (result){
            $.messager.alert({title:"result",msg:result,icon:"info"});
            $("#product_form")[0].reset();//保存成功后重置界面
            },
        'fail':function(error){
           $.messager.alert({title:"result",msg:error,icon:"warning"});
        }
    })

}





