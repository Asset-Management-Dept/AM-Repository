

/*页面初始化,增加首页标签*/
$(function () {
    var content = '<iframe scrolling="auto" frameborder="0"  src="/mypage" style="width:100%;height:740px;"></iframe>';
    $('#maintab').tabs('add', {
        title: '首页',
        content: content,
        closable: false
    });
});


/*增加标签页*/
function addTab(title, url) {

    if ($('#maintab').tabs('exists', title)) {
        $('#maintab').tabs('select', title);
    } else {
        var content = '<iframe scrolling="auto" frameborder="0"  src="' + url + '" style="width:100%;height:810px;"></iframe>';
        $('#maintab').tabs('add', {
            title: title,
            content: content,
            closable: true
        });
    }
}