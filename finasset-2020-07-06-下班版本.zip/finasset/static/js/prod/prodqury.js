
//配置formatter
function myformatter(date) {
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    var d = date.getDate();
    return y + '' + (m < 10 ? ('0' + m) : m) + '' + (d < 10 ? ('0' + d) : d);
}


//配置parser，返回选择的日期
function myparser(s) {
    if (!s) {
        return new Date();
    }
    var ss = (s.split(''));
    var y = parseInt(ss[0], 10);
    var m = parseInt(ss[1], 10);
    var d = parseInt(ss[2], 10);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
        new Date(y, m - 1, d);
    } else {
        return new Date();
    }
}


/*ajax获得产品信息*/
$(function() {$("#prod-query-btn").click(function(event){
        event.preventDefault();
		var _pageNumber = 1;
		var _pageSize =  10;
		var _query_json = get_json_value(_pageSize,_pageNumber);
        $.post({
            'url': '/prod_manage/prodqury_result',
            'data':_query_json,/*{'prod_code':_prod_code, 'prod_life_statu':_prod_life_statu, 'pageNumber':_pageNumber, 'pageSize':_pageSize},*/
            //远程请求数据成功
            'success':function (_data) {

                var result_json = $.parseJSON(_data); //先将返回来的json字符串转化为json对象
                $("#dd").datagrid({data:result_json});
                var pager = $("#dd").datagrid("getPager");
                pager.pagination({
                    //当用户选择新的页面时触发
                    onSelectPage:function (pageNo, pageSize) {
                        var _query_json = get_json_value(pageSize,pageNo);
                        //重新远程请求数据载入数据
                        $.post({
                            'url': '/prod_manage/prodqury_result',
                            'data':_query_json, //{'prod_code':_prod_code, 'prod_life_statu':_prod_life_statu, 'pageNumber':pageNo, 'pageSize':pageSize},
                            'success':function (_data) {
                                var next_page_data = $.parseJSON(_data);
                                $("#dd").datagrid("loadData", next_page_data);
                                },
                            'fail':function(error){ alert(error); }
                        });
                    }
                });
              },
            'fail':function(error){ alert(error); }
        })
    })
});


/*右键弹出菜单:编辑、查看、删除*/
$(function(){
$('#dd').datagrid({
    onRowContextMenu: function(e, rowIndex, rowData){
        e.preventDefault(); //阻止浏览器捕获右键事件
        $(this).datagrid("clearSelections"); //取消所有选中项
        $(this).datagrid("selectRow", rowIndex); //根据索引选中该行
        $('#menu').menu('show', {left: e.pageX, top: e.pageY});
        //给右键菜单增加click事件响应
        $('#menu').menu({onClick:function(item){
            if(item.name == 'query'){
                get_product_details(rowData.pd_code,rowIndex);
            }
            if (item.name == 'modify'){
                Modif_product_info(rowData.pd_code,rowIndex);
            }
            if (item.name == 'delete'){
                del_product_info(rowData.pd_code,rowIndex);
            }
            if (item.name == 'export'){
                export_product_info(rowData.pd_code,rowIndex);
            }
         }
        });
        e.preventDefault(); //阻止浏览器自带的右键菜单弹出
      }
  });
});



/*查看产品详细信息*/
function get_product_details(primary_key,rowIndex) {
    var content = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_details_info?primary_key=' + primary_key + '" style="width:100%;height:600px;"></iframe>';
    $('#win').window({
        title:"【查看】产品详细信息",
        width:'100%',
        height:'auto',
        modal:true,
        content:content
    });

}


/*删除产品信息*/
function del_product_info(primary_key,rowIndex) {

    $.messager.confirm('Confirm','确认要删除吗?',function(r){
        //点击确实时执行
        if (r){
            var jsonstr = {'primary_key':primary_key};
            $.post({
                'url': '/prod_manage/delete_product_info',
                'data':JSON.stringify(jsonstr),
                'success':function (_data) {
                    if(_data == '200'){
                        $("#dd").datagrid("deleteRow", rowIndex);
                        $.messager.alert({title:"result",msg:'删除成功!',icon:"info"});
                    }
                 },
                'fail':function(error){
                    alert(error);}
            })
        }
    });
}



/*修改产品信息*/
function Modif_product_info(primary_key,rowIndex) {
    var content = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_update_info?primary_key=' + primary_key + '" style="width:100%;height:600px;"></iframe>';
    $('#win').window({
        title:"【更新】产品信息",
        width:'100%',
        height:'auto',
        modal:true,
        content:content,
        onClose:function () {
            //do nothing
        }
    });

}


/*导出产品信息*/
function export_product_info(primary_key,rowIndex) {
    var jsonstr = {'primary_key':primary_key};
    $.get({
        'url': '/prod_manage/export_product_info',
        'data':jsonstr,//JSON.stringify(jsonstr),
        'success':function (_data) {
            alert(_data);
            },
        'fail':function(error){
                    alert(error);}
    })

}



/*获得控件的值*/
function get_json_value(_pageSize,_pageNumber) {

    var _query_condition = new Map();
    _query_condition.set('pageSize',_pageSize);
    _query_condition.set('pageNumber',_pageNumber);

    //产品代码
    var _prod_code = $('input[name="prod_code"]').val();
    if(_prod_code == null || _prod_code == ''){
        _query_condition.set('prod_code','%');
    }else{
        _query_condition.set('prod_code',_prod_code);
    }

    //产品模式
    var _prod_mode = $("#prod_mode").val();
    if(_prod_mode == null || _prod_mode == ''){
        _query_condition.set('prod_mode','%');
    }else{
        _query_condition.set('prod_mode',_prod_mode);
    }

    //募集方式
    var _jianguan_muji_fs = $("#jianguan_muji_fs").val();
    if(_jianguan_muji_fs == null || _jianguan_muji_fs == ''){
        _query_condition.set('jianguan_muji_fs','%');
    }else{
        _query_condition.set('jianguan_muji_fs',_jianguan_muji_fs);
    }

    //发行成立日期
    var _fx_b_date = $('input[name="fx_b_date"]').val();
    if(_fx_b_date == null || _fx_b_date == ''){
        _query_condition.set('fx_b_date','%');
    }else{
        _query_condition.set('fx_b_date',_fx_b_date);
    }

    let obj = Object.create(null);
    for (let[k,v] of _query_condition) {
        obj[k] = v;
    }

    var _query_json = JSON.stringify(obj);

    return _query_json;

}



/*
var pager = $("#dd").datagrid("getPager");
pager.pagination({
    //total:result_json.length,
    //当用户选择新的页面时触发
    onSelectPage:function (pageNo, pageSize) {
        alert('pageNumber:'+pageNo+',pageSize:'+pageSize);
        /*
        var start = (pageNo - 1) * pageSize;
        var end = start + pageSize;
        //重新远程请求数据载入数据
        //$("#dd").datagrid("loadData", result_json.slice(start, end));
        // 改变选项，并刷新分页栏信息
        pager.pagination('refresh', {
            total:result_json.length,
            pageNumber:pageNo
        });


    }
});

*/


/* history code
$(function(){
    $('#pp').pagination({
	onSelectPage:function(pageNumber, pageSize){
		//$(this).pagination('loading');
		alert('pageNumber:'+pageNumber+',pageSize:'+pageSize);
		//$(this).pagination('loaded');
	}
});
});


function operate_formatter(value, row, index) {
    return "<a href='#' class='easyui-linkbutton' onclick=\"javascript:alert(row.pd_code)\">编辑</a>   <a href='#' class='easyui-linkbutton'>查看</a>   <a href='#' class='easyui-linkbutton'>删除</a>";
}


        <th data-options="field:'operate',width:'15%',align:'center',formatter:operate_formatter">操作</th>

$(function(){
        $("#prod-query-btn").click(function(event){
        event.preventDefault();
		var _pageNumber = 1;
		var _pageSize =  10;
		var _prod_code = $('input[name="prod_code"]').val();
		var _prod_life_statu = $("#prod_life_statu").val();
		//ajax远程请求数据开始
        $.get({
            'url': '/prod_manage/prodqury_result',
            'data':{'prod_code':_prod_code, 'prod_life_statu':_prod_life_statu, 'pageNumber':_pageNumber, 'pageSize':_pageSize},
            //远程请求数据成功
            'success':function (_data) {
                var result_json = $.parseJSON(_data); //先将返回来的json字符串转化为json对象
                $("#dd").datagrid({
                    title:"产品信息",
                    rownumbers:true,
                    fitColumns:true,
                    pagination:true,
                    data:result_json,
                    columns:[[
                        {field:'pd_code',width:100,align:'center', title:"产品代码"},
                        {field:'pd_name',width:100,align:'center', title:"产品名称"},
                        {field:'pd_mode',width:100,align:'center', title:"产品模式"},
                        {field:'pd_zz_code',width:100,align:'center', title:"中债编码"},
                        {field:'pd_rg_bg_date',width:100,align:'center', title:"认购开始日期"},
                        {field:'pd_fx_b_date',width:100,align:'center', title:"发行成立日期"},
                        {field:'pd_life_statu',width:100,align:'center', title:"产品生命状态"},
                    ]]
                });
              },
            //远程请求数据失败
            'fail':function(error){
                alert(error);
            }
        })
       //ajax远程请求数据结束
      })
});

 */