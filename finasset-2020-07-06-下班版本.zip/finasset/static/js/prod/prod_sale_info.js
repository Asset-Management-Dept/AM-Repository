

// 全局变量
var editIndex = undefined;

function endEditing() {
    if (editIndex == undefined) {
        return true
    }
    //validateRow:验证指定的行，有效时返回 true : 验证所选定的行索引是否是前面所编辑的行??
    if ($('#dd').datagrid('validateRow', editIndex)) {
        //return true;
    } else {
        return false;
    }
}


/*点击行时触发*/
function onClickRow(index) {

    if (editIndex != index) {
        if (endEditing()) {
            $('#dd').datagrid('selectRow', index).datagrid('beginEdit', index); //selectRow:选中一行，行索引从 0 开始, beginEdit:开始对一行进行编辑。
            editIndex = index;//赋值给 editIndex , 表示正在编辑的行索引
        } else {
            $.messager.alert({title:"错误提示",msg:"请先点击保存按钮后再编辑下一行!",icon:"warning"});
            $('#dd').datagrid('selectRow', editIndex).datagrid('beginEdit', editIndex);
        }
    }
}


/*保存*/
function accept() {

    if (editIndex == undefined) {
        $.messager.alert({title: "错误提示", msg: "未检测到输入!", icon: "warning"});
    } else {
        $('#dd').datagrid('endEdit', editIndex); //结束行的编辑
        var rows = $('#dd').datagrid('getChanges');//获取最后一次提交以来更改的行
        var _pd_colect_money = Number(rows[0].pd_colect_money);
        var _pd_person_a = Number(rows[0].pd_person_a);
        var _pd_person_b = Number(rows[0].pd_person_b);
        var _pd_person_c = Number(rows[0].pd_person_c);
        var _pd_copr_a = Number(rows[0].pd_copr_a);
        var _pd_copr_b = Number(rows[0].pd_copr_b);
        var _pd_copr_c = Number(rows[0].pd_copr_c);
        var _pd_code = rows[0].pd_code;
        var _pd_done_flag = rows[0].pd_done_flag;

        if ((_pd_person_a + _pd_person_b + _pd_person_c + _pd_copr_a + _pd_copr_b + _pd_copr_c) == _pd_colect_money) {

            var _post_json_data = {
                "pd_code": _pd_code,
                "pd_colect_money": _pd_colect_money,
                "pd_person_a": _pd_person_a,
                "pd_person_b": _pd_person_b,
                "pd_person_c": _pd_person_c,
                "pd_copr_a": _pd_copr_a,
                "pd_copr_b": _pd_copr_b,
                "pd_copr_c": _pd_copr_c,
                "pd_done_flag":_pd_done_flag
            };
            $.post({
                'url': '/prod_manage/save_product_sale_info',
                'data': JSON.stringify(_post_json_data),
                'success': function (result) {
                    if(result == '200'){
                        alert("保存成功!");
                    }
                    if(result == '400'){
                        alert("更新成功!");
                    }
                    $('#dd').datagrid('acceptChanges');//提交自从被加载以来或最后一次调用 acceptChanges 以来所有更改的数据。
                    editIndex = undefined;
                },
                'fail': function (error) {
                    $.messager.alert({title: "result", msg: error, icon: "warning"});
                }
            });
        } else {
            $.messager.alert({title: "错误提示", msg: "各投资者金额相加不等于募集金额!", icon: "warning"});
            $('#dd').datagrid('selectRow', editIndex).datagrid('beginEdit', editIndex);
        }
    }
}


//var rows = $('#dd').datagrid('getChanges',type='updated');
//alert(rows.length+' rows are changed!');




/*初始载入页面加载数据*/
$(function () {
    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/prod_manage/prod_sale_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/prod_manage/prod_sale_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
});


/*获得控件的值*/
function get_json_value(_pageSize, _pageNumber) {

    var _query_condition = new Map();
    var _pd_code = $('#pd_code').val() == null || $('#pd_code').val() == '' ? '%' : $('#pd_code').val();

    _query_condition.set('pageSize', _pageSize);
    _query_condition.set('pageNumber', _pageNumber);
    _query_condition.set('pd_code', _pd_code);

    let obj = Object.create(null);
    for (let [k, v] of _query_condition) {
        obj[k] = v;
    }

    var _query_json = JSON.stringify(obj);

    return _query_json;

}


/*单笔查询*/
function search_product_info() {
    editIndex = undefined;
    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/prod_manage/prod_sale_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/prod_manage/prod_sale_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
}


