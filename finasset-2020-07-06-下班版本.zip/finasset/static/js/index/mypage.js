/*界面初始化*/
$(function () {
    $.post({
        'url': '/mypage',
        'data': {"prama": "nothing"},
        'success': function (_data) {
            var _returndata = $.parseJSON(_data);
            var arraydata = [];
            for (var i in _returndata) {
                arraydata.push(_returndata[i]);
            }
            var myChart = echarts.init(document.getElementById('area_one'));

            var dateList = arraydata.map(function (item) {
                return item[0];
            });
            var valueList = arraydata.map(function (item) {
                return item[1];
            });

            option = {
                // Make gradient line here
                visualMap: [{
                    show: false,
                    type: 'continuous',
                    seriesIndex: 0,
                    min: 0,
                    max: 400
                }],
                title: [{
                    left: 'center',
                    text: '理财产品发行折线图'
                }],
                tooltip: {
                    trigger: 'axis'
                },
                xAxis: [{
                    data: dateList,
                    name: '日期(月份)'
                }],
                yAxis: [{
                    splitLine: {show: false},
                    name: '月发行量'
                }],
                grid: [{
                    bottom: '10%',
                    right: '15%'
                }],
                series: [{
                    type: 'line',
                    showSymbol: false,
                    data: valueList
                }],
                lineStyle: {
                    color: '#ff9e5e'
                }
            };
            myChart.setOption(option);
        },
        'fail': function (error) {
            alert(error);
        }
    })
});


var myChart2 = echarts.init(document.getElementById('area_two'));
arear_two = {
    backgroundColor: '#fff',

    title: {
        text: '产品规模统计',
        left: 'center',
        top: 20,
        textStyle: {
            color: '#000'
        }
    },

    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
    },

    visualMap: {
        show: false,
        min: 80,
        max: 600,
        inRange: {
            colorLightness: [0, 1]
        }
    },
    series: [
        {
            type: 'pie',
            radius: '55%',
            center: ['50%', '50%'],
            data: [
                {value: 335, name: '个人普通客户'},
                {value: 310, name: '高净值客户'},
                {value: 274, name: '私人银行客户'},
                {value: 235, name: '同业客户'},
                {value: 400, name: '机构客户'}
            ].sort(function (a, b) {
                return a.value - b.value;
            }),
            roseType: 'radius',
            label: {
                color: 'rgba(255, 255, 255, 0.3)'
            },
            labelLine: {
                lineStyle: {
                    color: 'rgba(255, 255, 255, 0.3)'
                },
                smooth: 0.2,
                length: 10,
                length2: 20
            },
            itemStyle: {
                color: '#c23531',
                shadowBlur: 200,
                shadowColor: '#fff'
            },
            label: {
                show: true, //开启显示
                position: 'top', //在上方显示
                textStyle: { //数值样式
                    color: '#ff9e5e',
                    fontSize: 12,
                    fontWeight: 300
                }
            },

            animationType: 'scale',
            animationEasing: 'elasticOut',
            animationDelay: function (idx) {
                return Math.random() * 200;
            }
        }
    ]
};

myChart2.setOption(arear_two);


var myChart3 = echarts.init(document.getElementById('area_three'));

area_three = {
    title: {
        text: '产品期限统计',
        left: 'center',
        top: 20,
        textStyle: {
            color: '#000'
        }
    },
    xAxis: {
        type: 'category',
        data: ['7天-1个月(含)', '1-3个月(含)', '3-6个月(含)', '6-12个月(含)', '1-3年(含)']
    },
    yAxis: {
        type: 'value'
    },
    label: {
        show: true, //开启显示
        position: 'top', //在上方显示
        textStyle: { //数值样式
            color: 'black',
            fontSize: 16,
            fontWeight: 600
        }
    },
    series: [{
        data: [13, 187, 138, 56, 1],
        type: 'bar',
        showBackground: true,
        backgroundStyle: {
            color: 'rgba(220, 220, 220, 0.8)'
        }
    }]
};

myChart3.setOption(area_three);


var myChart4 = echarts.init(document.getElementById('area_four'));

area_four = {
    tooltip: {
        formatter: '{a} <br/>{b} : {c}%'
    }, title: {
        text: '中间业务收入完成率',
        left: 'center',
        top: 5,
        textStyle: {
            color: '#000'
        }
    }, grid: [{
        bottom: '2%',
        right: '15%'
    }],
    series: [
        {
            name: '',
            type: 'gauge',
            detail: {formatter: '{value}%'},
            data: [{value: 77, name: '指标完成率'}]
        }
    ]
};

myChart4.setOption(area_four);








