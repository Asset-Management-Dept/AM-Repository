



#1.托管行信息-分页用
SQL_ESCROW_BANK_INFO_QUERY = """ 
                    select rownum as rowno,
                           t.eb_code, 
                           t.eb_name, 
                           t.eb_open_bank_name, 
                           t.eb_account_name, 
                           t.eb_account_no, 
                           t.eb_area 
                     from fas_escrow_bank_info t 
                            """



#2.托管行信息总数-分页用
SQL_ESCROW_BANK_INFO_COUNT_QUERY = """  select count(1) as total from fas_escrow_bank_info t  """


#3.更新托管行信息
SQL_UPDATE_ESCROW_BANK_QUERY = """ 
                    select rownum as rowno,
                           t.eb_code, 
                           t.eb_name, 
                           t.eb_open_bank_name, 
                           t.eb_account_name, 
                           t.eb_account_no, 
                           t.eb_area 
                     from fas_escrow_bank_info t where 1 = 1
                            """


#4.交易对手信息
SQL_TRADE_OPPONENTS_INFO_QUERY = """
                    select rownum as rowno,
                           t.trade_opponents_code,
                           t.trade_opponents_name,
                           t.trade_opponents_type || '-' || t1.item_value as trade_opponents_type,
                           t.trade_opponents_account_no,
                           t.trade_opponents_account_name,
                           t.trade_opponents_bank_no
                     from fas_trade_opponents_info t,
                          (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'trade_opponents_type') t1 --机构类型
                     where t.trade_opponents_type = t1.item_key(+)
                                 """



#5.交易对手信息总数-分页用
SQL_TRADE_OPPONENTS_INFO_COUNT = """
                    select count(1) as total
                     from fas_trade_opponents_info t,
                          (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'trade_opponents_type') t1 --机构类型
                     where t.trade_opponents_type = t1.item_key(+)
                                """




#6.更新交易对手信息
SQL_UPDATE_TRADE_OPPONENTS_INFO_QUERY = """ 
                    select rownum as rowno,
                           t.trade_opponents_code, 
                           t.trade_opponents_name, 
                           t.trade_opponents_type, 
                           t.trade_opponents_account_no, 
                           t.trade_opponents_account_name, 
                           t.trade_opponents_bank_no 
                     from fas_trade_opponents_info t where 1 = 1
                            """




#7.用户信息
SQL_USER_MANAGE_INFO_QUERY = """ 
                    select rownum as rowno, 
                           t.user_id,
                           t.user_name    
                    from (select t.user_id, t.user_name from fas_users t order by t.user_id desc) t
                   where 1 = 1
                             """


#8.用户信息总数-分页用
SQL_USER_MANAGE_INFO_COUNT_QUERY = """
                   select count(1) as total from fas_users t where 1 = 1
                                   """