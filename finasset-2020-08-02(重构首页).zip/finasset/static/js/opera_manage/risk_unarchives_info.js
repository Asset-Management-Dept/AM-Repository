


/*初始化*/
$(function () {
    var _key = $('#flag').val();
    init_archives_risk_details(_key);//初始化档案风险预警
});


//初始化档案风险预警
function init_archives_risk_details(_key) {

    layui.use('table', function () {
        var table = layui.table;
        table.render({
            elem: '#test',
            toolbar: true,
            defaultToolbar: ['filter', 'exports', 'print'],
            url: '/opera_manage/risk_unarchives_info',
            where: {flag: _key},
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 25, title: '', fixed: 'left', align: 'center'}
                , {field: 'archives_pk_id', width: 130, align: 'center', fixed: 'left', title: '档案ID', hide: true}
                , {field: 'pd_code', width: 130, align: 'center', fixed: 'left', title: '产品代码'}
                , {field: 'pd_name', width: 200, align: 'left', fixed: 'left', title: '产品名称'}
                , {field: 'pd_profit_type', width: 150, align: 'center', title: '收益特征'}
                , {field: 'pd_fx_b_date', width: 100, align: 'center', title: '成立日'}
                , {field: 'pd_ov_date', width: 100, align: 'center', title: '到期日'}
                , {field: 'pd_colect_money', width: 100, align: 'center', title: '实际规模'}
                , {field: 'pd_base_rate', width: 150, align: 'center', title: '预期收益率%'}
                , {field: 'pd_asset_rate', width: 150, align: 'center', title: '资产端收益率%'}
                , {field: 'pd_asset_tx', width: 350, align: 'center', title: '资产投向'}
                , {field: 'jianguan_tuoguan_jnei_mc', width: 200, align: 'center', title: '托管行'}
                , {field: 'archi_a', width: 150, align: 'center', title: '起始运作书', templet: function (d) {
                        if (d.archi_a === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_b', width: 150, align: 'center', title: '产品说明书', templet: function (d) {
                        if (d.archi_b === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_c', width: 150, align: 'center', title: '划款指令单', templet: function (d) {
                        if (d.archi_c === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_d', width: 150, align: 'center', title: '认购单', templet: function (d) {
                        if (d.archi_d === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_e', width: 150, align: 'center', title: '确认单', templet: function (d) {
                        if (d.archi_e === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_f', width: 150, align: 'center', title: '资产底层表', templet: function (d) {
                        if (d.archi_f === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {
                    field: 'archi_g', width: 150, align: 'center', title: '到期来账划款单', templet: function (d) {
                        if (d.archi_g === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_h', width: 150, align: 'center', title: 'OA出账审批流程', templet: function (d) {
                        if (d.archi_h === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_i', width: 150, align: 'center', title: 'OA到期入账审批来账', templet: function (d) {
                        if (d.archi_i === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {field: 'archi_j', width: 150, align: 'center', title: 'OA投资指令', templet: function (d) {
                        if (d.archi_j === '2') {return '<span style="color:#f50900;font-weight:bold;">未归档</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">已归档</span>'}}
                }
                , {fixed: 'right', width: 150, title: '操作', align: 'center', toolbar: '#barDemo'}
            ]],
            page: true,
            request: {
                pageName: 'pageNumber',
                limitName: 'pageSize'
            },
            response: {
                countName: 'total',
                dataName: 'rows'
            }
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _archives_pk_id = data['archives_pk_id'];
            var _archi_a = data['archi_a'];
            var _archi_b = data['archi_b'];
            var _archi_c = data['archi_c'];
            var _archi_d = data['archi_d'];
            var _archi_e = data['archi_e'];
            var _archi_f = data['archi_f'];
            var _archi_g = data['archi_g'];
            var _archi_h = data['archi_h'];
            var _archi_i = data['archi_i'];
            var _archi_j = data['archi_j'];

            console.log(obj);
            if (obj.event === 'update') {  //更新事件

                var contents = '<div style="background-color:rgba(35,43,136,0.86);color:#000;line-height:55px;">';
                var _div_htlm = '<div style="width:100%;margin-top:5px;"><div style="float:left;width:25%;text-align:right;">';
                var _div_htlm1 = '</div><div style="float:right;width:65%;margin-right:30px;">';
                var _un_html =  '<option value="">----请选择----</option>' +
                                '<option value="1">已归档</option>' +
                                '<option value="2">未归档</option>' +
                                '</select></div></div>';
                var _done_html = '<option value="1" selected="selected">已归档</option>'+
                                 '<option value="2">未归档</option>' +
                                 '</select></div></div>';

                var _a_conts = _div_htlm + '起始运作书' + _div_htlm1 + '<select style="height:auto;" id="sel_a">';
                var _b_conts = _div_htlm + '产品说明书' + _div_htlm1 + '<select style="height:auto;" id="sel_b">';
                var _c_conts = _div_htlm + '划款指令单' + _div_htlm1 + '<select style="height:auto;" id="sel_c">';
                var _d_conts = _div_htlm + '认购单' + _div_htlm1 + '<select style="height:auto;" id="sel_d">';
                var _e_conts = _div_htlm + '确认单' + _div_htlm1 + '<select style="height:auto;" id="sel_e">';
                var _f_conts = _div_htlm + '资产底层表' + _div_htlm1 + '<select style="height:auto;" id="sel_f">';
                var _g_conts = _div_htlm + '到期来账划款单' + _div_htlm1 + '<select style="height:auto;" id="sel_g">';
                var _h_conts = _div_htlm + 'OA出账审批流程' + _div_htlm1 + '<select style="height:auto;" id="sel_h">';
                var _i_conts = _div_htlm + 'OA到期入账审批来账' + _div_htlm1 + '<select style="height:auto;" id="sel_i">';
                var _j_conts = _div_htlm + 'OA投资指令' + _div_htlm1 + '<select style="height:auto;" id="sel_j">';


                if (_archi_a === '2') {//未归档
                    _a_conts += _un_html;
                } else {
                    _a_conts += _done_html;
                }

                if (_archi_b === '2') {//未归档
                    _b_conts += _un_html;
                } else {
                    _b_conts += _done_html;
                }

                if (_archi_c === '2') {//未归档
                    _c_conts += _un_html;
                } else {
                    _c_conts += _done_html;
                }

                if (_archi_d === '2') {//未归档
                    _d_conts += _un_html;
                } else {
                    _d_conts += _done_html;
                }

                if (_archi_e === '2') {//未归档
                    _e_conts += _un_html;
                } else {
                    _e_conts += _done_html;
                }

                if (_archi_f === '2') {//未归档
                    _f_conts += _un_html;
                } else {
                    _f_conts += _done_html;
                }

                if (_archi_g === '2') {//未归档
                    _g_conts += _un_html;
                } else {
                    _g_conts += _done_html;
                }

                if (_archi_h === '2') {//未归档
                    _h_conts += _un_html;
                } else {
                    _h_conts += _done_html;
                }

                if (_archi_i === '2') {//未归档
                    _i_conts += _un_html;
                } else {
                    _i_conts += _done_html;
                }

                if (_archi_j === '2') {//未归档
                    _j_conts += _un_html;
                } else {
                    _j_conts += _done_html;
                }

                contents = contents + _a_conts + _b_conts + _c_conts + _d_conts + _e_conts + _f_conts + _g_conts
                    + _h_conts + _i_conts + _j_conts + '</div>';


                layer.open({
                    title: '更新档案归档状态',
                    type: 1, //基本层类型：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    closeBtn: false,
                    area: '650px;',
                    shade: [0.4, '#393D49'],
                    skin: 'layui-layer-molv',
                    anim: 2,
                    id: 'LAY_layuipro', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: contents,
                    yes: function (index, layero) {

                        var _a_val = $('#sel_a').val()===""?'2':$('#sel_a').val();
                        var _b_val = $('#sel_b').val()===""?'2':$('#sel_b').val();
                        var _c_val = $('#sel_c').val()===""?'2':$('#sel_c').val();
                        var _d_val = $('#sel_d').val()===""?'2':$('#sel_d').val();
                        var _e_val = $('#sel_e').val()===""?'2':$('#sel_e').val();
                        var _f_val = $('#sel_f').val()===""?'2':$('#sel_f').val();
                        var _g_val = $('#sel_g').val()===""?'2':$('#sel_g').val();
                        var _h_val = $('#sel_h').val()===""?'2':$('#sel_h').val();
                        var _i_val = $('#sel_i').val()===""?'2':$('#sel_i').val();
                        var _j_val = $('#sel_j').val()===""?'2':$('#sel_j').val();

                        var _json = {'archives_pk_id': _archives_pk_id,
                                     'archi_a': _a_val,'archi_b': _b_val,
                                     'archi_c': _c_val,'archi_d': _d_val,
                                     'archi_e': _e_val,'archi_f': _f_val,
                                     'archi_g': _g_val,'archi_h': _h_val,
                                     'archi_i': _i_val,'archi_j': _j_val
                                    };
                        $.post({
                            'url': '/opera_manage/archives_status_confirm',
                            'data': JSON.stringify(_json),
                            'success': function (_data) {
                                alert(_data);
                                layer.close(index);
                                table.reload('test',{
                                    url:'/opera_manage/archives_manage_info_query',
                                    where: {pd_code: "%", pd_fx_b_date: "%"},
                                });
                            },
                            'fail': function (error) {
                                alert(error);
                            }
                        });
                    }
                });
            }
        });

    });

}