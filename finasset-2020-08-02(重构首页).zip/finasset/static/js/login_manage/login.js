
/*
* author:ruanyemao
* date:2020-07-28
* descrip:登陆界面js
*
* */


/*登陆*/
function login() {

    var _account = $('#user_id').val();
    var _passwd = $('#user_pwd').val();

    if (_account == null || _account === "" || _passwd == null || _passwd === "") {
        alert('请输入账号及密码!');
        return false;
    } else {
        return true;
    }

}








