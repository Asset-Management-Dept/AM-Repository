
/*页面初始化*/
$(function () {
    flushtable();
});

/*从远端获取数据并填充数据表格*/
function flushtable() {

    layui.use('table', function () {

        var table = layui.table;
        var _prod_code = $('#prod_code').val() === null || $('#prod_code').val() === '' ? '%' : $('#prod_code').val(); //产品代码
        var _prod_mode = $("#prod_mode").val() === null || $('#prod_mode').val() === '' ? '%' : $('#prod_mode').val();//产品模式
        var _jianguan_muji_fs = $("#jianguan_muji_fs").val() === null || $('#jianguan_muji_fs').val() === '' ? '%' : $('#jianguan_muji_fs').val();//募集方式
        var _fx_b_date = $('#fx_b_date').val() === null || $('#fx_b_date').val() === '' ? '%' : $('#fx_b_date').val();//发行成立日期

        //table初始化
        table.render({
            elem: '#test',
            toolbar: true,
            defaultToolbar: ['filter', 'exports', 'print'],
            url: '/prod_manage/prodqury',
            where: {prod_code: _prod_code, prod_mode: _prod_mode, jianguan_muji_fs: _jianguan_muji_fs, fx_b_date: _fx_b_date},
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 65, title: '序号', fixed: 'left', align: 'center'}
                , {field: 'pd_code', width: 130, align: 'center', fixed: 'left', title: '产品代码'}
                , {field: 'pd_name', width: 300, align: 'left', fixed: 'left', title: '产品名称'}
                , {field: 'pd_base_rate', width: 100, align: 'center', title: '业绩比较基准%'}
                , {field: 'pd_plancolectmoney', width: 100, align: 'center', title: '计划募集金额(元)'}
                , {field: 'pd_mode', width: 100, align: 'center', title: '产品模式'}
                , {field: 'pd_zz_code', width: 100, align: 'center', title: '中债编码'}
                , {field: 'pd_type', width: 100, align: 'center', title: '产品类型'}
                , {field: 'pd_risk_level', width: 100, align: 'center', title: '风险等级'}
                , {field: 'pd_profit_type', width: 100, align: 'center', title: '收益特点'}
                , {field: 'pd_adjust_type', width: 100, align: 'center', title: '核算方式'}
                , {field: 'pd_fx_b_date', width: 100, align: 'center', title: '发行成立日期', sort: true}
                , {field: 'pd_life_statu', width: 100, align: 'center', title: '产品生命状态'}
                , {field: 'pd_salerate', width: 90, align: 'center', title: '销售手续费率%'}
                , {field: 'pd_tuoguangrate', width: 90, align: 'center', title: '托管费率%'}
                , {field: 'pd_investmanagerate', width: 90, align: 'center', title: '投资管理费率%'}
                , {field: 'jianguan_tuoguan_jnei_mc', width: 100, align: 'center', title: '托管行名称'}
                , {field: 'pd_adjust_type', width: 100, align: 'center', title: '核算方式'}
                , {field: 'pd_interest_base', width: 100, align: 'center', title: '计息基数'}
                , {field: 'pd_sy_b_date', width: 100, align: 'center', title: '收益起始日期'}
                , {field: 'pd_open_b_date', width: 100, align: 'center', title: '开放起始日期'}
                , {field: 'pd_open_o_date', width: 100, align: 'center', title: '开放结束日期'}
                , {field: 'pd_df_date', width: 100, align: 'center', title: '产品兑付日期'}
                , {field: 'pd_verify_person', width: 100, align: 'center', title: '审批人姓名'}
                , {field: 'pd_verify_certi', width: 100, align: 'center', title: '审批人证件'}
                , {field: 'pd_desiner_name', width: 100, align: 'center', title: '设计人姓名'}
                , {field: 'pd_desiner_certi', width: 100, align: 'center', title: '设计人证件'}
                , {field: 'investmanage_name', width: 100, align: 'center', title: '投资经理姓名'}
                , {field: 'investmanage_zj', width: 100, align: 'center', title: '投资经理证件'}
                , {field: 'ywry_name', width: 100, align: 'center', title: '业务人员姓名'}
                , {field: 'ywry_zj_phone', width: 100, align: 'center', title: '业务人员座机'}
                , {field: 'ywry_yd_phone', width: 100, align: 'center', title: '业务人员手机'}
                , {field: 'ywry_mail', width: 100, align: 'center', title: '业务人员邮箱'}
                , {field: 'zj_tx', width: 100, align: 'center', title: '资金投向地'}
                , {field: 'lc_fw_type', width: 100, align: 'center', title: '理财服务模式'}
                , {field: 'prod_manager_mode', width: 100, align: 'center', title: '产品管理模式'}
                , {field: 'invest_pz_type', width: 100, align: 'center', title: '资产配置方式'}
                , {field: 'dj_fs', width: 100, align: 'center', title: '产品定价方式'}
                , {field: 'tz_zc_type', width: 100, align: 'center', title: '投资资产类型'}
                , {field: 'hezuo_mode', width: 100, align: 'center', title: '合作模式'}
                , {field: 'prod_zengxin_flag', width: 100, align: 'center', title: '产品增信标识'}
                , {field: 'prod_zengxin_comp', width: 100, align: 'center', title: '产品增信机构'}
                , {field: 'prod_zengxin_xingshi', width: 100, align: 'center', title: '产品增信形式'}
                , {field: 'prod_pingpai', width: 100, align: 'center', title: '产品品牌'}
                , {field: 'prod_qishu', width: 100, align: 'center', title: '产品期数'}
                , {field: 'sale_channel_dif', width: 100, align: 'center', title: '销售渠道划分'}
                , {field: 'touzi_zhonglei_bili', width: 100, align: 'center', title: '投资种类及比例'}
                , {field: 'jianguan_guanli_fs', width: 100, align: 'center', title: '管理方式'}
                , {field: 'jianguan_muji_fs', width: 100, align: 'center', title: '募集方式'}
                , {field: 'jianguan_kuaijihesuan_fs', width: 100, align: 'center', title: '会计核算方式'}
                , {field: 'jianguan_shouyi_bz', width: 100, align: 'center', title: '收益保证标志'}
                , {field: 'jianguan_benjinbz_bz', width: 100, align: 'center', title: '本金保障标志'}
                , {field: 'jianguan_tiqianzhongzhi_bz', width: 100, align: 'center', title: '可提前终止标志'}
                , {field: 'jianguan_shuhui_bz', width: 100, align: 'center', title: '可赎回权标志'}
                , {field: 'jianguan_tuoguan_jwai_daima', width: 100, align: 'center', title: '境外托管机构代码'}
                , {field: 'jianguan_tuoguan_jwai_gb', width: 100, align: 'center', title: '境外托管机构国别'}
                , {field: 'jianguan_tuoguan_jwai_mc', width: 100, align: 'center', title: '境外托管机构名称'}
                , {field: 'pd_cpqx', width: 100, align: 'center', title: '产品期限'}
                , {field: 'pd_tongyezs', width: 100, align: 'center', title: '是否同业专属'}
                , {field: 'pd_setholdtime', width: 100, align: 'center', title: '设置最短持有期限'}
                , {field: 'pd_holddate', width: 100, align: 'center', title: '最短持有期限(天)'}
                , {field: 'pd_tzshouy_dzr', width: 100, align: 'center', title: '投资收益到账日'}
                , {field: 'pd_xjmanagertype', width: 100, align: 'center', title: '是否现金管理类'}
                , {field: 'pd_beginsalemoney', width: 100, align: 'center', title: '起点销售金额'}
                , {field: 'pd_tzbenjin_dzr', width: 100, align: 'center', title: '投资本金到账日'}
                , {field: 'pd_freeback', width: 100, align: 'center', title: '自由赎回'}
                , {fixed: 'right', width: 190, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]],
            page: true,
            request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            },
            response: {
                countName: 'total',
                dataName: 'rows'
            }
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _primary_key = data['pd_code'];
            if (obj.event === 'del') {  //删除事件
                var jsonstr = {'primary_key': _primary_key};
                layer.confirm('确认删除?', function (index) {
                    $.post({
                        'url': '/prod_manage/delete_product_info',
                        'data': JSON.stringify(jsonstr),
                        'success': function (_data) {
                            if (_data == '200') {
                                obj.del();
                                layer.close(index);
                                flushtable();
                            }
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                });
            } else if (obj.event === 'edit') {  //修改事件
                var _titles = '[修改]产品信息';
                var _url = '/prod_manage/prod_info_collect?primary_key=' + _primary_key + '&request_type=modify';
                var _id = 'pd_edit';
                //var cont = '<iframe scrolling="auto" frameborder="0" src="/prod_manage/prod_info_collect?primary_key=' + _primary_key + '&request_type=modify" style="width:100%;height:750px;"></iframe>';
                parent.addTab(_titles, _url, _id);

                /*if (parent.$('#maintab').tabs('exists', title)) {
                    parent.$('#maintab').tabs('select', title);
                } else {
                    parent.$('#maintab').tabs('add', {
                        title: title,
                        content: contents,
                        closable: true
                    });
                }*/


            } else if (obj.event === 'copy') { //复制事件
                var _titles = '[复制]产品信息';
                var _url = '/prod_manage/prod_info_collect?primary_key=' + _primary_key + '&request_type=copy';
                var _id = 'pd_copy';
                //var contents = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_info_collect?primary_key=' + _primary_key + '&request_type=copy" style="width:100%;height:750px;"></iframe>';

                parent.addTab(_titles, _url, _id);
                /*if (parent.$('#maintab').tabs('exists', title)) {
                    parent.$('#maintab').tabs('select', title);
                } else {
                    parent.$('#maintab').tabs('add', {
                        title: title,
                        content: contents,
                        closable: true
                    });
                }*/
            }
        });
    });
}


/*查询*/
function search(){
    flushtable();
}






































