function get_sel_data(id, dict_code) {
    //清空select框中数据
    $('#' + id + '').empty();
    $.ajax({
        url: "/prod_manage/get_sel_data",
        type: "get",
        data: {'dict_code': dict_code},//发送到服务器的数据。
        dataType: "json",//预期服务器返回的数据类型。
        success: function (json) {
            $('#' + id + '').select2({
                data: json,
                minimumResultsForSearch: -1,//设置支持搜索的最小集合，设置为负数，隐藏搜索框
                allowClear: true,//设置allowClear为true，将会在select后加一个X号，可用于快速清空已选项
                placeholder: ''
            });
        },
        error: function () {
            alert("获取下拉框数据失败");
        }
    });

}


/*保存*/
function save_asset_trusts_plan() {

    var _asset_trusts_plan_form = new Map();

    //核算方式 asset_hs_fs
    var _asset_hs_fs = $('#asset_hs_fs').val();
    if (_asset_hs_fs == null || _asset_hs_fs == '') {
        $.messager.alert({title: "错误提示", msg: "[核算方式]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_hs_fs', _asset_hs_fs);
    }

    //资产负债代码 asset_code
    var _asset_code = $('#asset_code').val();
    if (_asset_code == null || _asset_code == '') {
        $.messager.alert({title: "错误提示", msg: "[资产负债代码]为必填项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_code', _asset_code);
    }

    //资产负债名称 asset_name
    var _asset_name = $('#asset_name').val();
    if (_asset_name == null || _asset_name == '') {
        $.messager.alert({title: "错误提示", msg: "[资产负债名称]为必填项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_name', _asset_name);
    }

    //起息日 asset_qx_date
    var _asset_qx_date = $('#asset_qx_date').val();
    if (_asset_qx_date == null || _asset_qx_date == '') {
        $.messager.alert({title: "错误提示", msg: "[起息日]为必填项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_qx_date', _asset_qx_date);
    }

    //到期日 asset_dq_date
    var _asset_dq_date = $('#asset_dq_date').val();
    if (_asset_dq_date == null || _asset_dq_date == '') {
        $.messager.alert({title: "错误提示", msg: "[到期日]为必填项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_dq_date', _asset_dq_date);
    }

    //起息日与到期日之间的判断
    if (_asset_qx_date >= _asset_dq_date) {
        $.messager.alert({title: "错误提示", msg: "[起息日]应小于[到期日]", icon: "warning"});
        return;
    }


    //付息频率 asset_pay_freq
    var _asset_pay_freq = $('#asset_pay_freq').val();
    if (_asset_pay_freq == null || _asset_pay_freq == '') {
        $.messager.alert({title: "错误提示", msg: "[付息频率]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_pay_freq', _asset_pay_freq);
    }

    //收益率% asset_rate
    var _asset_rate = $('#asset_rate').val();
    if (_asset_rate == null || _asset_rate == '') {
        $.messager.alert({title: "错误提示", msg: "[收益率]为必填项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_rate', _asset_rate);
    }

    //计息基数 asset_adjust_base
    var _asset_adjust_base = $('#asset_adjust_base').val();
    if (_asset_adjust_base == null || _asset_adjust_base == '') {
        $.messager.alert({title: "错误提示", msg: "[计息基数]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_adjust_base', _asset_adjust_base);
    }


    //首次付息日 asset_first_pay_date
    var _asset_first_pay_date = $('#asset_first_pay_date').val();
    if (_asset_first_pay_date == null || _asset_first_pay_date == '') {
        $.messager.alert({title: "错误提示", msg: "[首次付息日]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_first_pay_date', _asset_first_pay_date);
    }

    //币种 asset_bz
    var _asset_bz = $('#asset_bz').val();
    if (_asset_bz == null || _asset_bz == '') {
        $.messager.alert({title: "错误提示", msg: "[币种]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_bz', _asset_bz);
    }

    //核心会计科目 asset_kj_km
    var _asset_kj_km = $('#asset_kj_km').val();
    if (_asset_kj_km == null || _asset_kj_km == '') {
        $.messager.alert({title: "错误提示", msg: "[核心会计科目]为必选项", icon: "warning"});
        return;
    } else {
        _asset_trusts_plan_form.set('asset_kj_km', _asset_kj_km);
    }

    //是否穿透 asset_though
    _asset_trusts_plan_form.set('asset_though', $('#asset_though').val() == null || $('#asset_though').val() == '' ? '' : $('#asset_though').val());
    //管理方式 asset_manage_type
    _asset_trusts_plan_form.set('asset_manage_type', $('#asset_manage_type').val() == null || $('#asset_manage_type').val() == '' ? '' : $('#asset_manage_type').val());
    //是否有预期收益率 asset_expect_flag
    _asset_trusts_plan_form.set('asset_expect_flag', $('#asset_expect_flag').val() == null || $('#asset_expect_flag').val() == '' ? '' : $('#asset_expect_flag').val());
    //管理人名称 asset_manager_name
    _asset_trusts_plan_form.set('asset_manager_name', $('#asset_manager_name').val() == null || $('#asset_manager_name').val() == '' ? '' : $('#asset_manager_name').val());
    //托管人 asset_tg_people
    _asset_trusts_plan_form.set('asset_tg_people', $('#asset_tg_people').val() == null || $('#asset_tg_people').val() == '' ? '' : $('#asset_tg_people').val());
    //募集金额 asset_mj_money
    _asset_trusts_plan_form.set('asset_mj_money', $('#asset_mj_money').val() == null || $('#asset_mj_money').val() == '' ? '' : $('#asset_mj_money').val());
    //托管费率% asset_tg_rate
    _asset_trusts_plan_form.set('asset_tg_rate', $('#asset_tg_rate').val() == null || $('#asset_tg_rate').val() == '' ? '' : $('#asset_tg_rate').val());
    //报送人行资产代码 asset_rh_code
    _asset_trusts_plan_form.set('asset_rh_code', $('#asset_rh_code').val() == null || $('#asset_rh_code').val() == '' ? '' : $('#asset_rh_code').val());
    //发行机构类型 asset_fxjg_type
    _asset_trusts_plan_form.set('asset_fxjg_type', $('#asset_fxjg_type').val() == null || $('#asset_fxjg_type').val() == '' ? '' : $('#asset_fxjg_type').val());
    //备注 asset_note
    _asset_trusts_plan_form.set('asset_note', $('#asset_note').val() == null || $('#asset_note').val() == '' ? '' : $('#asset_note').val());


    //设置保存类型：new表示新增产品、modify表示修改产品、copy表示复制产品
    _asset_trusts_plan_form.set('operation_type', $('#operation_type').val());

    let obj = Object.create(null);
    for (let [k, v] of _asset_trusts_plan_form) {
        obj[k] = v;
    }

    $.post({
        'url': '/asset_manage/save_asset_trusts_plan',
        'data': JSON.stringify(obj),
        'success': function (result) {
            $.messager.alert({title: "result", msg: result, icon: "info"});
        },
        'fail': function (error) {
            $.messager.alert({title: "result", msg: error, icon: "warning"});
        }
    });

}


/*重置*/
function reset_asset_trusts_plan() {

}


/*
$(function () {

    $('#hs_fs').select2({
        placeholder: '---请选择---',
        minimumResultsForSearch: -1,
        allowClear: true
    });


    $('#asset_fxjg_type').select2({
        data: asset_fxjg_type_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });

    $('#asset_expect_flag').select2({
        data: asset_expect_flag_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });

    $('#asset_though').select2({
        data: asset_though_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });

    $('#asset_manage_type').select2({
        data: asset_manage_type_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });

    $('#asset_kj_km').select2({
        data: asset_kj_km_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });
    $('#asset_bz').select2({
        data: asset_bz_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });
    $('#asset_pay_freq').select2({
        data: asset_pay_freq_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });
    $('#asset_adjust_base').select2({
        data: asset_adjust_base_data,
        minimumResultsForSearch: -1,
        placeholder: '---请选择---',
        allowClear: true
    });


var hs_fs_data = [
    {id: 1, text: '1-按收益'},
    {id: 2, text: '2-按净值'}
];

var asset_pay_freq_data = [
    {id: 1, text: '1-按月支付'},
    {id: 2, text: '2-按季支付'},
    {id: 3, text: '3-半年支付'},
    {id: 4, text: '4-按年支付'},
    {id: 5, text: '5-到期支付'},
    {id: 6, text: '6-自定义支付'}
];

var asset_adjust_base_data = [
    {id: '360', text: '360-360天'},
    {id: '365', text: '365-365天'},
    {id: '366', text: '366-366天'}
];

var asset_bz_data = [
    {id: '1', text: '人民币'},
    {id: '2', text: '美元'},
    {id: '3', text: '其他'}
];

    var asset_kj_km_data = [
    {id: '01', text: '01-保本类理财产品'},
    {id: '02', text: '02-非保本类理财产品'},
    {id: '03', text: '03-信托产品'},
    {id: '04', text: '04-资产管理计划'},
    {id: '07', text: '07-基金产品'},
    {id: '99', text: '99-其他投资'}
];

var asset_though_data = [
    {id: '0', text: '0-否'},
    {id: '1', text: '1-是'}
];

var asset_manage_type_data = [
    {id: '01', text: '01-主动'},
    {id: '02', text: '02-被动'},
    {id: '03', text: '03-其他'},

];

var asset_expect_flag_data = [
    {id: '0', text: '0-否'},
    {id: '1', text: '1-是'}
];

var asset_fxjg_type_data = [
    {id: '01', text: '01-中小微企业'},
    {id: '02', text: '02-大型企业'},
    {id: '99', text: '99-其他'},

];


});
*/