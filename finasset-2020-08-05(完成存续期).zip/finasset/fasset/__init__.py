from flask import Flask
from flask_login import LoginManager
from config import db, SQLALCHEMY_DATABASE_URI, SQLALCHEMY_TRACK_MODIFICATIONS, templates_dir, static_dir
import os


login_manager = LoginManager()

def create_app():
    """ 创建app的方法 """
    app = Flask(__name__, static_folder=static_dir, template_folder=templates_dir)  # 生成Flask对象

    app.config['SQLALCHEMY_DATABASE_URI'] = SQLALCHEMY_DATABASE_URI  # 配置app的URI

    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = SQLALCHEMY_TRACK_MODIFICATIONS

    app.jinja_env.auto_reload = True

    app.secret_key = os.urandom(24)

    app.debug = True

    login_manager.login_view = 'index.login'  # 定义访问到的登陆界面

    login_manager.login_message = '请先登陆!'

    login_manager.login_message_category = "info"

    db.init_app(app=app)  # SQLAlchemy 初始化App

    login_manager.init_app(app)  # LoginManager初始化App

    print('------------------创建app-------------------------')

    # 返回Flask对象app
    return app



