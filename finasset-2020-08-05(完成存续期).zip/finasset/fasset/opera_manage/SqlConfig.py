

#1.档案信息查询SQL
SQL_ARCHIVES_INFO_QUERY = """
                select rownum as rowno,
                       t3.archives_pk_id,
                       t.pd_code, --产品代码
                       t.pd_name, --产品名称
                       t.pd_profit_type || '-' || a5.item_value as pd_profit_type,--收益特征
                       t.pd_fx_b_date,--成立日
                       t.pd_ov_date,--到期日
                       t1.pd_colect_money,--实际规模
                       t.pd_base_rate,--预期收益率
                       t2.asset_rate as pd_asset_rate,--资产端收益率
                       t2.asset_code||'-'||t2.asset_name as pd_asset_tx,--资产投向
                       t4.eb_name as jianguan_tuoguan_jnei_mc, --托管行 
                       t3.archi_a,
                       t3.archi_b,
                       t3.archi_c,
                       t3.archi_d,
                       t3.archi_e,
                       t3.archi_f,
                       t3.archi_g,
                       t3.archi_h,
                       t3.archi_i,
                       t3.archi_j
                  from fas_prod_info t, --产品信息表
                       fas_prod_sale_info t1,  --产品销售信息表
                       (select * from fas_asset_trade_info a where a.asset_comfir = '1') t2,--资产交易流水表表
                       fas_prod_archives_info t3,--档案信息表
                       fas_escrow_bank_info t4,   --托管行信息表
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_profit_type') a5 --收益特点     
                 where t.pd_code = t1.pd_code --1:1关系-一条产品信息对应一条销售信息
                   and t.pd_code = t2.asset_prod_code --1:N关系-一条产品信息对应多条资产交易信息
                   and t2.deal_id = t3.deal_id --1:1关系-一条资产交易信息对应一条档案信息  
                   and t.jianguan_tuoguan_jnei_mc = t4.eb_code --1:1关系
                   and t.pd_profit_type = a5.item_key(+)
                          """



#2.档案信息查询-总数-分页用
SQL_ARCHIVES_INFO_COUNT_QUERY = """
                select count(1) as total
                  from fas_prod_info t, --产品信息表
                       fas_prod_sale_info t1,  --产品销售信息表
                       (select * from fas_asset_trade_info a where a.asset_comfir = '1') t2,--资产交易流水表表
                       fas_prod_archives_info t3,--档案信息表
                       fas_escrow_bank_info t4,   --托管行信息表
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_profit_type') a5 --收益特点     
                 where t.pd_code = t1.pd_code --1:1关系-一条产品信息对应一条销售信息
                   and t.pd_code = t2.asset_prod_code --1:N关系-一条产品信息对应多条资产交易信息
                   and t2.deal_id = t3.deal_id --1:1关系-一条资产交易信息对应一条档案信息  
                   and t.jianguan_tuoguan_jnei_mc = t4.eb_code --1:1关系
                   and t.pd_profit_type = a5.item_key(+)
                                """

