from fasset.opera_manage import opera_manage
from flask import render_template, request
from flask_login import login_required
from fasset.opera_manage.SqlConfig import *
from fasset.opera_manage.models import *
from utils.DbUtils import DbUtil
from sqlalchemy import text
from fasset import db
from utils.DataTypeEncoder import DecimalEncoder
from utils.PrimaryKey import PrimaryKey
import json



# 日常运营管理-路由跳转
@opera_manage.route("/opera_route", methods=['POST', 'GET'])
@login_required
def opera_route():

    # get 方法
    if request.method == 'GET':
        # 路由跳转到资产信息主界面
        if request.args.get("flag") == 'archives_manage_info':
            return render_template("opera_manage/archives_manage_info.html")



# 档案管理界面-查询
@opera_manage.route("/archives_manage_info_query", methods=['POST','GET'])
@login_required
def archives_manage_info_query():

    # 界面初始化
    if request.method == 'POST':
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _json['pd_code']
        _pd_fx_b_date = _json['pd_fx_b_date']
        _pageSize = _json['pageSize']  # 分页-数据
        _pageNumber = _json['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)

        _sql_archives_info_query = SQL_ARCHIVES_INFO_QUERY  # 档案信息查询sql
        _sql_archives_count_query = SQL_ARCHIVES_INFO_COUNT_QUERY  # 档案信息数量count
        _sql_condition = ""

        # 拼接[产品代码]参数条件
        if _pd_code == '%':
            _sql_condition = _sql_condition + ' and t.pd_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.pd_code=:pd_code '

        # 拼接[产品发行成立日]参数条件
        if _pd_fx_b_date == '%':
            _sql_condition = _sql_condition + ' and t.pd_fx_b_date like \'%\' '
        else:
             _sql_condition = _sql_condition + ' and t.pd_fx_b_date >=:pd_fx_b_date '

        # 分页SQL语句-详细信息
        _sql_archives_info_query_all = """select * from (select * from (""" \
                                   + _sql_archives_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_archives_count_query + _sql_condition

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_archives_info_query_all), {"pd_code": _pd_code, "pd_fx_b_date":_pd_fx_b_date})
            resulttotal = session.execute(text(_sql_count_query_all), {"pd_code": _pd_code, "pd_fx_b_date":_pd_fx_b_date})

            _results_prod_info = resultproxy.fetchall()
            _results_total = resulttotal.fetchall()

            _return_dict = []

            # 总结果数
            for _rt in _results_total:
                _return_dict = dict(zip(_rt.keys(),_rt))

            resList = []
            # 将明细数压入List
            for _rpiq in _results_prod_info:
                rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
                resList.append(rowDict_info)

            _return_dict["rows"] = resList
            _return_dict["code"] = "0"
            _return_dict["msg"] = "success"
            _result_json = json.dumps(_return_dict, cls=DecimalEncoder)

            print('----------------------------------------------档案管理信息最终查询返回的结果为：' + _result_json)

            return _result_json

        except Exception as e:
            print(e)



# 档案归档状态更新
@opera_manage.route("/archives_status_confirm", methods=['POST', 'GET'])
@login_required
def archives_status_confirm():

    if request.method == 'POST':
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _archives_pk_id = _json['archives_pk_id']
        _archi_a = _json['archi_a']
        _archi_b = _json['archi_b']
        _archi_c = _json['archi_c']
        _archi_d = _json['archi_d']
        _archi_e = _json['archi_e']
        _archi_f = _json['archi_f']
        _archi_g = _json['archi_g']
        _archi_h = _json['archi_h']
        _archi_i = _json['archi_i']
        _archi_j = _json['archi_j']

        for key in _json:
            print('----------', _json[key])

        fas_prod_archives_info = FAS_PROD_ARCHIVES_INFO.query.filter(FAS_PROD_ARCHIVES_INFO.archives_pk_id == _archives_pk_id).first()
        fas_prod_archives_info.archi_a = _archi_a
        fas_prod_archives_info.archi_b = _archi_b
        fas_prod_archives_info.archi_c = _archi_c
        fas_prod_archives_info.archi_d = _archi_d
        fas_prod_archives_info.archi_e = _archi_e
        fas_prod_archives_info.archi_f = _archi_f
        fas_prod_archives_info.archi_g = _archi_g
        fas_prod_archives_info.archi_h = _archi_h
        fas_prod_archives_info.archi_i = _archi_i
        fas_prod_archives_info.archi_j = _archi_j

            # 处理异常
        try:
            db.session.commit()  # 提交到数据库 -->执行
            return "档案归档状态更新成功!"
        except Exception as e:
            db.session.rollback()  # 回滚数据  -->执行
            print(e)
            return "档案归档状态更新失败!"



# 未归档档案
@opera_manage.route("/risk_unarchives_info", methods=['POST', 'GET'])
@login_required
def risk_unarchives_info():

    session = DbUtil().get_session()
    # GET方法，首次进入界面时调用
    if request.method == 'GET':
        _key = request.args.get("flag")
        return render_template("opera_manage/risk_unarchives_info.html", _key = _key)


    # POST方法，分页下一页时调用
    if request.method == 'POST':

        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _key = _json['flag']
        _pageSize = _json['pageSize']  # 分页-数据
        _pageNumber = _json['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)

        _sql_archives_info_query = SQL_ARCHIVES_INFO_QUERY  # 档案信息查询sql
        _sql_archives_count_query = SQL_ARCHIVES_INFO_COUNT_QUERY  # 档案信息数量count
        _sql_condition = ""

        if _key == 'archi_a':
            _sql_condition = " and t3.archi_a = '2' "
        if _key == 'archi_b':
            _sql_condition = " and t3.archi_b = '2' "
        if _key == 'archi_c':
            _sql_condition = " and t3.archi_c = '2' "
        if _key == 'archi_d':
            _sql_condition = " and t3.archi_d = '2' "
        if _key == 'archi_e':
            _sql_condition = " and t3.archi_e = '2' "
        if _key == 'archi_f':
            _sql_condition = " and t3.archi_f = '2' "
        if _key == 'archi_g':
            _sql_condition = " and t3.archi_g = '2' "
        if _key == 'archi_h':
            _sql_condition = " and t3.archi_h = '2' "
        if _key == 'archi_i':
            _sql_condition = " and t3.archi_i = '2' "
        if _key == 'archi_j':
            _sql_condition = " and t3.archi_j = '2' "


        # 分页SQL语句-详细信息
        _sql_archives_info_query_all = """select * from (select * from (""" \
                                       + _sql_archives_info_query \
                                       + _sql_condition + """) where rowno > """ \
                                       + str(_begin) + """) where rowno <=""" \
                                       + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_archives_count_query + _sql_condition

        print('-------------分页语句:',_pageNumber,'-------'+_sql_archives_info_query_all)

        try:

            resultproxy = session.execute(text(_sql_archives_info_query_all))
            resulttotal = session.execute(text(_sql_count_query_all))

            _results_details = resultproxy.fetchall()
            _results_total = resulttotal.fetchall()

            _return_dict = []

            # 总结果数
            for _rt in _results_total:
                _return_dict = dict(zip(_rt.keys(),_rt))

            resList = []
            # 将明细数压入List
            for _rpiq in _results_details:
                rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
                resList.append(rowDict_info)

            _return_dict["rows"] = resList
            _return_dict["code"] = "0"
            _return_dict["msg"] = "success"
            _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
            return _result_json

        except Exception as e:
            print(e)


