from config import db


# 资产管理计划(信托计划) 业务表
class FAS_ASSET_TRUSTS_PLAN(db.Model):
    '资产管理计划(信托计划)'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_asset_trusts_plan'

    # 模型对应的字段
    asset_code = db.Column(db.String, primary_key=True, autoincrement=True)
    asset_name = db.Column(db.String(120))
    asset_hs_fs = db.Column(db.String(4))
    asset_qx_date = db.Column(db.String(8))
    asset_dq_date = db.Column(db.String(8))
    asset_pay_freq = db.Column(db.String(4))
    asset_rate = db.Column(db.Float)
    asset_adjust_base = db.Column(db.String(4))
    asset_first_pay_date = db.Column(db.String(8))
    asset_bz = db.Column(db.String(4))
    asset_kj_km = db.Column(db.String(4))
    asset_though = db.Column(db.String(4))
    asset_manage_type = db.Column(db.String(4))
    asset_expect_flag = db.Column(db.String(4))
    asset_manager_name = db.Column(db.String(40))
    asset_tg_people = db.Column(db.String(120))
    asset_mj_money = db.Column(db.Float)
    asset_tg_rate = db.Column(db.Float)
    asset_rh_code = db.Column(db.String(40))
    asset_fxjg_type = db.Column(db.String(4))
    asset_note = db.Column(db.String(120))

    # 构造函数
    # 类的方法与普通的函数只有一个特别的区别——它们必须有一个额外的第一个参数名称, 按照惯例它的名称是 self
    # self代表类的实例，而非类
    def __init__(self, _asset_hs_fs, _asset_code, _asset_name, _asset_qx_date, _asset_dq_date, _asset_pay_freq,
                 _asset_rate, _asset_adjust_base, _asset_first_pay_date, _asset_bz, _asset_kj_km, _asset_though,
                 _asset_manage_type, _asset_expect_flag, _asset_manager_name, _asset_tg_people, _asset_mj_money,
                 _asset_tg_rate, _asset_rh_code, _asset_fxjg_type, _asset_note):
        self.asset_hs_fs = _asset_hs_fs
        self.asset_code = _asset_code
        self.asset_name = _asset_name
        self.asset_qx_date = _asset_qx_date
        self.asset_dq_date = _asset_dq_date
        self.asset_pay_freq = _asset_pay_freq
        self.asset_rate = _asset_rate
        self.asset_adjust_base = _asset_adjust_base
        self.asset_first_pay_date = _asset_first_pay_date
        self.asset_bz = _asset_bz
        self.asset_kj_km = _asset_kj_km
        self.asset_though = _asset_though
        self.asset_manage_type = _asset_manage_type
        self.asset_expect_flag = _asset_expect_flag
        self.asset_manager_name = _asset_manager_name
        self.asset_tg_people = _asset_tg_people
        self.asset_mj_money = _asset_mj_money
        self.asset_tg_rate = _asset_tg_rate
        self.asset_rh_code = _asset_rh_code
        self.asset_fxjg_type = _asset_fxjg_type
        self.asset_note = _asset_note


# 资产交易 - 交易流水表
class FAS_ASSET_TRADE_INFO(db.Model):
    '资产管理计划(信托计划)'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_asset_trade_info'

    # 定义字段
    deal_id = db.Column(db.String, primary_key=True, autoincrement=True)  # 交易ID
    asset_deal_date = db.Column(db.String(8))  # 交易日期
    asset_deal_dirt = db.Column(db.String(4))  # 交易方向
    asset_type = db.Column(db.String(8))  # 资产名称
    asset_code = db.Column(db.String(40))  # 资产名称
    asset_name = db.Column(db.String(120))  # 资产名称
    opponents_code = db.Column(db.String(40))  # 交易对手
    asset_deal_money = db.Column(db.Float)  # 交易金额
    asset_deal_rate = db.Column(db.Float)  # 交易利率
    asset_js_money = db.Column(db.Float)  # 结算金额
    asset_intervest_total = db.Column(db.Float)  # 应计利息总额
    kjfl_type = db.Column(db.String(8))  # 会计分类
    asset_prod_code = db.Column(db.String(40))  # 匹配产品代码
    asset_prod_name = db.Column(db.String(120))  # 匹配产品名称
    asset_prod_ye = db.Column(db.Float)  # 匹配产品余额
    asset_note = db.Column(db.String(120))  # 备注
    asset_qx_date = db.Column(db.String(8))  # 资产起息日
    asset_dq_date = db.Column(db.String(8))  # 资产到期日
    asset_first_pay_date = db.Column(db.String(8))  # 首次付息日
    asset_pay_freq = db.Column(db.String(4))  # 付息频率
    asset_rate = db.Column(db.Float)  # 资产收益率
    asset_kj_km = db.Column(db.String(8))  # 会计科目
    asset_adjust_base = db.Column(db.String(8))  # 计息基数
    asset_comfir = db.Column(db.String(1))  # 交易确认标志

    # 构造函数
    def __init__(self, deal_id, asset_deal_date, asset_deal_dirt, asset_type, asset_code, asset_name, opponents_code,
                 asset_deal_money, asset_deal_rate, asset_js_money, asset_intervest_total, kjfl_type, asset_prod_code,
                 asset_prod_name, asset_prod_ye, asset_note, asset_qx_date, asset_dq_date, asset_first_pay_date,
                 asset_pay_freq, asset_rate, asset_kj_km, asset_adjust_base, asset_comfir):
        self.deal_id = deal_id
        self.asset_deal_date = asset_deal_date
        self.asset_deal_dirt = asset_deal_dirt
        self.asset_type = asset_type
        self.asset_code = asset_code
        self.asset_name = asset_name
        self.opponents_code = opponents_code
        self.asset_deal_money = asset_deal_money
        self.asset_deal_rate = asset_deal_rate
        self.asset_js_money = asset_js_money
        self.asset_intervest_total = asset_intervest_total
        self.kjfl_type = kjfl_type
        self.asset_prod_code = asset_prod_code
        self.asset_prod_name = asset_prod_name
        self.asset_prod_ye = asset_prod_ye
        self.asset_note = asset_note
        self.asset_qx_date = asset_qx_date
        self.asset_dq_date = asset_dq_date
        self.asset_first_pay_date = asset_first_pay_date
        self.asset_pay_freq = asset_pay_freq
        self.asset_rate = asset_rate
        self.asset_kj_km = asset_kj_km
        self.asset_adjust_base = asset_adjust_base
        self.asset_comfir = asset_comfir




# 资产现金流量表：fas_asset_cash_flow
class FAS_ASSET_CASH_FLOW(db.Model):
    '资产现金流量表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_asset_cash_flow'

    # 模型对应的字段
    flow_id = db.Column(db.String, primary_key=True, autoincrement=True) #主键
    deal_id = db.Column(db.String(40)) #交易ID
    asset_code = db.Column(db.String(40)) #资产代码
    asset_name = db.Column(db.String(120)) #资产名称
    account_event = db.Column(db.String(3))  # 会计事件
    pay_date = db.Column(db.String(8)) #支付日期
    theory_cost = db.Column(db.Float) #理论发生额
    reality_cost  = db.Column(db.Float) #实际发生额
    intervest_cost = db.Column(db.Float) #本期应计利息
    is_confirm = db.Column(db.String(1)) #现金确认：0 - 未确认，1 - 已确认
    confirm_date = db.Column(db.String(8))  # 确认日期

    # 构造函数
    def __init__(self, flow_id, deal_id, asset_code, asset_name, account_event, pay_date, theory_cost,
                 reality_cost, intervest_cost, is_confirm, confirm_date):
        self.flow_id = flow_id
        self.deal_id = deal_id
        self.asset_code = asset_code
        self.asset_name = asset_name
        self.account_event = account_event
        self.pay_date = pay_date
        self.theory_cost = theory_cost
        self.reality_cost = reality_cost
        self.intervest_cost = intervest_cost
        self.is_confirm = is_confirm
        self.confirm_date = confirm_date




# 资产余额表：fas_asset_balance
class FAS_ASSET_BALANCE(db.Model):
    '资产余额表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_asset_balance'

    # 模型对应的字段
    asset_code = db.Column(db.String, primary_key=True, autoincrement=True) #资产代码
    asset_balance = db.Column(db.Float) #资产余额
    asset_life_status = db.Column(db.String(8)) #资产生命状态：001 - 持有中, 002 - 已卖出, 003 - 到期

    #构造函数
    def __init__(self, asset_code, asset_balance, asset_life_status):
        self.asset_code = asset_code
        self.asset_balance = asset_balance
        self.asset_life_status = asset_life_status



# 资产余额流水表：fas_asset_balance_deal
class FAS_ASSET_BALANCE_DEAL(db.Model):
    '资产余额流水表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_asset_balance_deal'

    # 模型对应的字段
    id = db.Column(db.String, primary_key=True, autoincrement=True) #主键
    deal_id = db.Column(db.String(40))  # 交易表ID
    asset_code = db.Column(db.String(40)) #资产代码
    asset_name = db.Column(db.String(120)) #资产名称
    deal_date = db.Column(db.String(8)) #交易日期
    deal_type = db.Column(db.String(8)) #交易类型：001-资产买入,002-资产卖出,003-中间付息,004-到期还本
    deal_monney = db.Column(db.Float) #交易金额
    deal_balance = db.Column(db.Float) #交易后余额

    #构造函数
    def __init__(self, id, deal_id, asset_code, asset_name, deal_date, deal_type, deal_monney, deal_balance):
        self.id = id
        self.deal_id = deal_id
        self.asset_code = asset_code
        self.asset_name = asset_name
        self.deal_date = deal_date
        self.deal_type = deal_type
        self.deal_monney = deal_monney
        self.deal_balance = deal_balance
