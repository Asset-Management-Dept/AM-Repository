from fasset.index import index  # 获取蓝图
from flask import render_template, abort,request,redirect, url_for
from flask_login import login_required, logout_user
from jinja2 import TemplateNotFound
from sqlalchemy import text
from utils.DbUtils import DbUtil
from fasset.index.SqlConfig import *
from fasset.index.models import *
from fasset import login_manager
import json


#应用根'/'路径,访问返回登陆界面
@index.route("/", methods=['GET', 'POST'])
def init():
    form = LoginForm()
    _user_exists = '1'
    return render_template("login_manage/login.html", _user_exists=_user_exists, form=form)


# 若访问非授权界面，则返回登陆界面
@index.route("/login", methods=['GET', 'POST'])
def login():

    form = LoginForm()
    # GET方法
    if request.method == 'GET':
        _user_exists = '1'
        return render_template("login_manage/login.html", _user_exists=_user_exists, form=form)

    # POST方法
    if request.method == 'POST':
        user_id = request.form.get('user_id', None)
        user_pwd = request.form.get('user_pwd', None)
        fas_user = FAS_USERS.query_by_userid(user_id)

        if fas_user and fas_user.verify_password(user_pwd):
            login_user(fas_user) # 通过Flask-Login的login_user方法登录用户
            print('存在用户：', user_id, '---', user_pwd)
            user_name = fas_user.user_name
            return redirect(url_for('index.idx', user_name=user_name, user_id=str(user_id)))  # url_for操作对象是函数，而不是route里的路径

        else:
            print('用户不存在：', user_id, '---', user_pwd)
            _user_exists = '0'
            return render_template("login_manage/login.html", _user_exists=_user_exists)



# 首页
@index.route("/idx/?<string:user_name>&<string:user_id>", methods=['GET', 'POST'])
@login_required
def idx(user_name, user_id):
    print('登陆首页用户：', user_name, '---', user_id)
    return render_template("index.html", user_name=user_name, user_id=str(user_id))


# 我的驾驶舱
#对于使用者来说，如果需要页面是授权用户才可见，在相应视图函数前加上 @login_required 装饰器进行声明即可，
# @login_required 装饰器对于未登录用户访问，默认处理是重定向到 LoginManager.login_view 所指定的视图
@index.route("/mypage", methods=['GET', 'POST'])
@login_required
def mypage():

    if request.method == 'GET':
       return render_template("mypage.html")


    if request.method == 'POST':
        session = DbUtil().get_session()
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _key = _json['flag']

        # 初始化档案风险区域
        if _key == 'archives':
            _result_json = init_archives_risk(session)
            return _result_json

        # 初始化数据可视化区域
        if _key == 'DataVisualized':
            _result_json = init_data_visualized(session)
            return _result_json

        # 初始化资产存续期区域
        if _key == 'asset_cash_flow':
            _result_json = init_asset_cash_flow(session)
            return _result_json




#初始化档案风险区域
def init_archives_risk(session):
    try:
        _sql_mypage_init_archives_risk = SQL_MYPAGE_INIT_ARCHIVES_RISK
        resultproxy = session.execute(text(_sql_mypage_init_archives_risk))
        _return_dict = {}
        for x, y in resultproxy:
            _return_dict[x] = y
        _result_json = json.dumps(_return_dict)
        return _result_json
    except Exception as e:
        print(e)
        _result_json = {'archi_a': 'wrong', 'archi_b': 'wrong', 'archi_c': 'wrong', 'archi_d': 'wrong',
                        'archi_e': 'wrong',
                        'archi_f': 'wrong', 'archi_g': 'wrong', 'archi_h': 'wrong', 'archi_i': 'wrong',
                        'archi_j': 'wrong'
                        }
        return _result_json


# 初始化数据可视化区域
def init_data_visualized(session):

    try:
        _sql_mypage_init_data_visualied = SQL_MYPAGE_INTI_DATA_VISUALIZED
        _resultproxy = session.execute(text(_sql_mypage_init_data_visualied))
        _results_query_info = _resultproxy.fetchall()
        # 定义列表[]
        _mylist_data_visualied = []
        for _i in _results_query_info:
            _mylist_data_visualied.append(list(_i))
        # 定义字典{}
        _mydict_area_one = {}
        for i, val in enumerate(_mylist_data_visualied):
            _mydict_area_one[i] = val
        _result_json = json.dumps(_mydict_area_one)
        return _result_json

    except Exception as e:
        print(e)


# 初始化资产存续期区域
def init_asset_cash_flow(session):
    try:
        _sql_mypage_init_asset_cash_flow = SQL_MYPAGE_INIT_ASSET_CASH_FLOW
        resultproxy = session.execute(text(_sql_mypage_init_asset_cash_flow))

        _return_dict = {}
        resList = []
        # 将明细数压入List
        for _rpiq in resultproxy:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
            resList.append(rowDict_info)

        _return_dict["data"] = resList
        _return_dict["code"] = "0"
        _return_dict["msg"] = "success"
        _result_json = json.dumps(_return_dict)
        print('------------初始化资产存续期区域',_result_json)
        return _result_json
    except Exception as e:
        print(e)



#当一个请求过来的时候，如果 ctx.user 没有值，那么 flask-login 就会使用 session 中 session['user_id'] 作为参数，
# 调用 login_manager 中使用 user_loader 装饰器设置的 callback 函数加载用户，
# 需要注意的是，如果指定的 user_id 无效，不应该抛出异常，而是应该返回 None
@login_manager.user_loader
def load_user(user_id):
    print('load_user方法被调用,user_id为：',user_id,'----------',FAS_USERS.query.get(user_id))
    return FAS_USERS.query.get(user_id)


#超时重新登陆
@login_manager.unauthorized_handler
def unauthorized():
    return redirect(url_for('index.login'))


#注销登陆
@index.route("/logout", methods=['GET', 'POST'])
@login_required
def logout():
    if request.method == 'GET':
        logout_user()
        return redirect(url_for('index.login'))


'''

    if request.method == 'POST':
        try:
            _sql_mypage_area_one = SQL_MYPAGE_AREA_ONE
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_mypage_area_one))

            _results_query_info = resultproxy.fetchall()

            # 定义列表[]
            _mylist_area_one = []

            for _i in _results_query_info:
                _mylist_area_one.append(list(_i))

            # 定义字典{}
            _mydict_area_one = {}
            for i, val in enumerate(_mylist_area_one):
                _mydict_area_one[i] = val

            #输出字典
            #for key, values in _mydict_area_one.items():
            #    print(key,'--', values)

            _result_json = json.dumps(_mydict_area_one)

            return _result_json

        except TemplateNotFound:
            abort(404)
        except Exception as e:
            print(e)
'''