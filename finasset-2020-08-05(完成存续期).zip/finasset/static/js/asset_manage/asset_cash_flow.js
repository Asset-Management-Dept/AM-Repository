



/*获取select下拉框数据*/
function get_asset_data(id, dict_code) {

    $('#' + id + '').empty();//清空select框中数据
    $.ajax({
        url: "/asset_manage/get_sel_data",
        type: "get",
        data: {'dict_code': dict_code},//发送到服务器的数据。
        dataType: "json",//预期服务器返回的数据类型。
        success: function (json) {
            $('#' + id + '').select2({
                data: json,
                allowClear: true,//设置allowClear为true，将会在select后加一个X号，可用于快速清空已选项
                placeholder: '-----请选择-----'
            });
            $('#' + id + '').val(null).trigger("change");
            $('#' + id + '').select2("open");
        },
        error: function () {
            alert("获取下拉框数据失败");
        }
    });
}




/*查询*/
function query_cash_flow_info() {
    var _asset_code = $('#asset_code').val(); //产品代码
    if (_asset_code == null) {
        alert('请选择要查询的资产!');
        return 0;
    } else {
        layui.use('table', function () {
            var table = layui.table;
            table.render({
                elem: '#test',
                toolbar: true,
                skin: 'line',
                size: 'sm',
                defaultToolbar: ['filter', 'exports', 'print'],
                url: '/asset_manage/asset_cash_flow_query',
                where: {asset_code: _asset_code},
                method: 'post',
                contentType: 'application/json',
                cols: [[
                    {field: 'rowno', width: 55, title: '', fixed: 'left', align: 'center'}
                    , {field: 'id', width: 200, align: 'center', title: '流水编号',sort: true}
                    , {field: 'deal_id', width: 200, align: 'left', title: '交易编号'}
                    , {field: 'asset_code', width: 250, align: 'left', title: '资产代码'}
                    , {field: 'asset_name', width: 350, align: 'center', title: '资产名称'}
                    , {field: 'deal_date', width: 150, align: 'center', title: '交易日期'}
                    , {field: 'deal_type', width: 150, align: 'center', title: '交易类型'}
                    , {field: 'deal_monney', width: 150, align: 'center', title: '交易金额'}
                    , {field: 'deal_balance', width: 150, align: 'center', title: '交易后资产余额'}
                ]],
                page: true,
                request: {  //用于对分页请求的参数：page、limit重新设定名称
                    pageName: 'pageNumber', //页码的参数名称，默认：page
                    limitName: 'pageSize' //每页数据量的参数名，默认：limit
                },
                response: {
                    countName: 'total',
                    dataName: 'rows'
                }
            });
        });
    }

}