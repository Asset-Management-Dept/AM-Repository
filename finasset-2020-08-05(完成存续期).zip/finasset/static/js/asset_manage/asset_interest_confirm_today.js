




/*界面初始化*/
$(function () {
   query_asset_interest_confirm();
});


/*查询数据*/
function query_asset_interest_confirm() {

    layui.use('table', function () {
        var table = layui.table;
        table.render({
            elem: '#test',
            toolbar: true,
            skin: 'line',
            size: 'sm',
            defaultToolbar: ['filter', 'exports', 'print'],
            url: '/asset_manage/asset_interest_confirm_today_query',
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 25, title: '', fixed: 'left', align: 'center'}
                , {field: 'flow_id', width: 25, align: 'center', title: '流水编号', hide: true}
                , {field: 'deal_id', width: 25, align: 'center', title: '交易编号', hide: true}
                , {field: 'asset_code', width: 150, align: 'center', title: '资产代码'}
                , {field: 'asset_name', width: 300, align: 'center', title: '资产名称'}
                , {field: 'account_event', width: 200, align: 'center', title: '会计事件'}
                , {field: 'pay_date', width: 100, align: 'center', title: '发生日期'}
                , {field: 'theory_cost', width: 150, align: 'center', title: '理论发生金额'}
                , {field: 'reality_cost', width: 150, align: 'center', title: '实际发生金额'}
                , {field: 'asset_qx_date', width: 100, align: 'center', title: '起息日'}
                , {field: 'asset_dq_date', width: 100, align: 'center', title: '到期日'}
                , {field: 'asset_js_money', width: 150, align: 'center', title: '交易结算金额'}
                , {field: 'asset_rate', width: 150, align: 'center', title: '收益率%'}
                , {field: 'is_confirm', width: 100, align: 'center', title: '现金确认',templet: function (d) {
                        if (d.is_confirm === '未确认') {return '<span style="color:#f50900;font-weight:bold;">'+d.is_confirm+'</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">'+d.is_confirm+'</span>'}}
                }
                , {field: 'confirm_date', width: 100, align: 'center', title: '确认日期'}
                , {fixed: 'right', width: 200, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]],
            page: true,
            request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            },
            response: {
                countName: 'total',
                dataName: 'rows'
            }
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _flow_id = data['flow_id'];
            var _deal_id = data['deal_id'];
            var _json = {'deal_id': _deal_id, 'flow_id': _flow_id};
            console.log(obj);
            if (obj.event === 'confirm') {  //确认

            } else if (obj.event === 'modify') { //修改

            } else if (obj.event === 'late') { //延期

            }
        });
    });


}