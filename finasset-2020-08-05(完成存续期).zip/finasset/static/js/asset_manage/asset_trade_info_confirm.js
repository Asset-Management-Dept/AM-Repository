
/*获取select下拉框数据*/
function get_sel_data(id, dict_code) {

    $('#' + id + '').empty();//清空select框中数据
    $.ajax({
        url: "/prod_manage/get_sel_data",
        type: "get",
        data: {'dict_code': dict_code},//发送到服务器的数据。
        dataType: "json",//预期服务器返回的数据类型。
        success: function (json) {
            $('#' + id + '').select2({
                data: json,
                allowClear: true,//设置allowClear为true，将会在select后加一个X号，可用于快速清空已选项
                placeholder: '-----请选择-----'
            });
            $('#' + id + '').val(null).trigger("change");
            $('#' + id + '').select2("open");
        },
        error: function () {
            alert("获取下拉框数据失败");
        }
    });
}

/*查询*/
function query_asset_trade_info() {

    var _asset_type = $('#asset_type').val() === null || $('#asset_type').val() === "" ? '%' : $('#asset_type').val(); //资产类型
    var _asset_trade_date = $('#asset_trade_date').val() === null || $('#asset_trade_date').val() === "" ? '%' : $('#asset_trade_date').val(); //交易日期

    layui.use('table', function () {
        var table = layui.table;
        table.render({
            elem: '#test',
            toolbar: true,
            defaultToolbar: ['filter', 'exports', 'print'],
            url: '/asset_manage/asset_trade_info_confirm_query',
            where: {asset_type: _asset_type, asset_trade_date: _asset_trade_date},
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 25, title: '', fixed: 'left', align: 'center'}
                , {field: 'deal_id', width: 200, align: 'center', title: '交易编号', sort: true}
                , {field: 'asset_comfir', width: 100, align: 'center', title: '成交标志', templet: function (d) {
                        if (d.asset_comfir === '否') {return '<span style="color:#f50900;font-weight:bold;">' + d.asset_comfir + '</span>'}
                        else if(d.asset_comfir === '已成交') { return '<span style="color:#0624b3;font-weight:bold;">' + d.asset_comfir + '</span>' }
                        else { return '<span style="color:#333333;font-weight:bold;">' + d.asset_comfir + '</span>' }
                        }
                  }
                , {field: 'asset_code_name', width: 300, align: 'center', title: '资产名称'}
                , {field: 'asset_prod_code_name', width: 300, align: 'center', title: '匹配理财产品'}
                , {field: 'asset_deal_date', width: 100, align: 'center', title: '交易日期'}
                , {field: 'asset_deal_dirt', width: 100, align: 'center', title: '交易方向'}
                , {field: 'asset_type_name', width: 200, align: 'center', title: '资产负债类型'}
                , {field: 'opponents_code', width: 200, align: 'center', title: '交易对手名称'}
                , {field: 'asset_deal_money', width: 100, align: 'center', title: '交易金额'}
                , {field: 'asset_deal_rate', width: 100, align: 'center', title: '交易利率%'}
                , {field: 'asset_js_money', width: 100, align: 'center', title: '结算金额'}
                , {field: 'asset_intervest_total', width: 150, align: 'center', title: '应计利息总额'}
                , {field: 'kjfl_type', width: 200, align: 'center', title: '会计科目'}
                , {field: 'asset_prod_ye', width: 200, align: 'center', title: '匹配理财产品金额'}
                , {field: 'asset_qx_date', width: 100, align: 'center', title: '资产起息日'}
                , {field: 'asset_dq_date', width: 100, align: 'center', title: '资产到期日'}
                , {field: 'asset_first_pay_date', width: 150, align: 'center', title: '资产首次付息日'}
                , {field: 'asset_pay_freq', width: 150, align: 'center', title: '资产付息频率'}
                , {field: 'asset_rate', width: 150, align: 'center', title: '资产收益率%'}
                , {field: 'asset_kj_km', width: 200, align: 'center', title: '核心会计科目'}
                , {field: 'asset_adjust_base', width: 100, align: 'center', title: '计息基数'}
                , {field: 'asset_note', width: 200, align: 'center', title: '备注'}
                , {fixed: 'right', width: 150, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]],
            page: true,
            request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            },
            response: {
                countName: 'total',
                dataName: 'rows'
            }
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _deal_id = data['deal_id'];
            var _json = {'deal_id': _deal_id};
            console.log(obj);
            if (obj.event === 'done') {  //成交事件
                switch (data['asset_comfir']) {
                    case "已成交": { alert('该笔交易已做过成交确认!'); break; }
                    case "已撤单": { alert('该笔交易已撤单!'); break; }
                    default: {
                        //成交
                        $.post({
                            'url': '/asset_manage/asset_trade_info_confirm',
                            'data': JSON.stringify(_json),
                            'success': function (_data) {
                                alert(_data);
                                //表格数据重载
                                table.reload('test',{
                                    url:'/asset_manage/asset_trade_info_confirm_query',
                                    where: {asset_type: _asset_type, asset_trade_date: _asset_trade_date}
                                });
                            },
                            'fail': function (error) {alert(error);}
                        });
                        break;
                    }
                }
            } else if (obj.event === 'undo') { //撤单事件
                switch (data['asset_comfir']) {
                    case "已成交": { alert('该笔交易已做过成交确认!无法撤单!'); break; }
                    case "已撤单": { alert('该笔交易已做过撤单!'); break; }
                    default: {
                        //撤单
                        $.post({
                            'url': '/asset_manage/asset_trade_info_confirm_cancle',
                            'data': JSON.stringify(_json),
                            'success': function (_data) {
                                alert(_data);
                                table.reload('test',{
                                    url:'/asset_manage/asset_trade_info_confirm_query',
                                    where: {asset_type: _asset_type, asset_trade_date: _asset_trade_date}
                                });
                            },
                            'fail': function (error) {alert(error);}
                        });
                        break;
                    }
                }
            }
        });
    });
}























