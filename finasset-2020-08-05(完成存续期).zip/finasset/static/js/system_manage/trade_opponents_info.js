/*初始载入页面加载数据*/
$(function () {
    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/system_manage/trade_opponents_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/system_manage/trade_opponents_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
});


/*右键弹出菜单:编辑、删除*/
$(function () {
    $('#dd').datagrid({
        onRowContextMenu: function (e, rowIndex, rowData) {
            e.preventDefault(); //阻止浏览器捕获右键事件
            $(this).datagrid("clearSelections"); //取消所有选中项
            $(this).datagrid("selectRow", rowIndex); //根据索引选中该行
            $('#menu').menu('show', {left: e.pageX, top: e.pageY});
            //给右键菜单增加click事件响应
            $('#menu').menu({
                onClick: function (item) {
                    if (item.name == 'modify') {
                        Modif_trade_opponents_info(rowData.trade_opponents_code, rowIndex);
                    }
                    if (item.name == 'delete') {
                        del_trade_opponents_info(rowData.trade_opponents_code, rowIndex);
                    }
                }
            });
            e.preventDefault(); //阻止浏览器自带的右键菜单弹出
        }
    });
});


/*删除交易对手信息*/
function del_trade_opponents_info(primary_key, rowIndex) {

    $.messager.confirm('Confirm', '确认要删除吗?', function (r) {
        //点击确实时执行
        if (r) {
            var jsonstr = {'primary_key': primary_key};
            $.post({
                'url': '/system_manage/delete_trade_opponents_info',
                'data': JSON.stringify(jsonstr),
                'success': function (_data) {
                    if (_data == '200') {
                        $("#dd").datagrid("deleteRow", rowIndex);
                        $.messager.alert({title: "result", msg: '删除成功!', icon: "info"});
                    }
                },
                'fail': function (error) {
                    alert(error);
                }
            })
        }
    });
}


/*修改交易对手信息*/
function Modif_trade_opponents_info(primary_key, rowIndex) {
    var content = '<iframe scrolling="auto" frameborder="0"  src="/system_manage/update_trade_opponents_info?primary_key='
                   + primary_key + '" style="width:100%;height:100%;"></iframe>';
    $('#win').window({
        title: "【修改】交易对手信息",
        width: 850,
        height: 450,
        modal: true,
        content: content,
        onClose: function () {
            //do nothing
        }
    });
}


/*单笔查询交易对手信息*/
function search_trade_opponents_data() {

    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/system_manage/trade_opponents_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/system_manage/trade_opponents_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
}


/*新增交易对手信息*/
function create_trade_opponents_info() {

    var content = '<iframe scrolling="auto" frameborder="0"  src="/system_manage/add_trade_opponents_info" style="width:100%;height:100%;"></iframe>';
    $('#win').window({
        title: '新增交易对手信息',
        width: 850,
        height: 450,
        modal: true,
        content:content
    });

}


/*获得控件的值*/
function get_json_value(_pageSize, _pageNumber) {

    var _query_condition = new Map();
    var _trade_opponents_code = $('#trade_opponents_code').val() == null || $('#trade_opponents_code').val() == '' ? '%' : $('#trade_opponents_code').val();

    _query_condition.set('pageSize', _pageSize);
    _query_condition.set('pageNumber', _pageNumber);
    _query_condition.set('trade_opponents_code', _trade_opponents_code);

    let obj = Object.create(null);
    for (let [k, v] of _query_condition) {
        obj[k] = v;
    }

    var _query_json = JSON.stringify(obj);

    return _query_json;

}