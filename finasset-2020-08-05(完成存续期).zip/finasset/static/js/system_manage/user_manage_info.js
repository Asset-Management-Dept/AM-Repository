/*初始载入页面加载数据*/
$(function () {
    flushtable();
});


/*从远端获取数据并填充数据表格*/
function flushtable() {

    layui.use('table', function () {

        var table = layui.table;
        //table初始化
        table.render({
            elem: '#test'
            , toolbar: '#toolbarDemo'
            , defaultToolbar: ['filter', 'exports', 'print']
            , url: '/system_manage/user_manage_info'
            , method: 'post'
            , contentType: 'application/json'
            , cols: [[
                {field: 'rowno', width: 60, title: '序号', fixed: 'left', align: 'center'}
                , {field: 'user_id', width: 300, align: 'center', title: '用户ID'}
                , {field: 'user_name', width: 400, align: 'center', title: '用户名称'}
                , {fixed: 'right', width: 400, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]]
            , page: true
            , request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            }
            , response: {
                countName: 'total',
                dataName: 'rows'
            }
        });
        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _user_id = data['user_id'];
            console.log(obj);
            if (obj.event === 'del') {  //删除事件
                layer.confirm('确认删除?', function (index) {
                    var _json = {'user_id': _user_id};
                    $.post({
                        'url': '/system_manage/delete_user_info',
                        'data': JSON.stringify(_json),
                        'success': function (_data) {
                            if (_data === '200') {
                                obj.del();
                                layer.close(layer.index);
                                flushtable();
                            }
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });

                });
            } else if (obj.event === 'modify') {  //修改事件

                layer.open({
                    title: '修改用户密码',
                    type: 1, //基本层类型：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    closeBtn: false,
                    area: '600px;',
                    shade: 0.8,
                    id: 'LAY_layuipro_modify_pwd', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #fff; color: #393D49; font-weight: 300;">' +
                        '<input name="user_pwd_old" id="user_pwd_old" class="txt" type="password" placeholder="请输入原密码..." style="height: 40px;width: 100%;" autocomplete="off"><br><br>' +
                        '<input name="user_pwd_new" id="user_pwd_new" class="txt" type="password" placeholder="请输入新密码..." style="height: 40px;width: 100%;" autocomplete="off">' +
                        '</div>',
                    yes: function () {
                        var user_pwd_old = $('#user_pwd_old').val();
                        var user_pwd_new = $('#user_pwd_new').val();
                        //密码中必须包含字母、数字、特称字符，至少8个字符，最多30个字符。
                        var regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,30}');
                        if (user_pwd_old == null || user_pwd_old === "" || user_pwd_new == null || user_pwd_new === "") {
                            alert("请输入全部必填要素后再提交!");
                            return false;
                        } else if(!regex.test(user_pwd_new)){
                            alert("您的新密码复杂度太低（密码中必须包含字母、数字、特殊字符，8~30个字符），请重新输入！");
                            return false;
                        } else {
                            var _json = {'user_id':_user_id, 'user_pwd_old': user_pwd_old, 'user_pwd_new': user_pwd_new};
                            $.post({
                                'url': '/system_manage/modify_user_info',
                                'data': JSON.stringify(_json),
                                'success': function (_data) {
                                    if (_data === '200') {
                                        alert("用户密码修改成功!");
                                        flushtable();
                                        layer.close(layer.index);
                                    }else {
                                        alert(_data);
                                        layer.close(layer.index);
                                    }
                                },
                                'fail': function (error) {alert(error);}
                            });
                        }
                    }
                });
            }
        });
        // 监听头部工具事件
        table.on('toolbar(test)', function (obj) {
            if (obj.event === 'create') { //新建事件 //打开一个弹出层
                layer.open({
                    title: '新建用户信息',
                    type: 1, //基本层类型：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    closeBtn: false,
                    area: '600px;',
                    shade: 0.8,
                    id: 'LAY_layuipro', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #fff; color: #393D49; font-weight: 300;">' +
                        '<input name="user_id" id="user_id" class="txt" type="text" placeholder="请输入账号..." style="height: 40px;width: 100%;" autocomplete="off"><br><br>' +
                        '<input name="user_name" id="user_name" class="txt" type="text" placeholder="请输入用户名..." style="height: 40px;width: 100%;" autocomplete="off"><br><br>' +
                        '<input name="user_pwd" id="user_pwd" class="txt" type="password" placeholder="请输入密码..." style="height: 40px;width: 100%;" autocomplete="off">' +
                        '</div>',
                    yes: function () {

                        var user_id = $('#user_id').val();
                        var user_name = $('#user_name').val();
                        var user_pwd = $('#user_pwd').val();
                        //密码中必须包含字母、数字、特称字符，至少8个字符，最多30个字符。
                        var regex = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,30}');

                        if (user_id == null || user_id === "" || user_name == null || user_name === "" || user_pwd == null|| user_pwd === "") {
                            alert("请输入全部必填要素后再提交!");
                            return false;
                        }else if(!regex.test(user_pwd)){
                            alert("您的密码复杂度太低（密码中必须包含字母、数字、特殊字符，8~30个字符），请重新输入！");
                            return false;
                        }else {
                            var _json = {'user_id': user_id, 'user_name': user_name, 'user_pwd': user_pwd};
                            $.post({
                                'url': '/system_manage/create_user_info',
                                'data': JSON.stringify(_json),
                                'success': function (_data) {
                                    if (_data === '200') {
                                        alert("用户新增成功!");
                                        flushtable();
                                        layer.close(layer.index);
                                    }
                                },
                                'fail': function (error) {alert(error);}
                            });
                        }
                    }
                });
            }
        });

    });
}