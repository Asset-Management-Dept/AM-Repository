



#1.托管行信息-分页用
SQL_ESCROW_BANK_INFO_QUERY = """ 
                    select rownum as rowno,
                           t.eb_code, 
                           t.eb_name, 
                           t.eb_open_bank_name, 
                           t.eb_account_name, 
                           t.eb_account_no, 
                           t.eb_area 
                     from fas_escrow_bank_info t 
                            """



#2.托管行信息总数-分页用
SQL_ESCROW_BANK_INFO_COUNT_QUERY = """  select count(1) as total from fas_escrow_bank_info t  """


#3.更新托管行信息
SQL_UPDATE_ESCROW_BANK_QUERY = """ 
                    select rownum as rowno,
                           t.eb_code, 
                           t.eb_name, 
                           t.eb_open_bank_name, 
                           t.eb_account_name, 
                           t.eb_account_no, 
                           t.eb_area 
                     from fas_escrow_bank_info t where 1 = 1
                            """