from fasset.opera_manage import opera_manage
from flask import render_template, request
from fasset.opera_manage.SqlConfig import *
from fasset.opera_manage.models import *
from utils.DbUtils import DbUtil
from sqlalchemy import text
from fasset import db
from utils.DataTypeEncoder import DecimalEncoder
from utils.PrimaryKey import PrimaryKey
import json


# 档案管理界面
@opera_manage.route("/archives_manage_info",methods=['POST','GET'])
def archives_manage_info():

    # 界面首次访问返回
    if request.method == 'GET':
        return render_template("opera_manage/archives_manage_info.html")

    # 界面初始化
    if request.method == 'POST':
        _json_ebcode = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _json_ebcode['pd_code']
        _pageSize = _json_ebcode['pageSize']  # 分页-数据
        _pageNumber = _json_ebcode['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)
        _sql_archives_info_query = SQL_ARCHIVES_INFO_QUERY  # 档案信息查询sql
        _sql_archives_count_query = SQL_ARCHIVES_INFO_COUNT_QUERY  # 档案信息数量count
        _sql_condition = ""

        # 拼接[产品代码]参数条件
        if _pd_code == '%':
            _sql_condition = _sql_condition + ' and t.pd_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.pd_code=:pd_code '

        # 分页SQL语句-详细信息
        _sql_archives_info_query_all = """select * from (select * from (""" \
                                   + _sql_archives_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_archives_count_query + _sql_condition

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_archives_info_query_all), {"pd_code": _pd_code})
            resulttotal = session.execute(text(_sql_count_query_all), {"pd_code": _pd_code})

        except Exception as e:
            print(e)

        _results_prod_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        resList = []
        # 将明细数压入List
        for _rpiq in _results_prod_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
            resList.append(rowDict_info)

        _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

        _result_json = json.dumps(_return_dict,cls=DecimalEncoder)

        print('----------------------------------------------档案管理信息最终查询返回的结果为：' + _result_json)

        return _result_json



# 档案管理保存
@opera_manage.route("/save_archives_manage_info", methods=['POST', 'GET'])
def save_archives_manage_info():

    if request.method == 'POST':
        _post_json_data = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _post_json_data['pd_code']
        _archi_a = _post_json_data['archi_a']
        _archi_b = _post_json_data['archi_b']
        _archi_c = _post_json_data['archi_c']
        _archi_d = _post_json_data['archi_d']
        _archi_e = _post_json_data['archi_e']
        _archi_f = _post_json_data['archi_f']
        _archi_g = _post_json_data['archi_g']
        _archi_h = _post_json_data['archi_h']
        _archi_i = _post_json_data['archi_i']
        _archi_j = _post_json_data['archi_j']

        for key in _post_json_data:
            print('----------',_post_json_data[key])


        # 获得数据库会话
        session = DbUtil().get_session()
        _existflag = FAS_PROD_ARCHIVES_INFO.query.filter_by(pd_code=_pd_code).first()
        if (_existflag == None):

            # 创建一个主键对象，从数据库获取主键
            primaryobj = PrimaryKey(session)

            # 从数据库获取主键
            _archives_pk = primaryobj.getArchivesPrimaryKey()

            fas_prod_archives_info = FAS_PROD_ARCHIVES_INFO(_archives_pk, _pd_code, _archi_a, _archi_b,
                                                            _archi_c, _archi_d, _archi_e, _archi_f,
                                                            _archi_g, _archi_h,_archi_i,_archi_j)

            session.add(fas_prod_archives_info)

            # 处理异常
            try:
                session.commit()  # 提交到数据库 -->执行
                return "200"
            except Exception as e:
                session.rollback()  # 回滚数据  -->执行
                print(e)
                return "300"
        else:

            # 创建数据库
            db.create_all()
            fas_prod_archives_info = FAS_PROD_ARCHIVES_INFO.query.filter(FAS_PROD_ARCHIVES_INFO.archives_pk_id == _existflag.archives_pk_id).first()
            fas_prod_archives_info.archi_a = _archi_a
            fas_prod_archives_info.archi_b = _archi_b
            fas_prod_archives_info.archi_c = _archi_c
            fas_prod_archives_info.archi_d = _archi_d
            fas_prod_archives_info.archi_e = _archi_e
            fas_prod_archives_info.archi_f = _archi_f
            fas_prod_archives_info.archi_g = _archi_g
            fas_prod_archives_info.archi_h = _archi_h
            fas_prod_archives_info.archi_i = _archi_i
            fas_prod_archives_info.archi_j = _archi_j

            # 处理异常
            try:
                db.session.commit()  # 提交到数据库 -->执行
                return "400"
            except Exception as e:
                db.session.rollback()  # 回滚数据  -->执行
                print(e)
                return "500"


# 未归档档案
@opera_manage.route("/risk_unarchives_info", methods=['POST', 'GET'])
def risk_unarchives_info():

    if request.method == 'GET':

        _key = request.args.get("unarchives")
        _pd_code = request.args.get("pd_code")  # 分页-数据
        _pageSize = request.args.get("pageSize")  # 分页-数据
        _pageNumber = request.args.get("pageNumber")  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)

        print(_key,'----_pd_code',_pd_code,'----_pageSize',_pageSize,'----_pageNumber',_pageNumber)

        session = DbUtil().get_session()

        if _key == '起始运作书':

            _sql_risk_unarchives_info = SQL_RISK_UNARCHIVES_INFO_A

            _sql_archives_count_query = SQL_RISK_UNARCHIVES_INFO_A_CNT

            _sql_condition = ""

            # 拼接[产品代码]参数条件
            if _pd_code == '%':
                _sql_condition = _sql_condition + ' and t.pd_code like \'%\' '
            else:
                _sql_condition = _sql_condition + ' and t.pd_code=:pd_code '

            # 分页SQL语句-详细信息
            _sql_archives_info_query_all = """select * from (select * from (""" \
                                           + _sql_risk_unarchives_info \
                                           + _sql_condition + """) where rowno > """ \
                                           + str(_begin) + """) where rowno <=""" \
                                           + str(_over)
            # 分页SQL语句-查询总数
            _sql_count_query_all = _sql_archives_count_query + _sql_condition

            try:

                resultproxy = session.execute(text(_sql_archives_info_query_all), {"pd_code": _pd_code})
                resulttotal = session.execute(text(_sql_count_query_all), {"pd_code": _pd_code})

            except Exception as e:
                print(e)

            _results_details = resultproxy.fetchall()
            _results_total = resulttotal.fetchall()

            # 总结果数
            for _rt in _results_total:
                _return_dict = dict(zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

            resList = []
            # 将明细数压入List
            for _rpiq in _results_details:
                rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
                resList.append(rowDict_info)

            _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

            _result_json = json.dumps(_return_dict, cls=DecimalEncoder)

            return render_template("opera_manage/risk_unarchives_info.html",_result_json = _result_json)


        if _key == '产品说明书':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == '划款指令单':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == '认购单':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == '确认单':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == '资产底层表':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == '到期来账划款单':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == 'OA出账审批流程':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == 'OA到期入账审批来账':
            return render_template("opera_manage/risk_unarchives_info.html")



        if _key == 'OA投资指令':
            return render_template("opera_manage/risk_unarchives_info.html")



