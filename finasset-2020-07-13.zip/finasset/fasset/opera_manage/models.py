from config import db


class FAS_PROD_ARCHIVES_INFO(db.Model):
    '理财产品销售信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_prod_archives_info'

    archives_pk_id = db.Column(db.String, primary_key=True, autoincrement=True)
    pd_code = db.Column(db.String)
    archi_a = db.Column(db.String)
    archi_b = db.Column(db.String)
    archi_c = db.Column(db.String)
    archi_d = db.Column(db.String)
    archi_e = db.Column(db.String)
    archi_f = db.Column(db.String)
    archi_g = db.Column(db.String)
    archi_h = db.Column(db.String)
    archi_i = db.Column(db.String)
    archi_j = db.Column(db.String)

    def __init__(self, _archives_pk_id, _pd_code, _archi_a, _archi_b, _archi_c, _archi_d, _archi_e, _archi_f, _archi_g, _archi_h,_archi_i,_archi_j):
        self.archives_pk_id = _archives_pk_id
        self.pd_code = _pd_code
        self.archi_a = _archi_a
        self.archi_b = _archi_b
        self.archi_c = _archi_c
        self.archi_d = _archi_d
        self.archi_e = _archi_e
        self.archi_f = _archi_f
        self.archi_g = _archi_g
        self.archi_h = _archi_h
        self.archi_i = _archi_i
        self.archi_j = _archi_j
