from fasset.index import index  # 获取蓝图
from flask import render_template, abort,request
from jinja2 import TemplateNotFound
from sqlalchemy import text
from utils.DbUtils import DbUtil
from fasset.index.SqlConfig import *
import json

# 主页面
@index.route("/")
def _index():
    try:
        return render_template("index.html")
    except TemplateNotFound:
        abort(404)

# 我的界面
@index.route("/mypage",methods=['GET','POST'])
def _mypage():

    if request.method == 'GET':
        try:
            return render_template("mypage.html")
        except TemplateNotFound:
            abort(404)

    if request.method == 'POST':
        try:
            _sql_mypage_area_one = SQL_MYPAGE_AREA_ONE

            session = DbUtil().get_session()

            resultproxy = session.execute(text(_sql_mypage_area_one))

            _return_dict = {}

            for x,y in resultproxy:

                _return_dict[x] = y

            _result_json = json.dumps(_return_dict)

            return _result_json

        except TemplateNotFound:
            abort(404)
        except Exception as e:
            print(e)



'''

    if request.method == 'POST':
        try:
            _sql_mypage_area_one = SQL_MYPAGE_AREA_ONE
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_mypage_area_one))

            _results_query_info = resultproxy.fetchall()

            # 定义列表[]
            _mylist_area_one = []

            for _i in _results_query_info:
                _mylist_area_one.append(list(_i))

            # 定义字典{}
            _mydict_area_one = {}
            for i, val in enumerate(_mylist_area_one):
                _mydict_area_one[i] = val

            #输出字典
            #for key, values in _mydict_area_one.items():
            #    print(key,'--', values)

            _result_json = json.dumps(_mydict_area_one)

            return _result_json

        except TemplateNotFound:
            abort(404)
        except Exception as e:
            print(e)
'''