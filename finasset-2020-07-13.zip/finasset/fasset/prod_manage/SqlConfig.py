'''
author:ruanyemao
date:2020-6-23
descrip:产品管理模块的SQL语句
'''

# 1.产品信息查询模块
SQL_PRODUCT_INFO_QUERY = """
                select rownum as rowno, 
                       pd_code, --产品代码
                       pd_name, --产品名称
                       a1.item_value as pd_mode, --产品模式
                       pd_zz_code, --中债编码
                       pd_rg_bg_date, --认购开始日期
                       pd_fx_b_date, --发行成立日期
                       pd_base_rate,--业绩比较基准
                       a8.item_value as pd_life_statu --产品生命状态
                  from fas_prod_info t,
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_mode') a1,
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_life_statu') a8
                  where t.pd_mode = a1.item_key(+)
                    and t.pd_life_statu = a8.item_key(+)
              """

# 1.产品信息查询模块
SQL_PRODUCT_INFO_QUERY_NEW = """
                            select rownum as rowno,
                                   pd_code,
                                   pd_name,
                                   pd_mode,
                                   pd_zz_code,
                                   pd_type,
                                   pd_colect_type,
                                   pd_risk_level,
                                   pd_profit_type,
                                   pd_adjust_type,
                                   pd_interest_base,
                                   pd_rg_bg_date,
                                   pd_rg_ov_date,
                                   pd_fx_b_date,
                                   pd_sy_b_date,
                                   pd_open_b_date,
                                   pd_open_o_date,
                                   pd_ov_date,
                                   pd_df_date,
                                   pd_life_statu,
                                   pd_verify_person,
                                   pd_verify_certi,
                                   pd_desiner_name,
                                   pd_desiner_certi,
                                   investmanage_name,
                                   investmanage_zj,
                                   ywry_name,
                                   ywry_zj_phone,
                                   ywry_yd_phone,
                                   ywry_mail,
                                   zj_tx,
                                   lc_fw_type,
                                   prod_manager_mode,
                                   invest_pz_type,
                                   dj_fs,
                                   tz_zc_type,
                                   hezuo_mode,
                                   prod_zengxin_flag,
                                   prod_zengxin_comp,
                                   prod_zengxin_xingshi,
                                   prod_pingpai,
                                   prod_qishu,
                                   sale_channel_dif,
                                   touzi_zhonglei_bili,
                                   jianguan_guanli_fs,
                                   jianguan_muji_fs,
                                   jianguan_kuaijihesuan_fs,
                                   jianguan_shouyi_bz,
                                   jianguan_benjinbz_bz,
                                   jianguan_tiqianzhongzhi_bz,
                                   jianguan_shuhui_bz,
                                   jianguan_tuoguan_jwai_daima,
                                   jianguan_tuoguan_jnei_mc,
                                   jianguan_tuoguan_jwai_gb,
                                   jianguan_tuoguan_jwai_mc,
                                   pd_cpqx,
                                   pd_tongyezs,
                                   pd_setholdtime,
                                   pd_holddate,
                                   pd_tzshouy_dzr,
                                   pd_xjmanagertype,
                                   pd_beginsalemoney,
                                   pd_salerate,
                                   pd_tuoguangrate,
                                   pd_plancolectmoney,
                                   pd_investmanagerate,
                                   pd_tzbenjin_dzr,
                                   pd_freeback,
                                   pd_base_rate
                              from v_fas_product_detail_info t where 1 = 1
                              """

# 2.产品信息查询模块
SQL_SEL_DATA_QUERY = """ select a.item_key as id, a.item_key || '-'||a.item_value as text from fas_sys_dict a """

# 3.产品信息总数-分页用
SQL_PRODUCT_COUNT_QUERY = """ 
                select count(1) as total
                  from fas_prod_info t,
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_mode') a1,
                       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_life_statu') a8
                  where t.pd_mode = a1.item_key(+)
                    and t.pd_life_statu = a8.item_key(+)
                          """


# 3.产品信息总数-分页用
SQL_PRODUCT_COUNT_QUERY_NEW = """  select count(1) as total from v_fas_product_detail_info t where 1 =1 """


# 4.产品详细信息
SQL_PRODUCT_DETAILS_QUERY = """
                            select t.pd_code, t.pd_name, t.pd_mode || '#'||a1.item_value as pd_mode, t.pd_zz_code, 
                                   t.pd_type || '#' ||a2.item_value as pd_type,
                                   t.pd_colect_type || '#' ||a3.item_value as pd_colect_type,
                                   t.pd_risk_level || '#' ||a4.item_value as pd_risk_level,
                                   t.pd_profit_type || '#' ||a5.item_value as pd_profit_type,
                                   t.pd_adjust_type|| '#' ||a6.item_value as pd_adjust_type,
                                   t.pd_interest_base|| '#' ||a7.item_value as pd_interest_base,
                                   t.pd_rg_bg_date, t.pd_rg_ov_date, t.pd_fx_b_date, t.pd_sy_b_date, t.pd_open_b_date, t.pd_open_o_date, 
                                   t.pd_ov_date, t.pd_df_date, t.pd_life_statu || '#' || a8.item_value as pd_life_statu,
                                   t.pd_verify_person || '#' || a27.item_value as pd_verify_person,
                                   t.pd_verify_certi,t.pd_desiner_name || '#' || a28.item_value as pd_desiner_name,
                                   t.pd_desiner_certi,t.investmanage_name || '#' || a29.item_value as investmanage_name,t.investmanage_zj,
                                   t.ywry_name || '#' || a30.item_value as ywry_name,
                                   t.ywry_zj_phone,t.ywry_yd_phone,t.ywry_mail,
                                   t.zj_tx || '#' ||a9.item_value as zj_tx,
                                   t.lc_fw_type || '#' ||a10.item_value as lc_fw_type,
                                   t.prod_manager_mode || '#' ||a11.item_value as prod_manager_mode,
                                   t.invest_pz_type || '#' ||a12.item_value as invest_pz_type,
                                   t.dj_fs || '#' ||a13.item_value as dj_fs,
                                   t.tz_zc_type || '#' ||a14.item_value as tz_zc_type,
                                   t.hezuo_mode || '#' ||a15.item_value as hezuo_mode,
                                   t.prod_zengxin_flag || '#' ||a16.item_value as prod_zengxin_flag,
                                   t.prod_zengxin_comp || '#' ||a17.item_value as prod_zengxin_comp,
                                   t.prod_zengxin_xingshi || '#' ||a18.item_value as prod_zengxin_xingshi,t.prod_pingpai, t.prod_qishu, 
                                   t.sale_channel_dif || '#' ||a19.item_value as sale_channel_dif, 
                                   t.touzi_zhonglei_bili,t.jianguan_guanli_fs || '#' ||a20.item_value as jianguan_guanli_fs,
                                   t.jianguan_muji_fs || '#' ||a21.item_value as jianguan_muji_fs,
                                   t.jianguan_kuaijihesuan_fs || '#' ||a22.item_value as jianguan_kuaijihesuan_fs,
                                   t.jianguan_shouyi_bz || '#' ||a23.item_value as jianguan_shouyi_bz,
                                   t.jianguan_benjinbz_bz || '#' ||a24.item_value as jianguan_benjinbz_bz,
                                   t.jianguan_tiqianzhongzhi_bz || '#' ||a25.item_value as jianguan_tiqianzhongzhi_bz,
                                   t.jianguan_shuhui_bz || '#' ||a26.item_value as jianguan_shuhui_bz,t.jianguan_tuoguan_jwai_daima,
                                   jianguan_tuoguan_jnei_mc || '#' || a38.eb_name as jianguan_tuoguan_jnei_mc,
                                   t.jianguan_tuoguan_jwai_gb,t.jianguan_tuoguan_jwai_mc,
                                   t.pd_cpqx || '#' ||a31.item_value as pd_cpqx,
                                   t.pd_tongyezs || '#' ||a32.item_value as pd_tongyezs,
                                   t.pd_setholdtime || '#' ||a33.item_value as pd_setholdtime,t.pd_holddate,
                                   t.pd_tzshouy_dzr || '#' ||a34.item_value as pd_tzshouy_dzr,
                                   t.pd_xjmanagertype || '#' ||a35.item_value as pd_xjmanagertype,
                                   t.pd_beginsalemoney,t.pd_salerate,t.pd_tuoguangrate,t.pd_plancolectmoney,t.pd_investmanagerate,
                                   t.pd_tzbenjin_dzr || '#' ||a36.item_value as pd_tzbenjin_dzr,
                                   t.pd_freeback || '#' ||a37.item_value as pd_freeback,
                                   t.pd_base_rate            
                              from fas_prod_info t,
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_mode') a1, --产品模式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_type') a2,--产品类型
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_colect_type') a3,--募集币种
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_risk_level') a4,--风险等级
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_profit_type') a5,--收益特点
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_adjust_type') a6,--核算方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_interest_base') a7,--计息基数
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_life_statu') a8,   --产品生命状态
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'zj_tx') a9,   --资金投向地
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'lc_fw_type') a10,   --理财服务模式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_manager_mode') a11,   --产品管理模式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'invest_pz_type') a12,   --资产配置方式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'dj_fs') a13,   --产品定价方式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'tz_zc_type') a14,   --投资资产类型 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'hezuo_mode') a15,   --合作模式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_flag') a16,   --产品增信标识 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_comp') a17,   --产品增信机构 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_xingshi') a18,   --产品增信形式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'sale_channel_dif') a19,   --销售渠道划分
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_guanli_fs') a20,   --管理方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_muji_fs') a21,   --募集方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_kuaijihesuan_fs') a22,   --会计核算方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shouyi_bz') a23,   --收益保证标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_benjinbz_bz') a24,   --本金保障标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_tiqianzhongzhi_bz') a25,   --可提前终止标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shuhui_bz') a26,    --可赎回权标志    
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_verify_person') a27,    --审批人姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_desiner_name') a28,    --设计人姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'investmanage_name') a29,    --投资经理姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'ywry_name') a30,    --业务人员姓名  
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_cpqx') a31, --产品期限
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tongyezs') a32, --是否同业专属
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_setholdtime') a33, --设置最短持有期限
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzshouy_dzr') a34, --投资收益到账日
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_xjmanagertype') a35, --是否现金管理类
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzbenjin_dzr') a36, --投资本金到账日
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_freeback') a37, --自由赎回标识
                                   (select a.eb_code,a.eb_name from fas_escrow_bank_info a) a38 --托管行          
                         where t.pd_mode = a1.item_key(+)
                           and t.pd_type = a2.item_key(+)
                           and t.pd_colect_type = a3.item_key(+)
                           and t.pd_risk_level = a4.item_key(+)
                           and t.pd_profit_type = a5.item_key(+)
                           and t.pd_adjust_type = a6.item_key(+)
                           and t.pd_interest_base = a7.item_key(+)
                           and t.pd_life_statu = a8.item_key(+)
                           and t.zj_tx = a9.item_key(+)
                           and t.lc_fw_type = a10.item_key(+)
                           and t.prod_manager_mode = a11.item_key(+)
                           and t.invest_pz_type = a12.item_key(+)
                           and t.dj_fs = a13.item_key(+)
                           and t.tz_zc_type = a14.item_key(+)
                           and t.hezuo_mode = a15.item_key(+)
                           and t.prod_zengxin_flag = a16.item_key(+)
                           and t.prod_zengxin_comp = a17.item_key(+)
                           and t.prod_zengxin_xingshi = a18.item_key(+)
                           and t.sale_channel_dif = a19.item_key(+)
                           and t.jianguan_guanli_fs = a20.item_key(+)
                           and t.jianguan_muji_fs = a21.item_key(+)
                           and t.jianguan_kuaijihesuan_fs = a22.item_key(+)
                           and t.jianguan_shouyi_bz = a23.item_key(+)
                           and t.jianguan_benjinbz_bz = a24.item_key(+)
                           and t.jianguan_tiqianzhongzhi_bz = a25.item_key(+)
                           and t.jianguan_shuhui_bz = a26.item_key(+)
                           and t.pd_verify_person = a27.item_key(+)
                           and t.pd_desiner_name = a28.item_key(+)
                           and t.investmanage_name = a29.item_key(+)
                           and t.ywry_name = a30.item_key(+)
                           and t.pd_cpqx = a31.item_key(+)
                           and t.pd_tongyezs = a32.item_key(+)
                           and t.pd_setholdtime = a33.item_key(+)
                           and t.pd_tzshouy_dzr = a34.item_key(+)
                           and t.pd_xjmanagertype = a35.item_key(+)
                           and t.pd_tzbenjin_dzr = a36.item_key(+)
                           and t.pd_freeback = a37.item_key(+)
                           and t.jianguan_tuoguan_jnei_mc = a38.eb_code(+)
                            """

# 5.产品导出信息
SQL_PRODUCT_EXPORT_QUERY = """
                        select t.pd_code,t.pd_name from fas_prod_info t
                           """

# 获取托管行下拉框数据
SQL_SEL_ESCROW_BANK_QUERY = """ select a.eb_code as id, a.eb_code || '-'||a.eb_name as text from fas_escrow_bank_info a """



# 产品销售信息
SQL_PRODUCT_SALE_INFO_QUERY = """
                            select rownum as rowno,
                                   t.pd_code,
                                   t.pd_name,
                                   t1.pd_colect_money,
                                   t1.pd_person_a,
                                   t1.pd_person_b,
                                   t1.pd_person_c,
                                   t1.pd_copr_a,
                                   t1.pd_copr_b,
                                   t1.pd_copr_c,
                                   (case when t1.pd_done_flag='1' then '是' when t1.pd_done_flag='2' then '否' end)  as pd_done_flag
                              from fas_prod_info t, fas_prod_sale_info t1
                             where t.pd_code = t1.pd_code(+)
                               --and t.pd_life_statu = '001'
                              """

# 产品销售信息-总计-分页用
SQL_PRODUCT_SALE_INFO_COUNT_QUERY = """
                            select count(1) as total
                              from fas_prod_info t, fas_prod_sale_info t1
                             where t.pd_code = t1.pd_code(+)
                               --and t.pd_life_statu = '001'
                                    """


# 复制产品信息
SQL_COPY_PRODUCT_INFO = """ select t.pd_code, t.pd_name, t.pd_mode || '#'||a1.item_value as pd_mode, t.pd_zz_code, 
                                   t.pd_type || '#' ||a2.item_value as pd_type,
                                   t.pd_colect_type || '#' ||a3.item_value as pd_colect_type,
                                   t.pd_risk_level || '#' ||a4.item_value as pd_risk_level,
                                   t.pd_profit_type || '#' ||a5.item_value as pd_profit_type,
                                   t.pd_adjust_type|| '#' ||a6.item_value as pd_adjust_type,
                                   t.pd_interest_base|| '#' ||a7.item_value as pd_interest_base,
                                   t.pd_rg_bg_date, t.pd_rg_ov_date, t.pd_fx_b_date, t.pd_sy_b_date, t.pd_open_b_date, t.pd_open_o_date, 
                                   t.pd_ov_date, t.pd_df_date, t.pd_life_statu || '#' || a8.item_value as pd_life_statu,
                                   t.pd_verify_person || '#' || a27.item_value as pd_verify_person,
                                   t.pd_verify_certi,t.pd_desiner_name || '#' || a28.item_value as pd_desiner_name,
                                   t.pd_desiner_certi,t.investmanage_name || '#' || a29.item_value as investmanage_name,t.investmanage_zj,
                                   t.ywry_name || '#' || a30.item_value as ywry_name,
                                   t.ywry_zj_phone,t.ywry_yd_phone,t.ywry_mail,
                                   t.zj_tx || '#' ||a9.item_value as zj_tx,
                                   t.lc_fw_type || '#' ||a10.item_value as lc_fw_type,
                                   t.prod_manager_mode || '#' ||a11.item_value as prod_manager_mode,
                                   t.invest_pz_type || '#' ||a12.item_value as invest_pz_type,
                                   t.dj_fs || '#' ||a13.item_value as dj_fs,
                                   t.tz_zc_type || '#' ||a14.item_value as tz_zc_type,
                                   t.hezuo_mode || '#' ||a15.item_value as hezuo_mode,
                                   t.prod_zengxin_flag || '#' ||a16.item_value as prod_zengxin_flag,
                                   t.prod_zengxin_comp || '#' ||a17.item_value as prod_zengxin_comp,
                                   t.prod_zengxin_xingshi || '#' ||a18.item_value as prod_zengxin_xingshi,t.prod_pingpai, t.prod_qishu, 
                                   t.sale_channel_dif || '#' ||a19.item_value as sale_channel_dif, 
                                   t.touzi_zhonglei_bili,t.jianguan_guanli_fs || '#' ||a20.item_value as jianguan_guanli_fs,
                                   t.jianguan_muji_fs || '#' ||a21.item_value as jianguan_muji_fs,
                                   t.jianguan_kuaijihesuan_fs || '#' ||a22.item_value as jianguan_kuaijihesuan_fs,
                                   t.jianguan_shouyi_bz || '#' ||a23.item_value as jianguan_shouyi_bz,
                                   t.jianguan_benjinbz_bz || '#' ||a24.item_value as jianguan_benjinbz_bz,
                                   t.jianguan_tiqianzhongzhi_bz || '#' ||a25.item_value as jianguan_tiqianzhongzhi_bz,
                                   t.jianguan_shuhui_bz || '#' ||a26.item_value as jianguan_shuhui_bz,t.jianguan_tuoguan_jwai_daima,
                                   jianguan_tuoguan_jnei_mc || '#' || a38.eb_name as jianguan_tuoguan_jnei_mc,
                                   t.jianguan_tuoguan_jwai_gb,t.jianguan_tuoguan_jwai_mc,
                                   t.pd_cpqx || '#' ||a31.item_value as pd_cpqx,
                                   t.pd_tongyezs || '#' ||a32.item_value as pd_tongyezs,
                                   t.pd_setholdtime || '#' ||a33.item_value as pd_setholdtime,t.pd_holddate,
                                   t.pd_tzshouy_dzr || '#' ||a34.item_value as pd_tzshouy_dzr,
                                   t.pd_xjmanagertype || '#' ||a35.item_value as pd_xjmanagertype,
                                   t.pd_beginsalemoney,t.pd_salerate,t.pd_tuoguangrate,t.pd_plancolectmoney,t.pd_investmanagerate,
                                   t.pd_tzbenjin_dzr || '#' ||a36.item_value as pd_tzbenjin_dzr,
                                   t.pd_freeback || '#' ||a37.item_value as pd_freeback,
                                   t.pd_base_rate            
                              from fas_prod_info t,
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_mode') a1, --产品模式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_type') a2,--产品类型
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_colect_type') a3,--募集币种
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_risk_level') a4,--风险等级
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_profit_type') a5,--收益特点
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_adjust_type') a6,--核算方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_interest_base') a7,--计息基数
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_life_statu') a8,   --产品生命状态
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'zj_tx') a9,   --资金投向地
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'lc_fw_type') a10,   --理财服务模式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_manager_mode') a11,   --产品管理模式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'invest_pz_type') a12,   --资产配置方式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'dj_fs') a13,   --产品定价方式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'tz_zc_type') a14,   --投资资产类型 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'hezuo_mode') a15,   --合作模式 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_flag') a16,   --产品增信标识 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_comp') a17,   --产品增信机构 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_xingshi') a18,   --产品增信形式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'sale_channel_dif') a19,   --销售渠道划分
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_guanli_fs') a20,   --管理方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_muji_fs') a21,   --募集方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_kuaijihesuan_fs') a22,   --会计核算方式
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shouyi_bz') a23,   --收益保证标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_benjinbz_bz') a24,   --本金保障标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_tiqianzhongzhi_bz') a25,   --可提前终止标志
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shuhui_bz') a26,    --可赎回权标志    
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_verify_person') a27,    --审批人姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_desiner_name') a28,    --设计人姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'investmanage_name') a29,    --投资经理姓名 
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'ywry_name') a30,    --业务人员姓名  
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_cpqx') a31, --产品期限
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tongyezs') a32, --是否同业专属
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_setholdtime') a33, --设置最短持有期限
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzshouy_dzr') a34, --投资收益到账日
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_xjmanagertype') a35, --是否现金管理类
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzbenjin_dzr') a36, --投资本金到账日
                                   (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_freeback') a37, --自由赎回标识
                                   (select a.eb_code,a.eb_name from fas_escrow_bank_info a) a38 --托管行          
                         where t.pd_mode = a1.item_key(+)
                           and t.pd_type = a2.item_key(+)
                           and t.pd_colect_type = a3.item_key(+)
                           and t.pd_risk_level = a4.item_key(+)
                           and t.pd_profit_type = a5.item_key(+)
                           and t.pd_adjust_type = a6.item_key(+)
                           and t.pd_interest_base = a7.item_key(+)
                           and t.pd_life_statu = a8.item_key(+)
                           and t.zj_tx = a9.item_key(+)
                           and t.lc_fw_type = a10.item_key(+)
                           and t.prod_manager_mode = a11.item_key(+)
                           and t.invest_pz_type = a12.item_key(+)
                           and t.dj_fs = a13.item_key(+)
                           and t.tz_zc_type = a14.item_key(+)
                           and t.hezuo_mode = a15.item_key(+)
                           and t.prod_zengxin_flag = a16.item_key(+)
                           and t.prod_zengxin_comp = a17.item_key(+)
                           and t.prod_zengxin_xingshi = a18.item_key(+)
                           and t.sale_channel_dif = a19.item_key(+)
                           and t.jianguan_guanli_fs = a20.item_key(+)
                           and t.jianguan_muji_fs = a21.item_key(+)
                           and t.jianguan_kuaijihesuan_fs = a22.item_key(+)
                           and t.jianguan_shouyi_bz = a23.item_key(+)
                           and t.jianguan_benjinbz_bz = a24.item_key(+)
                           and t.jianguan_tiqianzhongzhi_bz = a25.item_key(+)
                           and t.jianguan_shuhui_bz = a26.item_key(+)
                           and t.pd_verify_person = a27.item_key(+)
                           and t.pd_desiner_name = a28.item_key(+)
                           and t.investmanage_name = a29.item_key(+)
                           and t.ywry_name = a30.item_key(+)
                           and t.pd_cpqx = a31.item_key(+)
                           and t.pd_tongyezs = a32.item_key(+)
                           and t.pd_setholdtime = a33.item_key(+)
                           and t.pd_tzshouy_dzr = a34.item_key(+)
                           and t.pd_xjmanagertype = a35.item_key(+)
                           and t.pd_tzbenjin_dzr = a36.item_key(+)
                           and t.pd_freeback = a37.item_key(+)
                           and t.jianguan_tuoguan_jnei_mc = a38.eb_code(+) 
                        """







