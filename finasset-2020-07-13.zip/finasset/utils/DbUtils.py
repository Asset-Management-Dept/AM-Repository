from contextlib import contextmanager
from sqlalchemy import text,create_engine
from sqlalchemy.orm import sessionmaker
from config import SQLALCHEMY_DATABASE_URI
'''
author:ruanyemao
date:2020-6-20
descrip:数据库工具类
'''

class DbUtil:

    # 获取会话
    def get_session(self, bind='admin'):
        #engine = db.get_engine(app=db.get_app(), bind=bind)
        engine = create_engine(SQLALCHEMY_DATABASE_URI, pool_size=10, pool_recycle=7200,pool_pre_ping=True, encoding='utf-8')
        Session = sessionmaker(bind=engine)
        self.session = Session()
        return self.session

    @contextmanager
    def auto_commit(self, bind='admin'):
        try:
            self.session = self.get_session(bind=bind)
            yield
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            raise e
        finally:
            self.session.close()

    # 更新
    def Update(self, sql='', params={}):
        session = self.session
        if sql:
            stmt = text(sql)
            if params:
                session.execute(stmt, params)
            else:
                session.execute(stmt)
        else:
            print("SQL为空!")

    # 查询
    def Select(self, sql='', params={}):
        resList = []
        session = self.session
        if sql:
            stmt = text(sql)
            if params:
                for record in session.execute(stmt, params):
                    rowDict = dict((zip(record.keys(), record)))
                    resList.append(rowDict)
                print(resList)
                return resList
            else:
                for record in session.execute(stmt):
                    rowDict = dict((zip(record.keys(), record)))
                    resList.append(rowDict)
                print(resList)
                return resList
        else:
            print("SQL为空!")

    # 关闭会话
    def __del__(self):
        self.session.close()




