import os
import threading
from multiprocessing import Process
from WindPy import w

"""
author:ruanyemao
date:2020-06-30
descrip:该类启动多线程获取wind咨询数据

线程相关知识点：
线程定义：
在程序里一个执行路线就叫做线程,线程是程序执行的最小单位.

多线程
多线程类似于同时执行多个不同程序，多线程运行有如下优点：
 1.使用线程可以把占据长时间的程序中的任务放到后台去处理。
 2.程序的运行速度可能加快在一些等待的任务实现上如用户输入、文件读写和网络收发数据等。在这种情况下我们可以释放一些珍贵的资源如内存占用等等。

守护线程的工作方式类似服务器，只要没有客户端发来请求，就一直运行并且保持空闲，很像是后台。
threading模块建立的线程除了守护线程之外，其余的线程都会在主线程结束之前结束掉。
也就是说一般会先解决非守护线程的，所以相比而言，守护线程好像就“没那么重要”。
设置守护线程使用thread.daemon = True，要在线程启动之前就设置好。

--案例见: https://blog.csdn.net/Jamesjjjjj/article/details/82802987


Python3 通过两个标准库 _thread 和 threading 提供对线程的支持,由于_thread只是为了兼容python2的thread模块,所以推荐使用threading模块实现多线程。
threading提供了如下方法: 
- run(): 用以表示线程活动的方法。 
- start():启动线程活动。 
- join([time]): 等待至线程中止。--threading模块中join()的作用是为了防止子线程没结束主线程就先结束了,将子线程join到主线程中??? 
- isAlive(): 返回线程是否活动的。 
- getName(): 返回线程名。 
- setName(): 设置线程名

Python中使用线程有两种方式：函数方式 或者 用类来包装线程对象

（1）函数方式:
导入threading包
对象名= threading.Thread（target = 函数名） #创建线程对象,返回一个线程对象
对象名.start() #启动线程
示例代码：
def sing(num):
    for i in range(num):
        print("sing%d" % i)
        time.sleep(0.5)

def dance(num):
    for i in range(num):
        print("dancing%d" % i)
        time.sleep(0.5)

def main():
    t_sing = threading.Thread(target=sing, args=(5,))  --主进程创建sing线程对象
    t_dance = threading.Thread(target=dance, args=(6, )) --主进程创建dance线程对象
    t_sing.start()  --启动sing线程
    t_dance.start()  --启动dance线程

if __name__ == '__main__':
    main()  --主进程



（2）继承方式:
导入threading包
创建一个类继承Thread类，重写run方法
创建类对象，调用start()方法创建线程

"""


# 线程类
class GetWindDataThread(threading.Thread):

    # 私有属性,设置wind咨询连接状态
    __connect_statu = False

    # 构造函数,初始化连接windpy
    def __init__(self,threadID,threadName,queque,code):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.threadName = threadName
        self.queque = queque
        self.code = code
        print('------------threadID:'+str(threadID))
        print('------------threadName:' + threadName)
        print('------------code:' + code)
        # 启动windpy
        w.start()
        if w.isconnected():
            self.__connect_statu = True

    # 运行线程
    def run(self):
        # 获取债券信息
        if self.threadName == 'Thread-Get-Bond-Data' and self.__connect_statu == True:
            print('------------开始run---------------')
            self.getbondinfo(self.code)
            print('------------结束run---------------')

    # 获取债券详细信息
    def getbondinfo(self,_bond_code):

        if w.isconnected():
            _WindData = w.wss("020005.IB","fullname,issuerupdated,par,carrydate,outstandingbalance,maturitydate,term,interesttype,paymenttype,actualbenchmark,coupon,paymentdate,interestfrequency,taxrate,redemption_beginning,abs_spv,issuer,us_type","tradeDate=20200629;N=0")
            w.stop() #连接结束后主动关闭,否则会被wind把主线程也给关了
            # 若获取成功则将结果放入队列queque中
            if _WindData.ErrorCode == 0:
                _bond_dict = _WindData.Data
                for item in _bond_dict:
                    self.queque.put(item)
            else:
                self.queque.put('not data')
        else:
            print('------------未连接---------------')


# 进程类
class GetWindDataProcess(Process):

    # 私有属性,设置wind咨询连接状态
    __connect_statu = False

    # 构造函数,初始化连接windpy
    def __init__(self, threadID, threadName, queque, code):
        super().__init__()
        self.threadID = threadID
        self.threadName = threadName
        self.queque = queque
        self.code = code
        print('------------threadID:' + str(threadID))
        print('------------threadName:' + threadName)
        print('------------code:' + code)
        # 启动windpy
        w.start()
        if w.isconnected():
            self.__connect_statu = True

    # 运行线程
    def run(self):
        # 获取债券信息
        if self.threadName == 'Thread-Get-Bond-Data' and self.__connect_statu == True:
                print('------------开始run---------------')
                self.getbondinfo(self.code)
                print('------------结束run---------------')

    # 获取债券详细信息
    def getbondinfo(self, _bond_code):
        if w.isconnected():
            print('------------开始调用wind的方法---------------')
            _WindData = w.wss("020005.IB",
                              "fullname,issuerupdated,par,carrydate,outstandingbalance,maturitydate,term,interesttype,paymenttype,actualbenchmark,coupon,paymentdate,interestfrequency,taxrate,redemption_beginning,abs_spv,issuer,us_type",
                              "tradeDate=20200629;N=0")
            print('------------结束调用wind的方法---------------')
            # 若获取成功则将结果放入队列queque中
            if _WindData.ErrorCode == 0:
                _bond_dict = _WindData.Data
                for item in _bond_dict:
                    self.queque.put(item)
            else:
                self.queque.put('not data')
        else:
            print('------------未连接---------------')























