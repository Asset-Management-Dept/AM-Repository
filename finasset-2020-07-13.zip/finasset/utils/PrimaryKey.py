
from sqlalchemy import text

'''
author:ruanyemao
date:2020-07-08
descrip:数据库主键类,主要用于从数据库序列中获取唯一ID
'''

class PrimaryKey():


    # 构造函数
    def __init__(self,_session):

        self.session = _session


    # 获得档案管理表的主键
    def getArchivesPrimaryKey(self):

        sql_archives_primary_key = """ select to_char(sysdate,'yyyymmdd') || seq_archives.nextval as seq_archives from dual """

        try:
            resultproxy = self.session.execute(text(sql_archives_primary_key))

            _results_tup = resultproxy.fetchone() # 数据结果为元组: (val1,val2,val3,val4,....)

            _return_pk = _results_tup[0]

            return _return_pk

        except Exception as e:
            print(e)

            return "exception"
