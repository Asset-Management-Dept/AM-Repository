// 全局变量
var editIndex = undefined;

function endEditing() {
    if (editIndex == undefined) {
        return true
    }
    //validateRow:验证指定的行，有效时返回 true : 验证所选定的行索引是否是前面所编辑的行??
    if ($('#dd').datagrid('validateRow', editIndex)) {
        //return true;
    } else {
        return false;
    }
}


/*点击行时触发*/
function onClickRow(index) {

    if (editIndex != index) {
        if (endEditing()) {
            $('#dd').datagrid('selectRow', index).datagrid('beginEdit', index); //selectRow:选中一行，行索引从 0 开始, beginEdit:开始对一行进行编辑。
            editIndex = index;//赋值给 editIndex , 表示正在编辑的行索引
        } else {
            $.messager.alert({title: "错误提示", msg: "请先点击保存按钮后再编辑下一行!", icon: "warning"});
            $('#dd').datagrid('selectRow', editIndex).datagrid('beginEdit', editIndex);
        }
    }
}


/*保存*/
function accept_archives() {

    if (editIndex == undefined) {
        $.messager.alert({title: "错误提示", msg: "未检测到输入!", icon: "warning"});
    } else {

        $('#dd').datagrid('endEdit', editIndex); //结束行的编辑
        var rows = $('#dd').datagrid('getChanges');//获取最后一次提交以来更改的行
        var _pd_code = rows[0].pd_code;
        var _archi_a = rows[0].archi_a;
        var _archi_b = rows[0].archi_b;
        var _archi_c = rows[0].archi_c;
        var _archi_d = rows[0].archi_d;
        var _archi_e = rows[0].archi_e;
        var _archi_f = rows[0].archi_f;
        var _archi_g = rows[0].archi_g;
        var _archi_h = rows[0].archi_h;
        var _archi_i = rows[0].archi_i;
        var _archi_j = rows[0].archi_j;

        var _post_json_data = {
            "pd_code": _pd_code,
            "archi_a": _archi_a,
            "archi_b": _archi_b,
            "archi_c": _archi_c,
            "archi_d": _archi_d,
            "archi_e": _archi_e,
            "archi_f": _archi_f,
            "archi_g": _archi_g,
            "archi_h": _archi_h,
            "archi_i":_archi_i,
            "archi_j":_archi_j
        };
        $.post({
            'url': '/opera_manage/save_archives_manage_info',
            'data': JSON.stringify(_post_json_data),
            'success': function (result) {
                if (result == '200') {
                    alert("保存成功!");
                }
                if (result == '400') {
                    alert("更新成功!");
                }
                $('#dd').datagrid('acceptChanges');//提交自从被加载以来或最后一次调用 acceptChanges 以来所有更改的数据。
                editIndex = undefined;
            },
            'fail': function (error) {
                $.messager.alert({title: "result", msg: error, icon: "warning"});
            }
        });
    }
}


/*初始载入页面加载数据*/
$(function () {
    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/opera_manage/archives_manage_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/opera_manage/archives_manage_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
});


/*获得控件的值*/
function get_json_value(_pageSize, _pageNumber) {

    var _query_condition = new Map();
    var _pd_code = $('#pd_code').val() == null || $('#pd_code').val() == '' ? '%' : $('#pd_code').val();

    _query_condition.set('pageSize', _pageSize);
    _query_condition.set('pageNumber', _pageNumber);
    _query_condition.set('pd_code', _pd_code);

    let obj = Object.create(null);
    for (let [k, v] of _query_condition) {
        obj[k] = v;
    }

    var _query_json = JSON.stringify(obj);

    return _query_json;

}

/*单笔查询*/
function search_archives_info() {
    editIndex = undefined;
    var _pageNumber = 1;
    var _pageSize = 10;
    var _query_json = get_json_value(_pageSize, _pageNumber);
    $.post({
        'url': '/opera_manage/archives_manage_info',
        'data': _query_json,
        'success': function (_data) {
            var result_json = $.parseJSON(_data);
            $("#dd").datagrid({data: result_json});
            var pager = $("#dd").datagrid("getPager");
            pager.pagination({
                onSelectPage: function (pageNo, pageSize) {
                    var _query_json = get_json_value(pageSize, pageNo);
                    $.post({
                        'url': '/opera_manage/archives_manage_info',
                        'data': _query_json,
                        'success': function (_data) {
                            var next_page_data = $.parseJSON(_data);
                            $("#dd").datagrid("loadData", next_page_data);
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                }
            });
        },
        'fail': function (error) {
            alert(error);
        }
    })
}



















