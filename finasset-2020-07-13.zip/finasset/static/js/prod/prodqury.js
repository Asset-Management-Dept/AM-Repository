
/*页面初始化日期组件*/
//自定义颜色
laydate.render({
    elem: '#fx_b_date',
    theme: 'molv',
    format: 'yyyyMMdd'
});



/*ajax获得产品信息*/
$(function () {
    $("#prod-query-btn").click(function (event) {
        event.preventDefault();
        var _pageNumber = 1;
        var _pageSize = 10;
        var _query_json = get_json_value(_pageSize, _pageNumber);
        $.post({
            'url': '/prod_manage/prodqury',
            'data': _query_json,/*{'prod_code':_prod_code, 'prod_life_statu':_prod_life_statu, 'pageNumber':_pageNumber, 'pageSize':_pageSize},*/
            //远程请求数据成功
            'success': function (_data) {

                var result_json = $.parseJSON(_data); //先将返回来的json字符串转化为json对象
                $("#dd").datagrid({data: result_json});
                var pager = $("#dd").datagrid("getPager");
                pager.pagination({
                    //当用户选择新的页面时触发
                    onSelectPage: function (pageNo, pageSize) {
                        var _query_json = get_json_value(pageSize, pageNo);
                        //重新远程请求数据载入数据
                        $.post({
                            'url': '/prod_manage/prodqury',
                            'data': _query_json, //{'prod_code':_prod_code, 'prod_life_statu':_prod_life_statu, 'pageNumber':pageNo, 'pageSize':pageSize},
                            'success': function (_data) {
                                var next_page_data = $.parseJSON(_data);
                                $("#dd").datagrid("loadData", next_page_data);
                            },
                            'fail': function (error) {
                                alert(error);
                            }
                        });
                    }
                });
            },
            'fail': function (error) {
                alert(error);
            }
        })
    })
});


/*右键弹出菜单:编辑、查看、删除*/
$(function () {
    $('#dd').datagrid({
        onRowContextMenu: function (e, rowIndex, rowData) {
            e.preventDefault(); //阻止浏览器捕获右键事件
            $(this).datagrid("clearSelections"); //取消所有选中项
            $(this).datagrid("selectRow", rowIndex); //根据索引选中该行
            $('#menu').menu('show', {left: e.pageX, top: e.pageY});
            //给右键菜单增加click事件响应
            $('#menu').menu({
                onClick: function (item) {
                    //查看产品详情
                    if (item.name == 'query') {
                        get_product_details(rowData.pd_code, rowIndex);
                    }
                    //修改产品信息
                    if (item.name == 'modify') {
                        Modif_product_info(rowData.pd_code, rowIndex);
                    }
                    //删除产品信息
                    if (item.name == 'delete') {
                        del_product_info(rowData.pd_code, rowIndex);
                    }
                    //导出产品信息
                    if (item.name == 'export') {
                        export_product_info(rowData.pd_code, rowIndex);
                    }
                    //复制产品信息
                    if (item.name == 'Copy') {
                        copy_product_info(rowData.pd_code, rowIndex);
                    }
                }
            });
            e.preventDefault(); //阻止浏览器自带的右键菜单弹出
        }
    });
});


/*查看产品详细信息*/
function get_product_details(primary_key, rowIndex) {
    var content = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_details_info?primary_key=' + primary_key + '" style="width:100%;height:600px;"></iframe>';
    $('#win').window({
        title: "【查看】产品详细信息",
        width: '100%',
        height: 'auto',
        modal: true,
        content: content
    });

}


/*删除产品信息*/
function del_product_info(primary_key, rowIndex) {

    $.messager.confirm('Confirm', '确认要删除吗?', function (r) {
        //点击确实时执行
        if (r) {
            var jsonstr = {'primary_key': primary_key};
            $.post({
                'url': '/prod_manage/delete_product_info',
                'data': JSON.stringify(jsonstr),
                'success': function (_data) {
                    if (_data == '200') {
                        $("#dd").datagrid("deleteRow", rowIndex);
                        $.messager.alert({title: "result", msg: '删除成功!', icon: "info"});
                    }
                },
                'fail': function (error) {
                    alert(error);
                }
            })
        }
    });
}


/*导出产品信息*/
function export_product_info(primary_key, rowIndex) {

    var datvlue = $('#fx_b_date').val();//获得值
    var setdatvalue = $('#fx_b_date').val('20200501');//设置值

}


/*复制产品信息*/
function copy_product_info(primary_key, rowIndex) {

    var title = '[复制]产品信息';
    var contents = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_info_collect?primary_key='+primary_key+'&request_type=copy" style="width:100%;height:750px;"></iframe>';
    if (parent.$('#maintab').tabs('exists', title)) {
        parent.$('#maintab').tabs('select', title);
    } else {
        //重新建立一个tab页
        parent.$('#maintab').tabs('add', {
            title: title,
            content: contents,
            closable: true
        });
    }
}


/*修改产品信息*/
function Modif_product_info(primary_key, rowIndex) {

    /*var content = '<iframe scrolling="auto" frameborder="0"  src="/prod_manage/prod_update_info?primary_key=' + primary_key + '" style="width:100%;height:600px;"></iframe>';
    $('#win').window({
        title: "【更新】产品信息",
        width: '100%',
        height: 'auto',
        modal: true,
        content: content,
        onClose: function () {
            //do nothing
        }
    });*/

    var title = '[修改]产品信息';
    var contents = '<iframe scrolling="auto" frameborder="0" src="/prod_manage/prod_info_collect?primary_key='+primary_key+'&request_type=modify" style="width:100%;height:750px;"></iframe>';
    if (parent.$('#maintab').tabs('exists', title)) {
        parent.$('#maintab').tabs('select', title);
    } else {
        //重新建立一个tab页
        parent.$('#maintab').tabs('add', {
            title: title,
            content: contents,
            closable: true
        });
    }




}



/*获得控件的值*/
function get_json_value(_pageSize, _pageNumber) {

    var _query_condition = new Map();
    _query_condition.set('pageSize', _pageSize);
    _query_condition.set('pageNumber', _pageNumber);

    //产品代码
    var _prod_code = $('input[name="prod_code"]').val();
    if (_prod_code == null || _prod_code == '') {
        _query_condition.set('prod_code', '%');
    } else {
        _query_condition.set('prod_code', _prod_code);
    }

    //产品模式
    var _prod_mode = $("#prod_mode").val();
    if (_prod_mode == null || _prod_mode == '') {
        _query_condition.set('prod_mode', '%');
    } else {
        _query_condition.set('prod_mode', _prod_mode);
    }

    //募集方式
    var _jianguan_muji_fs = $("#jianguan_muji_fs").val();
    if (_jianguan_muji_fs == null || _jianguan_muji_fs == '') {
        _query_condition.set('jianguan_muji_fs', '%');
    } else {
        _query_condition.set('jianguan_muji_fs', _jianguan_muji_fs);
    }

    //发行成立日期
    var _fx_b_date = $('#fx_b_date').val();
    if (_fx_b_date == null || _fx_b_date == '') {
        _query_condition.set('fx_b_date', '%');
    } else {
        _query_condition.set('fx_b_date', _fx_b_date);
    }

    let obj = Object.create(null);
    for (let [k, v] of _query_condition) {
        obj[k] = v;
    }

    var _query_json = JSON.stringify(obj);

    return _query_json;

}




