from config import db


#1.托管行信息表
class FAS_ESCROW_BANK_INFO(db.Model):

    '托管行信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_escrow_bank_info'

    # 模型对应的字段
    eb_code = db.Column(db.String(40), primary_key=True, autoincrement=True)  # 托管行代码
    eb_name = db.Column(db.String(120))  # 托管行名称
    eb_open_bank_name = db.Column(db.String(120))  # 托管行开户行名称
    eb_account_name = db.Column(db.String(120))  # 开户名
    eb_account_no = db.Column(db.String(120))  # 开户账号
    eb_area = db.Column(db.String(12))  # 所在区域

    # 构造函数
    def __init__(self, eb_code, eb_name, eb_open_bank_name, eb_account_name, eb_account_no, eb_area):
        self.eb_code = eb_code
        self.eb_name = eb_name
        self.eb_open_bank_name = eb_open_bank_name
        self.eb_account_name = eb_account_name
        self.eb_account_no = eb_account_no
        self.eb_area = eb_area



#2.交易对手信息表
class FAS_TRADE_OPPONENTS_INFO(db.Model):

    '交易对手信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_trade_opponents_info'

    # 模型对应的字段
    trade_opponents_code = db.Column(db.String(42), primary_key=True, autoincrement=True)  # 交易对手编号
    trade_opponents_name = db.Column(db.String(120))  # 交易对手名称
    trade_opponents_account_no = db.Column(db.String(120))  # 资金账户
    trade_opponents_account_name = db.Column(db.String(120))  # 资金账户名
    trade_opponents_bank_no = db.Column(db.String(40))  # 支付系统行
    trade_opponents_type = db.Column(db.String(2))  # 机构种类


    # 构造函数
    def __init__(self, _trade_opponents_code, _trade_opponents_name, _trade_opponents_account_no,
                 _trade_opponents_account_name, _trade_opponents_bank_no, _trade_opponents_type):
        self.trade_opponents_code = _trade_opponents_code
        self.trade_opponents_name = _trade_opponents_name
        self.trade_opponents_account_no = _trade_opponents_account_no
        self.trade_opponents_account_name = _trade_opponents_account_name
        self.trade_opponents_bank_no = _trade_opponents_bank_no
        self.trade_opponents_type = _trade_opponents_type

