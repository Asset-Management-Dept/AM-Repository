


# 数据可视化SQL
SQL_MYPAGE_INTI_DATA_VISUALIZED = """
                select substr(t.pd_fx_b_date, 0, 6) as mont, count(1) as cnt
                  from fas_prod_info t
                 group by substr(t.pd_fx_b_date, 0, 6)
                 order by substr(t.pd_fx_b_date, 0, 6)
                      """


#档案风险预警SQL
SQL_MYPAGE_INIT_ARCHIVES_RISK = """ select * from v_risk_prod_unarchives t """




#初始化资产存续期区域SQL
SQL_MYPAGE_INIT_ASSET_CASH_FLOW = """
                        select '1' as rowno, 
                                '今日待确认付息/到期的资产' as mission_name, 
                                count(1) as mission_num 
                          from fas_asset_cash_flow t 
                         where t.pay_date = to_char(sysdate,'yyyymmdd')
                                  """