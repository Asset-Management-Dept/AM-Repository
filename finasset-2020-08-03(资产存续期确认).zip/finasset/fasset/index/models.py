from fasset import db
from werkzeug.security import check_password_hash, generate_password_hash
from flask_login import UserMixin, login_user
from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, PasswordField
from wtforms.validators import DataRequired


# 用户表
class FAS_USERS(db.Model, UserMixin):
    __tablename__ = 'fas_users'

    user_id = db.Column('user_id', db.String(6), primary_key=True)
    user_name = db.Column(db.String(40))
    user_pwd = db.Column(db.String(250), nullable=False)

    # 查询用户是否存在
    @staticmethod
    def query_by_userid(userid):
        return FAS_USERS.query.filter(FAS_USERS.user_id == userid).first()

    def __init__(self, user_id, user_name, user_pwd):
        self.user_id = user_id
        self.user_name = user_name
        self.user_pwd = generate_password_hash(user_pwd)

    def get_id(self):
        return str(self.user_id)  #python3下用str()来代替unicode()

    # 验证密码
    def verify_password(self, pwd):
        return check_password_hash(self.user_pwd, pwd)

    # 修改密码
    def modify_password(self, pwd):
        return generate_password_hash(self.user_pwd, pwd)





# 定义的表单都需要继承自FlaskForm
class LoginForm(FlaskForm):
    # 域初始化时，第一个参数是设置label属性的
    user_id = StringField('user_id', validators=[DataRequired('account is null')])
    user_pwd = PasswordField('user_pwd', validators=[DataRequired('password is null')])
