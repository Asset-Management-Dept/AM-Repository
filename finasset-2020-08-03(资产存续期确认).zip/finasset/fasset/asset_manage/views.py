from fasset.asset_manage import asset_manage  # 获取蓝图
from flask import render_template, request
from flask_login import login_required
from utils.DataTypeEncoder import *
from utils.DbUtils import DbUtil
from utils.PrimaryKey import PrimaryKey
from fasset.asset_manage.models import *
from fasset.prod_manage.models import *
from fasset.opera_manage.models import *
from fasset.asset_manage.SqlConfig import *
from WindPy import w
import json
from sqlalchemy import text




# 资产信息-路由跳转
@asset_manage.route("/asset_route", methods=['POST', 'GET'])
@login_required
def asset_route():

    # get 方法
    if request.method == 'GET':

        # 路由跳转到资产信息主界面
        if request.args.get("flag") == 'asset_all_info':
            return render_template("asset_manage/asset_all_info.html")

        # 路由跳转到[底层资产维护]主界面
        if request.args.get("flag") == 'asset_basement_info':
            return render_template("asset_manage/asset_basement_info.html")

        # 路由跳转到[资产穿透维护]主界面
        if request.args.get("flag") == 'asset_though_info':
            return render_template("asset_manage/asset_though_info.html")

        # 路由跳转到信托计划-录入界面
        if request.args.get("flag") == 'asset_type_trusts_plan':
            _return_json = json.dumps({"access_flag": "new"})
            return render_template("asset_manage/asset_trusts_plan.html", _return_json=_return_json)

        # 路由跳转到券商计划界面-录入界面
        if request.args.get("flag") == 'asset_type_broker_plan':
            return render_template("asset_manage/asset_broker_plan.html")

        # 路由跳转到信托计划-交易界面
        if request.args.get("flag") == 'asset_trusts_plan_deal':
            return render_template("asset_manage/asset_trusts_plan_deal.html")

        # 复制资产信息或者修改资产信息
        if request.args.get("flag") == 'copy' or request.args.get("flag") == 'modify':

            _return_json = _copy_asset_info(request)
            # 复制[信托计划]
            if request.args.get("asset_type") == '资产管理计划(信托计划)':
                return render_template("asset_manage/asset_trusts_plan.html",_return_json = _return_json)
            # 复制[券商计划]
            if request.args.get("asset_type") == '资产管理计划(券商计划)':
                return render_template("asset_manage/asset_broker_plan.html", _return_json=_return_json)

        # 路由跳转到资产交易确认界面
        if request.args.get("flag") == 'asset_trade_info_confirm':
            return render_template("asset_manage/asset_trade_info_confirm.html")

        # 路由跳转到资产收息确认界面
        if request.args.get("flag") == 'asset_interest_confirm':
            return render_template("asset_manage/asset_interest_confirm.html")

        # 路由跳转到资产收息确认界面
        if request.args.get("flag") == 'asset_interest_confirm_today':
            return render_template("asset_manage/asset_interest_confirm_today.html")


    # post 方法
    if request.method == 'POST':

        _form = json.loads(request.get_data(as_text=True))  # 载入json对象

        # 路由跳转到资产信息主界面
        if _form['flag'] == 'asset_all_info_init':

            _asset_code = _form['asset_code']
            _pageSize = _form['pageSize']  # 分页-数据
            _pageNumber = _form['pageNumber']  # 分页-页面数
            _begin = (int(_pageNumber) - 1) * int(_pageSize)
            _over = _begin + int(_pageSize)
            _sql_asset_info_query = SQL_ASSET_ALL_INFO_QUERY  # 档案信息查询sql
            _sql_asset_info_count_query = SQL_ASSET_ALL_INFO_COUNT_QUERY  # 档案信息数量count
            _sql_condition = ""

            # 拼接[资产代码]参数条件
            if _asset_code == '%':
                _sql_condition = _sql_condition + ' and t.asset_code like \'%\' '
            else:
                _sql_condition = _sql_condition + ' and t.asset_code=:asset_code '

            # 分页SQL语句-详细信息
            _sql_asset_info_query_all = """select * from (select * from (""" \
                                           + _sql_asset_info_query \
                                           + _sql_condition + """) where rowno > """ \
                                           + str(_begin) + """) where rowno <=""" \
                                           + str(_over)
            # 分页SQL语句-查询总数
            _sql_count_query_all = _sql_asset_info_count_query + _sql_condition

            try:
                session = DbUtil().get_session()
                resultproxy = session.execute(text(_sql_asset_info_query_all), {"asset_code": _asset_code})
                resulttotal = session.execute(text(_sql_count_query_all), {"asset_code": _asset_code})
                _results_prod_info = resultproxy.fetchall()
                _results_total = resulttotal.fetchall()
                for _rt in _results_total:
                    _return_dict = dict(zip(_rt.keys(), _rt))
                resList = []
                for _rpiq in _results_prod_info:
                    rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
                    resList.append(rowDict_info)
                _return_dict["rows"] = resList
                _return_dict["code"] = "0"
                _return_dict["msg"] = "success"
                _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
                return _result_json

            except Exception as e:
                print(e)
                return "初始化失败!"


# 资产信息维护 - 获取债券信息
@asset_manage.route("/get_bond_info", methods=['POST', 'GET'])
@login_required
def get_bond_info():
    if request.method == 'GET':
        _bond_code = request.args.get("bond_code")
        # 启动windpy
        w.start()
        if w.isconnected():
            _WindData = w.wss(_bond_code,
                              "fullname,issuerupdated,par,couponrate,latestpar,carrydate,maturitydate,term,interesttype,paymenttype,"
                              "actualbenchmark,coupon,abs_industry,abs_industry1,abs_province,net_cfets,dirty_cfets",
                              "tradeDate=20200701")
            w.stop()
            # 若获取成功则将结果放入队列queque中
            if _WindData.ErrorCode == 0:
                _bond_data = _WindData.Data
                _bond_field = _WindData.Fields
                _bond_data_list = []
                for _i in _bond_data:
                    _bond_data_list.append(_i[0])
                # 将两个列表转化为dict(x,y),x=[x1,x2,x3],y=[y1,y2,y3] -> dict = {"x1":"y1","x2","y2","x3":"y3"}
                _bonddict = dict(zip(_bond_field, _bond_data_list))

                for k, v in _bonddict.items():
                    print('------------', k, ':', v)

            else:
                _bonddict = {"wind", "not data"}
        else:
            print('------------未连接---------------')
        _resultjson = json.dumps(_bonddict, cls=DateEncoder)

        return _resultjson
    else:
        return ""


# 资产信息维护 - 资管计划-信托计划 - 保存：新增(new)-修改(modify)-复制(copy)
@asset_manage.route("/save_asset_trusts_plan", methods=['POST', 'GET'])
@login_required
def save_asset_trusts_plan():

    if request.method == 'POST':

        _asset_trusts_plan_form = json.loads(request.get_data(as_text=True))  # 载入json对象

        _operation_type = _asset_trusts_plan_form['operation_type']  # 新增(new)-修改(modify)-复制(copy

        items = _asset_trusts_plan_form.items()
        for key, value in items:
            print('---------------------------前台传递过来的参数：' + str(key) + '=' + str(value))

        # 基本信息
        _asset_hs_fs = _asset_trusts_plan_form['asset_hs_fs']  #
        _asset_code = _asset_trusts_plan_form['asset_code']  #
        _asset_name = _asset_trusts_plan_form['asset_name']  #
        _asset_qx_date = _asset_trusts_plan_form['asset_qx_date']  #
        _asset_dq_date = _asset_trusts_plan_form['asset_dq_date']  #
        _asset_pay_freq = _asset_trusts_plan_form['asset_pay_freq']  #
        _asset_rate = _asset_trusts_plan_form['asset_rate']  #
        _asset_adjust_base = _asset_trusts_plan_form['asset_adjust_base']  #
        _asset_first_pay_date = _asset_trusts_plan_form['asset_first_pay_date']  #
        _asset_bz = _asset_trusts_plan_form['asset_bz']  #
        _asset_kj_km = _asset_trusts_plan_form['asset_kj_km']  #
        _asset_though = _asset_trusts_plan_form['asset_though']  #
        _asset_manage_type = _asset_trusts_plan_form['asset_manage_type']  #
        _asset_expect_flag = _asset_trusts_plan_form['asset_expect_flag']  #
        _asset_manager_name = _asset_trusts_plan_form['asset_manager_name']  #
        _asset_tg_people = _asset_trusts_plan_form['asset_tg_people']  #
        _asset_mj_money = _asset_trusts_plan_form['asset_mj_money']  #
        _asset_tg_rate = _asset_trusts_plan_form['asset_tg_rate']  #
        _asset_rh_code = _asset_trusts_plan_form['asset_rh_code']  #
        _asset_fxjg_type = _asset_trusts_plan_form['asset_fxjg_type']  #
        _asset_note = _asset_trusts_plan_form['asset_note']  #

        # 定义模型对象
        fas_asset_trusts_plan = FAS_ASSET_TRUSTS_PLAN(_asset_hs_fs, _asset_code, _asset_name, _asset_qx_date,
                                                      _asset_dq_date, _asset_pay_freq,
                                                      _asset_rate, _asset_adjust_base, _asset_first_pay_date, _asset_bz,
                                                      _asset_kj_km, _asset_though,
                                                      _asset_manage_type, _asset_expect_flag, _asset_manager_name,
                                                      _asset_tg_people, _asset_mj_money,
                                                      _asset_tg_rate, _asset_rh_code, _asset_fxjg_type, _asset_note)
        _handle_result = ''

        # 新增产品、复制产品
        if _operation_type == 'new' or _operation_type == 'copy':
            _handle_result = _save_new_and_copy_asset_trusts_plan(fas_asset_trusts_plan,_operation_type)

        # 修改产品
        if _operation_type == 'modify':
            _handle_result = _save_modify_asset_trusts_plan(fas_asset_trusts_plan)

        return _handle_result


#资产信息删除
@asset_manage.route("/delete_asset_info", methods=['POST', 'GET'])
@login_required
def delete_asset_info():

    if request.method == 'POST':
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _asset_code = _json['asset_code']
        _asset_type = _json['asset_type']
        _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）
        db.create_all()  # 创建数据库
        if _asset_type == '资产管理计划(信托计划)':
            try:
                _fas_asset_trusts_plan_obj = FAS_ASSET_TRUSTS_PLAN.query.filter(FAS_ASSET_TRUSTS_PLAN.asset_code == _asset_code).first()
                db.session.delete(_fas_asset_trusts_plan_obj)
                db.session.commit()
                print('--------------删除成功')
                return "200"
            except Exception as e:
                db.session.rollback()
                print(e)
                print('--------------删除失败')
                return "300"


# 动态获得select下拉框数据
@asset_manage.route("/get_sel_data", methods=['POST', 'GET'])
def get_sel_data():
    _dict_code = request.args.get(key='dict_code')

    if _dict_code == 'asset_name_trusts_plan':  # 信托资产信息下拉框数据
        _sql_main = SQL_SEL_TRUSTS_PLAN_QUERY
        _sql_all = _sql_main

    elif _dict_code == 'opponents_name':  # 交易对手下拉框数据
        _sql_main = SQL_SEL_OPPONENTS_QUERY
        _sql_all = _sql_main

    elif _dict_code == 'asset_product_info':  # 理财产品下拉框数据
        _sql_main = SQL_PRODUCT_INFO_QUERY
        _sql_all = _sql_main

    elif _dict_code == 'asset_all_info': # 资产信息维护界面下拉框
        _sql_main = SQL_SEL_ASSET_ALL_INFO_QUERY
        _sql_all = _sql_main

    else:
        _sql_main = SQL_SEL_DATA_QUERY
        _sql_condition = ' where a.dict_code=:val order by a.dict_code,a.item_key '
        _sql_all = _sql_main + _sql_condition

    print('_dict_code',_dict_code,'_sql_all------------',_sql_all)

    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_all), {"val": _dict_code})
    except Exception as e:
        print(e)
    else:
        _results = resultproxy.fetchall()

    resList = []
    for _result in _results:
        rowDict = dict(zip(_result.keys(), _result))
        resList.append(rowDict)

    _result_json = json.dumps(resList)

    print('--------------------返回数据：' + _result_json)

    return _result_json



# 获得信托计划的详细信息
@asset_manage.route("/get_asset_trusts_plan_details_data", methods=['POST', 'GET'])
@login_required
def get_asset_trusts_plan_details_data():
    _asset_code = request.args.get(key='asset_code')
    _sql_main = SQL_ASSET_TRUSTS_PLAN_DETAILS_INFO_QUERY
    _sql_condition = ' and t.asset_code=:asset_code '
    _sql_all = _sql_main + _sql_condition
    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_all), {"asset_code": _asset_code})
        _results = resultproxy.fetchall()
        for _result in _results:
            rowDict = dict(zip(_result.keys(), _result))
        _result_json = json.dumps(rowDict,cls=DecimalEncoder)
        print('--------------------返回数据：' + _result_json)
        return _result_json
    except Exception as e:
        print(e)



# 获得产品的余额信息
@asset_manage.route("/get_product_balance_data", methods=['POST', 'GET'])
@login_required
def get_product_balance_data():
    _product_code = request.args.get(key='product_code')
    _sql_main = SQL_PRODUCT_BALANCE_INFO_QUERY
    _sql_condition = ' and t.pd_code=:pd_code '
    _sql_all = _sql_main + _sql_condition
    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_all), {"pd_code": _product_code})
        _results = resultproxy.fetchall()
        for _result in _results:
            rowDict = dict(zip(_result.keys(), _result))
        _result_json = json.dumps(rowDict,cls=DecimalEncoder)
        print('--------------------返回数据：' + _result_json)
        return _result_json
    except Exception as e:
        print(e)


# 资管计划-信托计划 - 交易保存
@asset_manage.route("/commit_asset_trusts_plan_deal", methods=['POST','GET'])
@login_required
def commit_asset_trusts_plan_deal():

    if request.method == 'POST':

        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        # 交易要素
        _asset_deal_date = _json['asset_deal_date']  # 交易日期
        _asset_deal_dirt = _json['asset_deal_dirt']  # 交易方向
        _asset_code = _json['asset_code']  # 资产名称
        _opponents_code = _json['opponents_code']  # 交易面额(元)
        _asset_deal_money = _json['asset_deal_money']  # 交易收益率( %)
        _asset_deal_rate = _json['asset_deal_rate']  # 结算金额(元)
        _asset_js_money = _json['asset_js_money']  # 应计利息总额(元)
        _asset_intervest_total = _json['asset_intervest_total']  #
        _kjfl_type = _json['kjfl_type']  # 会计分类
        _asset_prod_code = _json['asset_prod_code']  # 理财产品
        _asset_prod_ye = _json['asset_prod_ye']  # 产品余额
        _asset_note = _json['asset_note']  # 备注

        # 资产要素
        _asset_qx_date = _json['asset_qx_date'] # 起息日
        _asset_dq_date = _json['asset_dq_date'] # 到期日
        _asset_first_pay_date = _json['asset_first_pay_date']# 首次付息日
        _asset_pay_freq = _json['asset_pay_freq']# 付息频率
        _asset_rate = _json['asset_rate']  # 收益率 %
        _asset_kj_km = _json['asset_kj_km'] # 核心会计科目
        _asset_adjust_base = _json['asset_adjust_base'] # 计息基数

        _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）


        session = DbUtil().get_session() # 获得数据库会话
        primaryobj = PrimaryKey(session) #获取主键dealid
        _deal_id_pk = primaryobj.get_primary_key() # 从数据库获取主键

        fas_asset_trusts_plan = FAS_ASSET_TRUSTS_PLAN.query.filter(FAS_ASSET_TRUSTS_PLAN.asset_code == _asset_code).first()
        fas_prod_info = FAS_PROD_INFO.query.filter(FAS_PROD_INFO.pd_code == _asset_prod_code).first()

        _asset_name = fas_asset_trusts_plan.asset_name
        _asset_prod_name = fas_prod_info.pd_name

        # 保存交易流水
        fas_asset_trade_info = FAS_ASSET_TRADE_INFO(_deal_id_pk, _asset_deal_date, _asset_deal_dirt, '100003',
                                                    _asset_code, _asset_name,
                                                    _opponents_code, _asset_deal_money, _asset_deal_rate,
                                                    _asset_js_money,
                                                    _asset_intervest_total, _kjfl_type, _asset_prod_code,
                                                    _asset_prod_name, _asset_prod_ye,
                                                    _asset_note, _asset_qx_date, _asset_dq_date, _asset_first_pay_date,
                                                    _asset_pay_freq,
                                                    _asset_rate, _asset_kj_km, _asset_adjust_base,
                                                    '0')  # asset_comfir = 0-未确认, 1-已确认, 2-已撤单 # asset_type = 100003 - 资产管理计划(信托计划)

        session.add(fas_asset_trade_info)

        try:
            session.commit()
            return "交易录入成功!请进行后续交易确认!"
        except Exception as e:
            session.rollback()
            print(e)
            return "交易录入失败!"




# 交易-成交确认-查询
@asset_manage.route("/asset_trade_info_confirm_query", methods=['POST','GET'])
@login_required
def asset_trade_info_confirm_query():

    if request.method == 'POST':
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象

        _asset_type = _json['asset_type']  # 资产负债品种
        _asset_trade_date = _json['asset_trade_date']  # 交易日期
        _pageSize = _json['pageSize']  # 分页-数据
        _pageNumber = _json['pageNumber']  # 分页-页面数

        _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）

        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)

        _sql_asset_trade_info_confirm_query = SQL_ASSET_TRADE_INFO_CONFIRM_QUERY
        _sql_count_query = SQL_ASSET_TRADE_INFO_CONFIRM_COUNT_QUERY
        _sql_condition = ''

        # 拼接查询条件
        if _asset_type == '%':
            _sql_condition = _sql_condition + ' and t.asset_type like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.asset_type =:asset_type '

        # 拼接查询条件
        if _asset_trade_date == '%':
            _sql_condition = _sql_condition + ' and t.asset_deal_date like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.asset_deal_date >=:asset_deal_date '


        # 分页SQL语句-详细信息
        _sql_asset_confirm_query_all = """select * from (select * from (""" \
                                   + _sql_asset_trade_info_confirm_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)

        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_count_query + _sql_condition

        print('----------------------------------------------_sql_asset_confirm_query_all查询语句[1]：' + _sql_asset_confirm_query_all)

        print('----------------------------------------------_sql_count_query_all查询语句[2]：：' + _sql_count_query_all)

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_asset_confirm_query_all),{"asset_type": _asset_type, "asset_deal_date": _asset_trade_date})

            resulttotal = session.execute(text(_sql_count_query_all),{"asset_type": _asset_type, "asset_deal_date": _asset_trade_date})

            _results_confirm_info = resultproxy.fetchall()
            _results_total = resulttotal.fetchall()

            _return_dict = []

            # 总结果数
            for _rt in _results_total:
                _return_dict = dict(zip(_rt.keys(), _rt))

            resList = []
            # 将明细数压入List
            for _rpiq in _results_confirm_info:
                rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
                resList.append(rowDict_info)

            _return_dict["rows"] = resList
            _return_dict["code"] = "0"
            _return_dict["msg"] = "success"
            _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
            print('----------------------------------------------最终查询返回的结果为：' + _result_json)
            return _result_json

        except Exception as e:
            print(e)




# 交易-成交确认
@asset_manage.route("/asset_trade_info_confirm", methods=['POST', 'GET'])
@login_required
def asset_trade_info_confirm():

    # (1)处理产品余额信息表：fas_prod_balance、产品余额交易流水表：fas_prod_balance_deal

    # (2)处理产品交易流水表：fas_asset_trade_info -> asset_confirm = 1-已确认

    # (3)生成现金流-存续期：fas_asset_cash_flow
    # 付息频率、计息基数、起息日、到期日、首次付息日、结算金额、收益率
    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    # 持有天数 = 到期日-起息日
    # 1 按月支付
    # 2 按季支付
    # 3 半年支付
    # 4 按年支付
    # 5 到期支付
    # 6 自定义支付 --暂时不实现-2020-07-30
    # (4)生成档案信息：fas_prod_archives_info
    # (5)记账

    if request.method == 'POST':

        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _deal_id = _json['deal_id']  # 资产负债品种

        _session = DbUtil().get_session()  # 获取数据库会话
        _pkobj = PrimaryKey(_session)
        fas_asset_trade_info = FAS_ASSET_TRADE_INFO.query.filter_by(deal_id=_deal_id).first()
        _asset_deal_dirt = fas_asset_trade_info.asset_deal_dirt #交易方向

        # 资产买入
        if _asset_deal_dirt == '1':
            msg = _asset_buy(fas_asset_trade_info, _session, _pkobj)
            return msg
        # 资产卖出
        elif _asset_deal_dirt == '2':
            msg = _asset_sale(fas_asset_trade_info, _session, _pkobj)
            return msg



# 交易-撤单
@asset_manage.route("/undo_asset_trade_info_confirm", methods=['POST', 'GET'])
@login_required
def undo_asset_trade_info_confirm():

    if request.method == 'POST':
        _json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _deal_id = _json['deal_id']  # 资产负债品种
        fas_asset_trade_info = FAS_ASSET_TRADE_INFO.query.filter(FAS_ASSET_TRADE_INFO.deal_id == _deal_id).first()
        fas_asset_trade_info.asset_comfir = '2'

        try:
            db.session.commit()  # 提交到数据库 -->执行
            return "交易撤单成功!"
        except Exception as e:
            db.session.rollback()  # 回滚数据  -->执行
            print(e)
            return "交易撤单失败!"



# 资产存续期确认查询
@asset_manage.route("/asset_interest_confirm_query", methods=['POST', 'GET'])
@login_required
def asset_interest_confirm_query():

    _json = json.loads(request.get_data(as_text=True))  # 载入json对象
    _asset_code = _json['asset_code']  # 资产负债品种
    _pay_date = _json['pay_date']  # 交易日期
    _pageSize = _json['pageSize']  # 分页-数据
    _pageNumber = _json['pageNumber']  # 分页-页面数

    _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）

    _begin = (int(_pageNumber) - 1) * int(_pageSize)
    _over = _begin + int(_pageSize)

    _sql_asset_interest_confirm_query = SQL_ASSET_INTERVEST_CONFIRM_QUERY
    _sql_count_query = SQL_ASSET_INTERVEST_CONFIRM_CNT_QUERY
    _sql_condition = ''

    # 拼接查询条件
    if _asset_code == '%':
        _sql_condition = _sql_condition + ' and t.asset_code like \'%\' '
    else:
        _sql_condition = _sql_condition + ' and t.asset_code =:asset_code '

    # 拼接查询条件
    if _pay_date == '%':
        _sql_condition = _sql_condition + ' and t.pay_date like \'%\' '
    else:
        _sql_condition = _sql_condition + ' and t.pay_date <=:pay_date '

    # 分页SQL语句-详细信息
    _sql_asset_confirm_query_all = """select * from (select * from (""" \
                                   + _sql_asset_interest_confirm_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)

    # 分页SQL语句-查询总数
    _sql_count_query_all = _sql_count_query + _sql_condition

    print('-------_sql_asset_confirm_query_all查询语句[1]：' + _sql_asset_confirm_query_all)

    print('-----_sql_count_query_all查询语句[2]：' + _sql_count_query_all)

    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_asset_confirm_query_all), {"asset_code": _asset_code, "pay_date": _pay_date})
        resulttotal = session.execute(text(_sql_count_query_all), {"asset_code": _asset_code, "pay_date": _pay_date})
        _results_confirm_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()
        _return_dict = []

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(zip(_rt.keys(), _rt))

        resList = []
        # 将明细数压入List
        for _rpiq in _results_confirm_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
            resList.append(rowDict_info)

        _return_dict["rows"] = resList
        _return_dict["code"] = "0"
        _return_dict["msg"] = "success"
        _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
        print('----------------------------------------------最终查询返回的结果为：' + _result_json)
        return _result_json

    except Exception as e:
        print(e)



# 今日资产存续期确认查询
@asset_manage.route("/asset_interest_confirm_today_query", methods=['POST', 'GET'])
@login_required
def asset_interest_confirm_today_query():

    _json = json.loads(request.get_data(as_text=True))  # 载入json对象
    _pageSize = _json['pageSize']  # 分页-数据
    _pageNumber = _json['pageNumber']  # 分页-页面数

    _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）

    _begin = (int(_pageNumber) - 1) * int(_pageSize)
    _over = _begin + int(_pageSize)

    _sql_asset_interest_confirm_td_query = SQL_ASSET_INTERVEST_CONFIRM_TODAY_QUERY
    _sql_count_query = SQL_ASSET_INTERVEST_CONFIRM_TODAY_CNT_QUERY
    _sql_condition = ''

    # 分页SQL语句-详细信息
    _sql_asset_confirm_query_all = """select * from (select * from (""" \
                                   + _sql_asset_interest_confirm_td_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)

    # 分页SQL语句-查询总数
    _sql_count_query_all = _sql_count_query + _sql_condition


    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_asset_confirm_query_all))
        resulttotal = session.execute(text(_sql_count_query_all))
        _results_confirm_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()
        _return_dict = []

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(zip(_rt.keys(), _rt))

        resList = []
        # 将明细数压入List
        for _rpiq in _results_confirm_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))
            resList.append(rowDict_info)

        _return_dict["rows"] = resList
        _return_dict["code"] = "0"
        _return_dict["msg"] = "success"
        _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
        print('----------------------------------------------最终查询返回的结果为：' + _result_json)
        return _result_json

    except Exception as e:
        print(e)


# 资产存续期-延期
@asset_manage.route("/asset_interest_confirm_delayed", methods=['POST', 'GET'])
@login_required
def asset_interest_confirm_delayed():
    _json = json.loads(request.get_data(as_text=True))  # 载入json对象
    _deal_id = _json['deal_id']
    _flow_id = _json['flow_id']
    _delay_date = _json['delay_date']

    _print_front_json(_json) #打印前台传递过来的参数（开发调试使用）

    fas_asset_trade_info = FAS_ASSET_TRADE_INFO.query.filter_by(deal_id=_deal_id).first()
    fas_asset_cash_flow = FAS_ASSET_CASH_FLOW.query.filter_by(flow_id=_flow_id).first()








    return ""









#资产买入
def _asset_buy(fas_asset_trade_info, _session, _pkobj):

    _deal_id = fas_asset_trade_info.deal_id
    _asset_deal_date = fas_asset_trade_info.asset_deal_date
    _asset_code = fas_asset_trade_info.asset_code
    _asset_name = fas_asset_trade_info.asset_name
    _asset_deal_money = fas_asset_trade_info.asset_deal_money
    _asset_deal_rate = fas_asset_trade_info.asset_deal_rate
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_prod_code = fas_asset_trade_info.asset_prod_code
    _asset_prod_name = fas_asset_trade_info.asset_prod_name
    _asset_qx_date = fas_asset_trade_info.asset_qx_date
    _asset_dq_date = fas_asset_trade_info.asset_dq_date
    _asset_pay_freq = fas_asset_trade_info.asset_pay_freq
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _asset_comfir = fas_asset_trade_info.asset_comfir

    fas_prod_balance = FAS_PROD_BALANCE.query.filter_by(pd_code=_asset_prod_code).first()
    _pd_balance = fas_prod_balance.pd_balance

    if _asset_js_money > _pd_balance:

        return "产品余额不足,无法成交确认!"

    else:

        # 【更新】处理产品余额表：fas_prod_balance
        _balance = _pd_balance - _asset_js_money  # 交易后产品余额
        fas_prod_balance.pd_balance = _balance  # 更新产品余额表：fas_prod_balance 的余额
        try:
            db.session.commit()  # 提交更新
        except Exception as e:
            db.session.rollback()
            return "更新产品余额表报错!"

        # 【插入】处理产品余额交易表：fas_prod_balance_deal
        _pk = _pkobj.get_primary_key()
        fas_prod_balance_deal = FAS_PROD_BALANCE_DEAL(_pk, _asset_prod_code, _asset_deal_date,
                                                      '002', _asset_js_money, _balance)  # deal_type = 002-对外投资
        try:
            _session.add(fas_prod_balance_deal)  # 插入记录
            _session.commit()  # 提交更新
        except Exception as e:
            _session.rollback()
            return "插入产品余额交易表报错!"

        # 【更新】处理产品交易流水表：fas_asset_trade_info -> asset_confirm = 1-已确认
        fas_asset_trade_info.asset_comfir = '1'
        try:
            db.session.commit()  # 提交更新
        except Exception as e:
            db.session.rollback()
            return "更新产品交易流水表报错!"

        # 【插入】生成档案信息：fas_prod_archives_info
        # 交易成交确认后，也一并创建该产品的档案管理数据，默认所有的档案均未归档，值设置为2
        _pk = _pkobj.get_primary_key()
        fas_prod_archives_info = FAS_PROD_ARCHIVES_INFO(_pk, _deal_id, _asset_prod_code, _asset_prod_name,
                                                        _asset_code, _asset_name, '2', '2', '2', '2', '2',
                                                        '2', '2', '2', '2', '2')
        try:
            _session.add(fas_prod_archives_info)  # 插入记录
            _session.commit()  # 提交数据
        except Exception as e:
            _session.rollback()
            return "生成档案信息报错!"

        # (3)生成现金流-存续期：fas_asset_cash_flow
        #   flow_id-主键、deal_id-交易ID、asset_code-资产代码、asset_name-资产名称
        #   pay_date-支付日期、theory_cost-理论发生额、reality_cost-实际发生额
        #   is_confirm-现金确认：0 - 未确认，1 - 已确认
        #  实现逻辑如下：
        #  1、计算：资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
        #  2、根据[付息频率]，依次生成现金流
        #  3、例如起息日：2020-07-01，到期日：2021-07-01
        #       按月支付：
        #           计算2020-07-01 ~ 2021-07-01共有x月，然后[资产投资收益]/x=每个月的应付利息

        # 按月支付-1
        if _asset_pay_freq == '1':
            _asset_pay_by_month(fas_asset_trade_info, _pkobj, _session)

        # 按季支付-2
        if _asset_pay_freq == '2':
            _asset_pay_by_quarter(fas_asset_trade_info, _pkobj, _session)

        # 半年支付-3
        if _asset_pay_freq == '3':
            _asset_pay_by_half_years(fas_asset_trade_info, _pkobj, _session)

        # 按年支付-4
        if _asset_pay_freq == '4':
            _asset_pay_by_year(fas_asset_trade_info, _pkobj, _session)

        # 到期支付-5
        if _asset_pay_freq == '5':
            _asset_pay_by_end(fas_asset_trade_info, _pkobj, _session)


        # (4)生成资产余额表：fas_asset_balance
        fas_asset_balance = FAS_ASSET_BALANCE(_asset_code, _asset_js_money, '001')  #asset_life_status=001-持有中
        try:
            _session.add(fas_asset_balance)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成资产余额表报错!"



        # (5)生成资产余额交易流水表：fas_asset_balance_deal
        _pk = _pkobj.get_primary_key()
        fas_asset_balance_deal = FAS_ASSET_BALANCE_DEAL(_pk, _deal_id, _asset_code, _asset_name, _asset_deal_date,
                                                        '001', _asset_js_money, _asset_js_money) #deal_type=001-资产买入
        try:
            _session.add(fas_asset_balance_deal)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成资产余额流水表报错!"


        return "确认成功!"



#资产卖出
def _asset_sale(fas_asset_trade_info, _session, _pkobj):


    return ""




# 复制资产信息或修改资产信息 - 获得信息
def _copy_asset_info(request):

    _asset_code = request.args.get("asset_code")
    # 复制信托计划
    if request.args.get("asset_type") == '资产管理计划(信托计划)':
        _sql_copy_asset_trusts_plan = SQL_COPY_ASSET_TRUSTS_PLAN + ' and t.asset_code=:asset_code'
        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_copy_asset_trusts_plan), {"asset_code": _asset_code})
            _results_details_info = resultproxy.fetchall()
            _return_dict = {}
            for _rt in _results_details_info:
                _return_dict = dict(zip(_rt.keys(),_rt))
            _return_dict["access_flag"] = request.args.get("flag")
            _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
            return _result_json
        except Exception as e:
            print(e)
            return "failed"



# 保存：新增资产信息或复制资产信息
def _save_new_and_copy_asset_trusts_plan(fas_asset_trusts_plan,_operation_type):

    session = DbUtil().get_session()
    session.add(fas_asset_trusts_plan)
    try:

        session.commit()  # 提交到数据库 -->执行
        if _operation_type == 'new':
            return "资产信息新增成功!"
        if _operation_type == 'copy':
            return "资产信息复制成功!"

    except Exception as e:

        session.rollback()  # 回滚数据  -->执行
        print(e)
        if _operation_type == 'new':
            return "资产信息新增失败!"
        if _operation_type == 'copy':
            return "资产信息复制失败!"



# 保存：修改资产信息
def _save_modify_asset_trusts_plan(fas_asset_trusts_plan_new):
    # 创建数据库
    db.create_all()
    # 获得对象
    fas_asset_trusts_plan_old = FAS_ASSET_TRUSTS_PLAN.query.filter(FAS_ASSET_TRUSTS_PLAN.asset_code == fas_asset_trusts_plan_new.asset_code).first()

    fas_asset_trusts_plan_old.asset_hs_fs = fas_asset_trusts_plan_new.asset_hs_fs
    fas_asset_trusts_plan_old.asset_name = fas_asset_trusts_plan_new.asset_name
    fas_asset_trusts_plan_old.asset_qx_date = fas_asset_trusts_plan_new.asset_qx_date
    fas_asset_trusts_plan_old.asset_dq_date = fas_asset_trusts_plan_new.asset_dq_date
    fas_asset_trusts_plan_old.asset_pay_freq = fas_asset_trusts_plan_new.asset_pay_freq
    fas_asset_trusts_plan_old.asset_rate = fas_asset_trusts_plan_new.asset_rate
    fas_asset_trusts_plan_old.asset_adjust_base = fas_asset_trusts_plan_new.asset_adjust_base
    fas_asset_trusts_plan_old.asset_first_pay_date = fas_asset_trusts_plan_new.asset_first_pay_date
    fas_asset_trusts_plan_old.asset_bz = fas_asset_trusts_plan_new.asset_bz
    fas_asset_trusts_plan_old.asset_kj_km = fas_asset_trusts_plan_new.asset_kj_km
    fas_asset_trusts_plan_old.asset_though = fas_asset_trusts_plan_new.asset_though
    fas_asset_trusts_plan_old.asset_manage_type = fas_asset_trusts_plan_new.asset_manage_type
    fas_asset_trusts_plan_old.asset_expect_flag = fas_asset_trusts_plan_new.asset_expect_flag
    fas_asset_trusts_plan_old.asset_manager_name = fas_asset_trusts_plan_new.asset_manager_name
    fas_asset_trusts_plan_old.asset_tg_people = fas_asset_trusts_plan_new.asset_tg_people
    fas_asset_trusts_plan_old.asset_mj_money = fas_asset_trusts_plan_new.asset_mj_money
    fas_asset_trusts_plan_old.asset_tg_rate = fas_asset_trusts_plan_new.asset_tg_rate
    fas_asset_trusts_plan_old.asset_rh_code = fas_asset_trusts_plan_new.asset_rh_code
    fas_asset_trusts_plan_old.asset_fxjg_type = fas_asset_trusts_plan_new.asset_fxjg_type
    fas_asset_trusts_plan_old.asset_note = fas_asset_trusts_plan_new.asset_note

    # 处理异常
    try:
        db.session.commit()  # 提交到数据库 -->执行
        return "资产信息修改成功!"
    except Exception as e:
        db.session.rollback()  # 回滚数据  -->执行
        print(e)
        return "资产信息修改失败!"




#按月付息
def _asset_pay_by_month(fas_asset_trade_info, _pkobj, _session):

    _qx_date = fas_asset_trade_info.asset_qx_date
    _dq_date = fas_asset_trade_info.asset_dq_date
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _deal_id = fas_asset_trade_info.deal_id
    _code = fas_asset_trade_info.asset_code
    _name = fas_asset_trade_info.asset_name

    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    _qx_format = datetime.date(int(_qx_date[0:4]), int(_qx_date[4:6]), int(_qx_date[6:8]))  # 起息日
    _dq_format = datetime.date(int(_dq_date[0:4]), int(_dq_date[4:6]), int(_dq_date[6:8]))  # 到期日
    _hold_days = days_minus(_dq_format, _qx_format) # 持有天数

    _hold_months = months_minus(_dq_format, _qx_format)  # 起息日与到期日间隔的月数 - 用于循环

    _intervest = (_asset_js_money * (_asset_rate / 100)) / int(_asset_adjust_base) * _hold_days # 资产投资收益（利息）

    _v_day = _qx_format
    _v_months = _hold_months

    while _v_months > 0:
        _pk = _pkobj.get_primary_key()
        pay_date = _get_next_month_days(_v_day)
        is_confirm = '0'
        # 最后一个月本息兑付
        if _v_months == 1:
            theory_cost = _intervest / _hold_months + _asset_js_money
            reality_cost = _intervest / _hold_months + _asset_js_money
            _pay_date = _dq_date
        else:
            theory_cost = _intervest / _hold_months
            reality_cost = _intervest / _hold_months
            _pay_date = pay_date.strftime("%Y%m%d")

        # 会计事件:account_event=003-中间付息
        # 现金确认日期:confirm_date='' 该字段到实际做确认动作的时候才赋值
        _cash_flow = FAS_ASSET_CASH_FLOW(_pk, _deal_id, _code, _name, '003', _pay_date,
                                         theory_cost, reality_cost, is_confirm, '')

        try:
            _session.add(_cash_flow)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成月度现金流报错!"

        _v_months = _v_months - 1
        _v_day = pay_date

    return "200"



#按季付息
def _asset_pay_by_quarter(fas_asset_trade_info, _pkobj, _session):

    _qx_date = fas_asset_trade_info.asset_qx_date
    _dq_date = fas_asset_trade_info.asset_dq_date
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _deal_id = fas_asset_trade_info.deal_id
    _code = fas_asset_trade_info.asset_code
    _name = fas_asset_trade_info.asset_name

    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    _qx_format = datetime.date(int(_qx_date[0:4]), int(_qx_date[4:6]), int(_qx_date[6:8])) # 起息日
    _dq_format = datetime.date(int(_dq_date[0:4]), int(_dq_date[4:6]), int(_dq_date[6:8])) # 到期日
    _hold_days = days_minus(_dq_format, _qx_format) # 持有天数

    _hold_quarters = quarters_minus(_dq_format, _qx_format) # 起息日与到期日间隔的季度数 - 用于循环

    _intervest = (_asset_js_money * (_asset_rate / 100)) / int(_asset_adjust_base) * _hold_days # 资产投资收益（利息）


    _v_day = _qx_format
    _v_quarters = _hold_quarters
    while _v_quarters > 0:
        _pk = _pkobj.get_primary_key()
        pay_date =_get_next_quarter_days(_v_day)
        is_confirm = '0'

        # 最后一个季度本息兑付
        if _v_quarters == 1:
            theory_cost = _intervest / _hold_quarters + _asset_js_money
            reality_cost = _intervest / _hold_quarters + _asset_js_money
            _pay_date = _dq_date
        else:
            theory_cost = _intervest / _hold_quarters
            reality_cost = _intervest / _hold_quarters
            _pay_date = pay_date.strftime("%Y%m%d")

        # 会计事件:account_event=003-中间付息
        # 现金确认日期:confirm_date='' 该字段到实际做确认动作的时候才赋值
        _cash_flow = FAS_ASSET_CASH_FLOW(_pk, _deal_id, _code, _name, '003', _pay_date,theory_cost,
                                         reality_cost, is_confirm, '')

        try:
            _session.add(_cash_flow)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成季度现金流报错!"

        _v_quarters = _v_quarters - 1
        _v_day = pay_date

    return "200"



#按半年支付
def _asset_pay_by_half_years(fas_asset_trade_info, _pkobj, _session):

    _qx_date = fas_asset_trade_info.asset_qx_date
    _dq_date = fas_asset_trade_info.asset_dq_date
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _deal_id = fas_asset_trade_info.deal_id
    _code = fas_asset_trade_info.asset_code
    _name = fas_asset_trade_info.asset_name

    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    _qx_format = datetime.date(int(_qx_date[0:4]), int(_qx_date[4:6]), int(_qx_date[6:8]))  # 起息日
    _dq_format = datetime.date(int(_dq_date[0:4]), int(_dq_date[4:6]), int(_dq_date[6:8]))  # 到期日
    _hold_days = days_minus(_dq_format, _qx_format)  # 持有天数

    _hold_half_years = half_years_minus(_dq_format, _qx_format)  # 起息日与到期日间隔的半年数 - 用于循环

    _intervest = (_asset_js_money * (_asset_rate / 100)) / int(_asset_adjust_base) * _hold_days  # 资产投资收益（利息）

    _v_day = _qx_format
    _v_half_years = _hold_half_years
    while _v_half_years > 0:
        _pk = _pkobj.get_primary_key()
        pay_date = _get_next_half_year_days(_v_day)
        is_confirm = '0'

        # 最后一个半年本息兑付
        if _v_half_years == 1:
            theory_cost = _intervest / _hold_half_years + _asset_js_money
            reality_cost = _intervest / _hold_half_years + _asset_js_money
            _pay_date = _dq_date
        else:
            theory_cost = _intervest / _hold_half_years
            reality_cost = _intervest / _hold_half_years
            _pay_date = pay_date.strftime("%Y%m%d")

        # 会计事件:account_event=003-中间付息
        # 现金确认日期:confirm_date='' 该字段到实际做确认动作的时候才赋值
        _cash_flow = FAS_ASSET_CASH_FLOW(_pk, _deal_id, _code, _name, '003', _pay_date, theory_cost,reality_cost,
                                         is_confirm, '')

        try:
            _session.add(_cash_flow)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成半年现金流报错!"

        _v_half_years = _v_half_years - 1
        _v_day = pay_date



    return "200"



#按年付息
def _asset_pay_by_year(fas_asset_trade_info, _pkobj, _session):

    _qx_date = fas_asset_trade_info.asset_qx_date
    _dq_date = fas_asset_trade_info.asset_dq_date
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _deal_id = fas_asset_trade_info.deal_id
    _code = fas_asset_trade_info.asset_code
    _name = fas_asset_trade_info.asset_name

    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    _qx_format = datetime.date(int(_qx_date[0:4]), int(_qx_date[4:6]), int(_qx_date[6:8]))  # 起息日
    _dq_format = datetime.date(int(_dq_date[0:4]), int(_dq_date[4:6]), int(_dq_date[6:8]))  # 到期日
    _hold_days = days_minus(_dq_format, _qx_format)  # 持有天数

    _hold_years = years_minus(_dq_format, _qx_format)  # 起息日与到期日间隔的年数 - 用于循环

    _intervest = (_asset_js_money * (_asset_rate / 100)) / int(_asset_adjust_base) * _hold_days  # 资产投资收益（利息）

    _v_day = _qx_format
    _v_years = _hold_years

    while _v_years > 0:
        _pk = _pkobj.get_primary_key()
        pay_date = _get_next_year_days(_v_day)
        is_confirm = '0'

        # 最后一个年本息兑付
        if _v_years == 1:
            theory_cost = _intervest / _hold_years + _asset_js_money
            reality_cost = _intervest / _hold_years + _asset_js_money
            _pay_date = _dq_date
        else:
            theory_cost = _intervest / _hold_years
            reality_cost = _intervest / _hold_years
            _pay_date = pay_date.strftime("%Y%m%d")

        # 会计事件:account_event=003-中间付息
        # 现金确认日期:confirm_date='' 该字段到实际做确认动作的时候才赋值
        _cash_flow = FAS_ASSET_CASH_FLOW(_pk, _deal_id, _code, _name, '003', _pay_date, theory_cost,reality_cost,
                                         is_confirm, '')

        try:
            _session.add(_cash_flow)
            _session.commit()
        except Exception as e:
            _session.rollback()
            return "生成年度现金流报错!"

        _v_years = _v_years - 1
        _v_day = pay_date

    return "200"



# 到期支付
def _asset_pay_by_end(fas_asset_trade_info, _pkobj, _session):

    _qx_date = fas_asset_trade_info.asset_qx_date
    _dq_date = fas_asset_trade_info.asset_dq_date
    _asset_js_money = fas_asset_trade_info.asset_js_money
    _asset_rate = fas_asset_trade_info.asset_rate
    _asset_adjust_base = fas_asset_trade_info.asset_adjust_base
    _deal_id = fas_asset_trade_info.deal_id
    _code = fas_asset_trade_info.asset_code
    _name = fas_asset_trade_info.asset_name

    # 资产投资收益（利息） = (本金*收益率)/计息基数 * 持有天数
    _qx_format = datetime.date(int(_qx_date[0:4]), int(_qx_date[4:6]), int(_qx_date[6:8]))  # 起息日
    _dq_format = datetime.date(int(_dq_date[0:4]), int(_dq_date[4:6]), int(_dq_date[6:8]))  # 到期日
    _hold_days = days_minus(_dq_format, _qx_format)  # 持有天数
    _intervest = (_asset_js_money * (_asset_rate / 100)) / int(_asset_adjust_base) * _hold_days  # 资产投资收益（利息）

    _pk = _pkobj.get_primary_key()
    _is_confirm = '0'
    _pay_date = _dq_date
    _cost = _intervest + _asset_js_money

    # 会计事件:account_event=004-到期还本
    # 现金确认日期:confirm_date='' 该字段到实际做确认动作的时候才赋值
    _cash_flow = FAS_ASSET_CASH_FLOW(_pk, _deal_id, _code, _name, '004', _pay_date, _cost, _cost, _is_confirm, '')

    try:
        _session.add(_cash_flow)
        _session.commit()
    except Exception as e:
        _session.rollback()
        return "生成到期支付现金流报错!"

    return "200"



# 计算两个日期间的天数差
def days_minus(days_over, days_begin):
    num = (days_over - days_begin).days
    return num


# 计算两个日期间的月份差（用于循环生成现金流的次数） - 按月付息
def months_minus(days_over, days_begin):
    year1 = days_over.year
    year2 = days_begin.year
    month1 = days_over.month
    month2 = days_begin.month
    num = (year1 - year2) * 12 + (month1 - month2)
    return num


# 计算两个日期间的季度差（用于循环生成现金流的次数） - 按季付息
def quarters_minus(days_over, days_begin):

    num = 0
    days_begin = _get_next_quarter_days(days_begin)
    while days_over.__gt__(days_begin):
        num = num + 1
        days_begin = _get_next_quarter_days(days_begin)

    return num+1


# 计算两个日期间的半年差（用于循环生成现金流的次数） - 按半年付息
def half_years_minus(days_over, days_begin):

    quarters_num = quarters_minus(days_over, days_begin)
    if quarters_num < 2:
        num = 1
    else:
        num = (quarters_num * 3) // 6

    return num



# 计算两个日期间的年份差（用于循环生成现金流的次数） - 按年付息
def years_minus(days_over, days_begin):

    num = 0
    days_begin = _get_next_year_days(days_begin)
    while days_over.__gt__(days_begin):
        num = num + 1
        days_begin = _get_next_year_days(days_begin)

    return num+1


#获取当前日期的[下一个月]的日期
# 如当前日期是:2020-07-21, 对应的下一个月的日期为:2020-08-21
def _get_next_month_days(today):

    if today.month == 12:
        next_month = datetime.date(today.year + 1, 1, today.day)
        return next_month
    else:
        next_month = datetime.date(today.year, today.month + 1, today.day)
        return next_month


#获取当前日期的[下一个季度]的日期
# 如当前日期是:2020-07-21, 对应的下一个季度的日期为:2020-10-21
def _get_next_quarter_days(today):

    if today.month >= 10:  #10月份后的下一个季度就是下一年了
        if today.month == 10:
            next_quarter_day = datetime.date(today.year + 1, 1, today.day)
            return next_quarter_day
        if today.month == 11:
            next_quarter_day = datetime.date(today.year + 1, 2, today.day)
            return next_quarter_day
        if today.month == 12:
            next_quarter_day = datetime.date(today.year + 1, 3, today.day)
            return next_quarter_day
    else:
        next_quarter_day = datetime.date(today.year, today.month + 3, today.day)
        return next_quarter_day


#获取当前日期的[下一个半年]的日期
# 如当前日期是:2020-01-21, 对应的下一个季度的日期为:2020-07-21
def _get_next_half_year_days(today):

    first_day = _get_next_quarter_days(today) #第1个季度

    send_day = _get_next_quarter_days(first_day)  # 第2个季度

    return send_day



#获取当前日期的[下一年]的日期
# 如当前日期是:2020-07-21, 对应的下一年的日期为:2021-07-21
def _get_next_year_days(today):

    #闰年条件（满足如下条件之一）：[2月份有29天]
    #1.能被4整除，且不能被100整除：(years%4 == 0 and years%100 != 0)
    #2.能被400整除：(years%400 == 0)

    _month = today.month
    _day = today.day

    #闰年
    if _month == 2 and _day == 29:
        _next_year_days = datetime.date(today.year + 1, today.month, today.day-1)
        return _next_year_days
    #平年
    else:
        _next_year_days = datetime.date(today.year + 1, today.month, today.day)
        return _next_year_days



# 打印前台传递过来的参数（开发调试使用）
def _print_front_json(_json):
    items = _json.items()
    for key, value in items:
        print('---------------------------前台传递过来的参数：' + str(key) + '=' + str(value))




















