

SQL_ASSET_ALL_INFO_QUERY = """ select * from v_fas_asset_all_info t where 1=1 """


SQL_ASSET_ALL_INFO_COUNT_QUERY = """ select count(1) as total from v_fas_asset_all_info t where 1=1 """


SQL_SEL_DATA_QUERY = """ select a.item_key as id, a.item_key || '-'||a.item_value as text from fas_sys_dict a """


SQL_SEL_TRUSTS_PLAN_QUERY = """ select a.asset_code as id, a.asset_code || '-' || a.asset_name as text from fas_asset_trusts_plan a """


SQL_ASSET_TRUSTS_PLAN_DETAILS_INFO_QUERY = """ 
                        select t.asset_code,
                               t.asset_name,
                               a.id || '-' || a.text as asset_hs_fs,
                               t.asset_qx_date,
                               t.asset_dq_date,
                               b.id || '-' || b.text as asset_pay_freq,
                               t.asset_rate,
                               t.asset_adjust_base,
                               t.asset_first_pay_date,
                               c.id || '-' || c.text as asset_bz,
                               d.id || '-' || d.text as asset_kj_km,
                               e.id || '-' || e.text as asset_though,
                               f.id || '-' || f.text as asset_manage_type,
                               g.id || '-' || g.text as asset_expect_flag,
                               t.asset_manager_name,
                               t.asset_tg_people,
                               t.asset_mj_money,
                               t.asset_tg_rate,
                               t.asset_rh_code,
                               h.id || '-' || h.text as asset_fxjg_type,
                               t.asset_note
                          from fas_asset_trusts_plan t,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_hs_fs') a,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_pay_freq') b,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_bz') c,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_km') d,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_though') e,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_manage_type') f,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_expect_flag') g,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_fxjg_type') h
                         where t.asset_hs_fs = a.id(+)
                           and t.asset_pay_freq = b.id(+)
                           and t.asset_bz = c.id(+)
                           and t.asset_kj_km = d.id(+)
                           and t.asset_though = e.id(+)
                           and t.asset_manage_type = f.id(+)
                           and t.asset_expect_flag = g.id(+)
                           and t.asset_fxjg_type = h.id(+)
                        """


SQL_SEL_OPPONENTS_QUERY = """
        select a.trade_opponents_code as id, a.trade_opponents_code || '-' || a.trade_opponents_name as text from fasset.fas_trade_opponents_info a
                          """


SQL_PRODUCT_INFO_QUERY = """ 
       select t.pd_code as id, t.pd_code||'-'||t.pd_name as text from fas_prod_info t,fas_prod_balance t1 where t.pd_code = t1.pd_code 
                         """


SQL_PRODUCT_BALANCE_INFO_QUERY = """
                        select * from fas_prod_balance t where 1 = 1
                                """


SQL_COPY_ASSET_TRUSTS_PLAN = """
                        select t.asset_code,
                               t.asset_name,
                               a.id || '#' || a.text as asset_hs_fs,
                               t.asset_qx_date,
                               t.asset_dq_date,
                               b.id || '#' || b.text as asset_pay_freq,
                               t.asset_rate,
                               i.id || '#' || i.text as asset_adjust_base,
                               t.asset_first_pay_date,
                               c.id || '#' || c.text as asset_bz,
                               d.id || '#' || d.text as asset_kj_km,
                               e.id || '#' || e.text as asset_though,
                               f.id || '#' || f.text as asset_manage_type,
                               g.id || '#' || g.text as asset_expect_flag,
                               t.asset_manager_name,
                               t.asset_tg_people,
                               t.asset_mj_money,
                               t.asset_tg_rate,
                               t.asset_rh_code,
                               h.id || '#' || h.text as asset_fxjg_type,
                               t.asset_note
                          from fas_asset_trusts_plan t,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_hs_fs') a,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_pay_freq') b,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_bz') c,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_km') d,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_though') e,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_manage_type') f,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_expect_flag') g,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_fxjg_type') h,
                               (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_adjust_base') i
                         where t.asset_hs_fs = a.id(+)
                           and t.asset_pay_freq = b.id(+)
                           and t.asset_bz = c.id(+)
                           and t.asset_kj_km = d.id(+)
                           and t.asset_though = e.id(+)
                           and t.asset_manage_type = f.id(+)
                           and t.asset_expect_flag = g.id(+)
                           and t.asset_fxjg_type = h.id(+)
                           and t.asset_adjust_base = i.id(+)
                             """


SQL_SEL_ASSET_ALL_INFO_QUERY = """
                    select t.asset_code as id, t.asset_code||'-'||t.asset_name as text from v_fas_asset_all_info t
                               """


SQL_ASSET_TRADE_INFO_CONFIRM_QUERY = """
                            select rownum as rowno,
                                   t.deal_id,
                                   t.asset_deal_date, --条件
                                   t1.id || '-'|| t1.text as asset_deal_dirt,
                                   t.asset_type, --条件
                                   t2.id || '-'|| t2.text as asset_type_name,
                                   t.asset_code || '-' || t.asset_name as asset_code_name,
                                   t3.id || '-'|| t3.text as opponents_code,
                                   t.asset_deal_money,
                                   t.asset_deal_rate,
                                   t.asset_js_money,
                                   t.asset_intervest_total,
                                   t4.id || '-'|| t4.text as kjfl_type,
                                   t.asset_prod_code || '-' || t.asset_prod_name as asset_prod_code_name,
                                   t.asset_prod_ye,
                                   t.asset_note,
                                   t.asset_qx_date,
                                   t.asset_dq_date,
                                   t.asset_first_pay_date,
                                   t5.id || '-'|| t5.text as asset_pay_freq,
                                   t.asset_rate,
                                   t6.id || '-'|| t6.text as asset_kj_km,
                                   t7.id || '-'|| t7.text as asset_adjust_base,
                                   (case when t.asset_comfir='0' then '否'  
                                         when t.asset_comfir='1' then '已成交'
                                         when t.asset_comfir='2' then '已撤单'
                                    end) as asset_comfir
                            from fas_asset_trade_info t,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_deal_dirt') t1,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_type') t2,
                                 (select b.trade_opponents_code as id, b.trade_opponents_name as text from fas_trade_opponents_info b) t3,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_type') t4,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_pay_freq') t5,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_km') t6,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_adjust_base') t7  
                             where t.asset_deal_dirt = t1.id
                               and t.asset_type = t2.id
                               and t.opponents_code = t3.id
                               and t.kjfl_type = t4.id(+)
                               and t.asset_pay_freq = t5.id
                               and t.asset_kj_km = t6.id(+)
                               and t.asset_adjust_base = t7.id(+)
                                     """


SQL_ASSET_TRADE_INFO_CONFIRM_COUNT_QUERY = """
                            select count(1) as total
                            from fas_asset_trade_info t,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_deal_dirt') t1,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_type') t2,
                                 (select b.trade_opponents_code as id, b.trade_opponents_name as text from fas_trade_opponents_info b) t3,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_km') t4,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_pay_freq') t5,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_kj_km') t6,
                                 (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'asset_adjust_base') t7  
                             where t.asset_deal_dirt = t1.id
                               and t.asset_type = t2.id
                               and t.opponents_code = t3.id
                               and t.kjfl_type = t4.id(+)
                               and t.asset_pay_freq = t5.id
                               and t.asset_kj_km = t6.id(+)
                               and t.asset_adjust_base = t7.id(+)
                                           """


SQL_ASSET_INTERVEST_CONFIRM_QUERY = """
                            select rownum as rowno,
                                   t.flow_id,
                                   t.deal_id,
                                   t.asset_code,
                                   t.asset_name,
                                   t.account_event,
                                   t.pay_date,
                                   t.theory_cost,
                                   t.reality_cost,
                                   t.asset_qx_date,
                                   t.asset_dq_date,
                                   t.asset_js_money,
                                   t.asset_rate,
                                   t.is_confirm,
                                   t.confirm_date
                              from (select t.flow_id,
                                           t.deal_id,
                                           t.asset_code, --条件
                                           t.asset_name,
                                           t.account_event || '-' || t2.text as account_event,
                                           t.pay_date, --条件
                                           t.theory_cost,
                                           t.reality_cost,
                                           t1.asset_qx_date,
                                           t1.asset_dq_date,
                                           t1.asset_js_money,
                                           t1.asset_rate,
                                           (case when t.is_confirm = '0' then '未确认'
                                                 when t.is_confirm = '1' then '已确认'
                                            end) is_confirm,
                                           t.confirm_date
                                      from fas_asset_cash_flow t,
                                           fas_asset_trade_info t1,
                                           (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'account_event') t2
                                     where t.deal_id = t1.deal_id
                                       and t.account_event = t2.id
                                     order by t.asset_code, t.pay_date) t  where 1 = 1
                                    """


SQL_ASSET_INTERVEST_CONFIRM_CNT_QUERY = """
                            select count(1) as total
                              from fas_asset_cash_flow t,
                                   fas_asset_trade_info t1,
                                   (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'account_event') t2
                             where t.deal_id = t1.deal_id
                               and t.account_event = t2.id
                                        """



SQL_ASSET_INTERVEST_CONFIRM_TODAY_QUERY = """
                            select rownum as rowno,
                                   t.flow_id,
                                   t.deal_id,
                                   t.asset_code, --条件
                                   t.asset_name,
                                   t.account_event||'-'||t2.text as account_event,
                                   t.pay_date, --条件
                                   t.theory_cost,
                                   t.reality_cost,
                                   t1.asset_qx_date,
                                   t1.asset_dq_date,
                                   t1.asset_js_money,
                                   t1.asset_rate,
                                   (case when t.is_confirm='0' then '未确认'
                                         when t.is_confirm='1' then '已确认'
                                    end) is_confirm,
                                   t.confirm_date
                              from fas_asset_cash_flow t,
                                   fas_asset_trade_info t1,
                                   (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'account_event') t2
                             where t.deal_id = t1.deal_id
                               and t.account_event = t2.id
                               and t.pay_date = to_char(sysdate,'yyyymmdd')
                                          """



SQL_ASSET_INTERVEST_CONFIRM_TODAY_CNT_QUERY = """
                                    select count(1) as total
                                      from fas_asset_cash_flow t,
                                           fas_asset_trade_info t1,
                                           (select a.item_key as id, a.item_value as text from fas_sys_dict a where a.dict_code = 'account_event') t2
                                     where t.deal_id = t1.deal_id
                                       and t.account_event = t2.id
                                       and t.pay_date = to_char(sysdate,'yyyymmdd')
                                                """



















