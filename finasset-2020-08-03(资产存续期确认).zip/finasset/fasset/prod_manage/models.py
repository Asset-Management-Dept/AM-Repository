from config import db


# 数据库FAS_PROD_INFO[理财产品信息表]实体类
'''
类的内置属性：
__dict__ : 类的属性（包含一个字典，由类的数据属性组成）
__doc__ :类的文档字符串
__name__: 类名
__module__: 类定义所在的模块（类的全名是'__main__.className'，如果类位于一个导入模块mymod中，那么className.__module__ 等于 mymod）
__bases__ : 类的所有父类构成元素（包含了一个由所有父类组成的元组）

析构函数 __del__ ：__del__在对象销毁的时候被调用，当对象不再被使用时，__del__方法运行
构造函数 __init__：__init__()方法是一种特殊的方法，被称为类的构造函数或初始化方法，创建了这个类的实例时就会调用该方法

私有属性：
  __private_attrs：两个下划线开头，声明该属性为私有，不能在类的外部被使用或直接访问。在类内部的方法中使用时 self.__private_attrs。
  示例： __myprovate_str = 'test'  --表明该属性是私有的

私有方法：
  __private_method：两个下划线开头，声明该方法为私有方法，不能在类的外部调用。在类的内部调用 self.__private_methods
  
类的继承：
  class SubClassName (ParentClass1[, ParentClass2, ...]):
  
  示例：
  class Parent:        # 定义父类
  
  class Child(Parent): # 定义子类  --其中[ Chlid(Parent) ]表示Child类继承了Parent类

'''


#产品信息表
class FAS_PROD_INFO(db.Model):

    '理财产品信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_prod_info'

    # 模型对应的字段
    pd_code = db.Column(db.String, primary_key=True, autoincrement=True)
    pd_name = db.Column(db.String(120))
    pd_mode = db.Column(db.String(5))
    pd_zz_code = db.Column(db.String(40))
    pd_type = db.Column(db.String(3))
    pd_colect_type = db.Column(db.String(3))
    pd_risk_level = db.Column(db.String(3))
    pd_profit_type = db.Column(db.String(3))
    pd_adjust_type = db.Column(db.String(3))
    pd_interest_base = db.Column(db.String(3))
    pd_rg_bg_date = db.Column(db.String(8))
    pd_rg_ov_date = db.Column(db.String(8))
    pd_fx_b_date = db.Column(db.String(8))
    pd_sy_b_date = db.Column(db.String(8))
    pd_open_b_date = db.Column(db.String(8))
    pd_open_o_date = db.Column(db.String(8))
    pd_ov_date = db.Column(db.String(8))
    pd_df_date = db.Column(db.String(8))
    pd_life_statu = db.Column(db.String(8))
    pd_verify_person = db.Column(db.String(25))
    pd_verify_certi = db.Column(db.String(25))
    pd_desiner_name = db.Column(db.String(25))
    pd_desiner_certi = db.Column(db.String(25))

    investmanage_name = db.Column(db.String(25))  # 投资经理姓名
    investmanage_zj = db.Column(db.String(25))  # 投资经理证件
    ywry_name = db.Column(db.String(25))  # 业务人员姓名
    ywry_zj_phone = db.Column(db.String(11))  # 业务人员座机
    ywry_yd_phone = db.Column(db.String(11))  # 业务人员手机
    ywry_mail = db.Column(db.String(25))  # 业务人员邮箱
    zj_tx = db.Column(db.String(3))  # 资金投向地
    lc_fw_type = db.Column(db.String(3))  # 理财服务模式
    prod_manager_mode = db.Column(db.String(3))  # 产品管理模式
    invest_pz_type = db.Column(db.String(3))  # 资产配置方式
    dj_fs = db.Column(db.String(3))  # 产品定价方式
    tz_zc_type = db.Column(db.String(3))  # 投资资产类型
    hezuo_mode = db.Column(db.String(3))  # 合作模式
    prod_zengxin_flag = db.Column(db.String(3))  # 产品增信标识
    prod_zengxin_comp = db.Column(db.String(3))  # 产品增信机构
    prod_zengxin_xingshi = db.Column(db.String(3))  # 产品增信形式
    prod_pingpai = db.Column(db.String(50))  # 产品品牌
    prod_qishu = db.Column(db.String(11))  # 产品期数
    sale_channel_dif = db.Column(db.String(3))  # 销售渠道划分
    touzi_zhonglei_bili = db.Column(db.String(50))  # 投资种类及比例
    jianguan_guanli_fs = db.Column(db.String(3))  # 管理方式
    jianguan_muji_fs = db.Column(db.String(3))  # 募集方式
    jianguan_kuaijihesuan_fs = db.Column(db.String(3))  # 会计核算方式
    jianguan_shouyi_bz = db.Column(db.String(3))  # 收益保证标志
    jianguan_benjinbz_bz = db.Column(db.String(3))  # 本金保障标志
    jianguan_tiqianzhongzhi_bz = db.Column(db.String(3))  # 可提前终止标志
    jianguan_shuhui_bz = db.Column(db.String(3))  # 可赎回权标志
    jianguan_tuoguan_jwai_daima = db.Column(db.String(50))  # 境外托管机构代码
    jianguan_tuoguan_jnei_mc = db.Column(db.String(50))  # 境内托管机构名称
    jianguan_tuoguan_jwai_gb = db.Column(db.String(50))  # 境外托管机构国别
    jianguan_tuoguan_jwai_mc = db.Column(db.String(50))  # 境外托管机构名称


    #2020-06-30新增13个字段
    pd_cpqx = db.Column(db.String(5))  # 产品期限
    pd_tongyezs = db.Column(db.String(5))  # 是否同业专属
    pd_setholdtime = db.Column(db.String(5))  # 设置最短持有期限
    pd_holddate = db.Column(db.Integer)  # 最短持有期限(天)
    pd_tzshouy_dzr = db.Column(db.String(5))  # 投资收益到账日
    pd_xjmanagertype = db.Column(db.String(5))  # 是否现金管理类
    pd_beginsalemoney = db.Column(db.Float)  # 起点销售金额
    pd_salerate = db.Column(db.Float)  # 销售手续费率%
    pd_tuoguangrate = db.Column(db.Float)  # 托管费率%
    pd_plancolectmoney = db.Column(db.Float)  # 计划募集金额(元)
    pd_investmanagerate = db.Column(db.Float)  # 投资管理费率%
    pd_tzbenjin_dzr = db.Column(db.String(5))  # 投资本金到账日
    pd_freeback = db.Column(db.String(5))  # 自由赎回

    #2020-07-03 新增一个字段：PD_BASE_RATE 业绩比较基准
    pd_base_rate = db.Column(db.Float)


    # 构造函数
    # 类的方法与普通的函数只有一个特别的区别——它们必须有一个额外的第一个参数名称, 按照惯例它的名称是 self
    # self代表类的实例，而非类
    def __init__(self, pd_code, pd_name, pd_mode, pd_zz_code, pd_type, pd_colect_type, pd_risk_level, pd_profit_type,
                 pd_adjust_type, pd_interest_base, pd_rg_bg_date, pd_rg_ov_date, pd_fx_b_date, pd_sy_b_date,
                 pd_open_b_date, pd_open_o_date, pd_ov_date, pd_df_date, pd_life_statu, pd_verify_person,
                 pd_verify_certi, pd_desiner_name, pd_desiner_certi,investmanage_name,investmanage_zj,ywry_name,ywry_zj_phone,
                 ywry_yd_phone,ywry_mail,zj_tx,lc_fw_type,prod_manager_mode,invest_pz_type,dj_fs,tz_zc_type,
                 hezuo_mode,prod_zengxin_flag,prod_zengxin_comp,prod_zengxin_xingshi,prod_pingpai,prod_qishu,
                 sale_channel_dif,touzi_zhonglei_bili,jianguan_guanli_fs,jianguan_muji_fs,jianguan_kuaijihesuan_fs,
                 jianguan_shouyi_bz,jianguan_benjinbz_bz,jianguan_tiqianzhongzhi_bz,jianguan_shuhui_bz,jianguan_tuoguan_jwai_daima,
                 jianguan_tuoguan_jnei_mc,jianguan_tuoguan_jwai_gb,jianguan_tuoguan_jwai_mc,
                 pd_cpqx, pd_tongyezs, pd_setholdtime, pd_holddate, pd_tzshouy_dzr, pd_xjmanagertype, pd_beginsalemoney,
                 pd_salerate, pd_tuoguangrate, pd_plancolectmoney, pd_investmanagerate, pd_tzbenjin_dzr, pd_freeback,pd_base_rate):
        self.pd_code = pd_code
        self.pd_name = pd_name
        self.pd_mode = pd_mode
        self.pd_zz_code = pd_zz_code
        self.pd_type = pd_type
        self.pd_colect_type = pd_colect_type
        self.pd_risk_level = pd_risk_level
        self.pd_profit_type = pd_profit_type
        self.pd_adjust_type = pd_adjust_type
        self.pd_interest_base = pd_interest_base
        self.pd_rg_bg_date = pd_rg_bg_date
        self.pd_rg_ov_date = pd_rg_ov_date
        self.pd_fx_b_date = pd_fx_b_date
        self.pd_sy_b_date = pd_sy_b_date
        self.pd_open_b_date = pd_open_b_date
        self.pd_open_o_date = pd_open_o_date
        self.pd_ov_date = pd_ov_date
        self.pd_df_date = pd_df_date
        self.pd_life_statu = pd_life_statu
        self.pd_verify_person = pd_verify_person
        self.pd_verify_certi = pd_verify_certi
        self.pd_desiner_name = pd_desiner_name
        self.pd_desiner_certi = pd_desiner_certi

        self.investmanage_name = investmanage_name
        self.investmanage_zj = investmanage_zj
        self.ywry_name = ywry_name
        self.ywry_zj_phone = ywry_zj_phone
        self.ywry_yd_phone = ywry_yd_phone
        self.ywry_mail = ywry_mail
        self.zj_tx = zj_tx
        self.lc_fw_type = lc_fw_type
        self.prod_manager_mode = prod_manager_mode
        self.invest_pz_type = invest_pz_type
        self.dj_fs = dj_fs
        self.tz_zc_type = tz_zc_type
        self.hezuo_mode = hezuo_mode
        self.prod_zengxin_flag = prod_zengxin_flag
        self.prod_zengxin_comp = prod_zengxin_comp
        self.prod_zengxin_xingshi = prod_zengxin_xingshi
        self.prod_pingpai = prod_pingpai
        self.prod_qishu = prod_qishu
        self.sale_channel_dif = sale_channel_dif
        self.touzi_zhonglei_bili = touzi_zhonglei_bili
        self.jianguan_guanli_fs = jianguan_guanli_fs
        self.jianguan_muji_fs = jianguan_muji_fs
        self.jianguan_kuaijihesuan_fs = jianguan_kuaijihesuan_fs
        self.jianguan_shouyi_bz = jianguan_shouyi_bz
        self.jianguan_benjinbz_bz = jianguan_benjinbz_bz
        self.jianguan_tiqianzhongzhi_bz = jianguan_tiqianzhongzhi_bz
        self.jianguan_shuhui_bz = jianguan_shuhui_bz
        self.jianguan_tuoguan_jwai_daima = jianguan_tuoguan_jwai_daima
        self.jianguan_tuoguan_jnei_mc = jianguan_tuoguan_jnei_mc
        self.jianguan_tuoguan_jwai_gb = jianguan_tuoguan_jwai_gb
        self.jianguan_tuoguan_jwai_mc = jianguan_tuoguan_jwai_mc

        # 2020-06-30新增13个字段
        self.pd_cpqx = pd_cpqx
        self.pd_tongyezs = pd_tongyezs
        self.pd_setholdtime = pd_setholdtime
        self.pd_holddate = pd_holddate
        self.pd_tzshouy_dzr = pd_tzshouy_dzr
        self.pd_xjmanagertype = pd_xjmanagertype
        self.pd_beginsalemoney = pd_beginsalemoney
        self.pd_salerate = pd_salerate
        self.pd_tuoguangrate = pd_tuoguangrate
        self.pd_plancolectmoney = pd_plancolectmoney
        self.pd_investmanagerate = pd_investmanagerate
        self.pd_tzbenjin_dzr = pd_tzbenjin_dzr
        self.pd_freeback = pd_freeback

        # 2020-06-30新增1个字段
        self.pd_base_rate = pd_base_rate


#产品销售信息表
class FAS_PROD_SALE_INFO(db.Model):

    '理财产品销售信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_prod_sale_info'

    pd_code = db.Column(db.String, primary_key=True, autoincrement=True)
    pd_colect_money = db.Column(db.Float)
    pd_person_a = db.Column(db.Float)
    pd_person_b = db.Column(db.Float)
    pd_person_c = db.Column(db.Float)
    pd_copr_a = db.Column(db.Float)
    pd_copr_b = db.Column(db.Float)
    pd_copr_c = db.Column(db.Float)
    pd_done_flag = db.Column(db.String)

    def __init__(self, pd_code, pd_colect_money, pd_person_a,
                 pd_person_b, pd_person_c, pd_copr_a, pd_copr_b,pd_copr_c,pd_done_flag):
        self.pd_code = pd_code
        self.pd_colect_money = pd_colect_money
        self.pd_person_a = pd_person_a
        self.pd_person_b = pd_person_b
        self.pd_person_c = pd_person_c
        self.pd_copr_a = pd_copr_a
        self.pd_copr_b = pd_copr_b
        self.pd_copr_c = pd_copr_c
        self.pd_done_flag = pd_done_flag



#产品余额表
class FAS_PROD_BALANCE(db.Model):

    '产品余额表'  # __doc__属性的值

    __tablename__ = 'fas_prod_balance'

    pd_code = db.Column(db.String, primary_key=True, autoincrement=True)
    pd_balance = db.Column(db.Float)
    pd_life_status = db.Column(db.String)

    def __init__(self,_pd_code,_pd_balance,_pd_life_status):
        self.pd_code = _pd_code
        self.pd_balance = _pd_balance
        self.pd_life_status = _pd_life_status



#产品余额交易流水表
class FAS_PROD_BALANCE_DEAL(db.Model):

    '产品余额交易流水表'  # __doc__属性的值

    __tablename__ = 'fas_prod_balance_deal'

    deal_id = db.Column(db.String, primary_key=True, autoincrement=True) #交易ID
    pd_code = db.Column(db.String) #产品代码
    deal_date = db.Column(db.String) #交易日期
    deal_type = db.Column(db.String) #交易类型
    deal_money = db.Column(db.Float) #交易金额
    deal_balance = db.Column(db.Float) #交易后余额

    def __init__(self,_deal_id,_pd_code,_deal_date,_deal_type,_deal_money,_deal_balance):
        self.deal_id = _deal_id
        self.pd_code = _pd_code
        self.deal_date = _deal_date
        self.deal_type = _deal_type
        self.deal_money = _deal_money
        self.deal_balance = _deal_balance

