from flask_script import Manager
from fasset import create_app
from fasset.index import index
from fasset.prod_manage import prod_manage
from fasset.asset_manage import asset_manage
from fasset.system_manage import system_manage
from fasset.opera_manage import opera_manage

'''
author:ruanyemao
date:2020-6-18
descrp:项目启动文件,采用blueprint来进行项目模块管理及URL路由
'''

app = create_app()  # 创建app

app.register_blueprint(blueprint=index, url_prefix='/')  # 注册蓝图 - 首页

app.register_blueprint(blueprint=prod_manage, url_prefix='/prod_manage')  # 注册蓝图 - 产品端管理

app.register_blueprint(blueprint=asset_manage, url_prefix='/asset_manage')  # 注册蓝图 - 资产端管理

app.register_blueprint(blueprint=opera_manage, url_prefix='/opera_manage')  # 注册蓝图 - 日常运营管理

app.register_blueprint(blueprint=system_manage, url_prefix='/system_manage')  # 注册蓝图 - 系统管理

manager = Manager(app=app)  # 通过app创建manager对象

# 运行服务器
# 默认的情况下，flask自带的web服务器是以单进程单线程来响应我们的客户端请求。
# 因此假设有10个请求进来是没有办法同事执行的，一个请求执行完之后才能执行另一个请求。
# 当然，flask自带的web服务器也可以开启多线程或者多进程模式
# app.run(host='0.0.0.0', debug=True)  # 单进程单线程
# app.run(host='0.0.0.0', debug=True, threadad=True)  # 单进程多线程，进程默认为1
# app.run(host='0.0.0.0', debug=True, threadad=True, processes=2)  # 多进程多线程，进程processes默认为1

if __name__ == '__main__':
    manager.run()
