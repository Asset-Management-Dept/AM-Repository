
/*初始化*/
$(function () {

    init_archives_risk();
    init_data_visualized();
    init_asset_cash_flow();

});


/*初始化档案预警区域*/
function init_archives_risk() {
    var _json = {"flag": "archives"};
    $.post({
        'url': '/mypage',
        'data': JSON.stringify(_json),
        'success': function (_data) {
            var _json = JSON.parse(_data);
            var _ahtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_a\")'>" + _json['archi_a'] + "</a>";
            var _bhtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_b\")'>" + _json['archi_b'] + "</a>";
            var _chtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_c\")'>" + _json['archi_c'] + "</a>";
            var _dhtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_d\")'>" + _json['archi_d'] + "</a>";
            var _ehtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_e\")'>" + _json['archi_e'] + "</a>";
            var _fhtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_f\")'>" + _json['archi_f'] + "</a>";
            var _ghtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_g\")'>" + _json['archi_g'] + "</a>";
            var _hhtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_h\")'>" + _json['archi_h'] + "</a>";
            var _ihtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_i\")'>" + _json['archi_i'] + "</a>";
            var _jhtlm = "<a href='javascript:void();' onclick='open_risk_archives(\"archi_j\")'>" + _json['archi_j'] + "</a>";
            document.getElementById('arch_a').innerHTML = _ahtlm;
            document.getElementById('arch_b').innerHTML = _bhtlm;
            document.getElementById('arch_c').innerHTML = _chtlm;
            document.getElementById('arch_d').innerHTML = _dhtlm;
            document.getElementById('arch_e').innerHTML = _ehtlm;
            document.getElementById('arch_f').innerHTML = _fhtlm;
            document.getElementById('arch_g').innerHTML = _ghtlm;
            document.getElementById('arch_h').innerHTML = _hhtlm;
            document.getElementById('arch_i').innerHTML = _ihtlm;
            document.getElementById('arch_j').innerHTML = _jhtlm;
        },
        'fail': function (error) {
            alert(error);
        }
    })
}


/*新建窗口查看未归档档案*/
function open_risk_archives(key) {

    var _titles = '未归档档案列表';
    var _url = '/opera_manage/risk_unarchives_info?flag=' + key + '';
    var _id = 'risk-archives-'+ key;
    parent.addTab(_titles, _url, _id);

}



/*初始化数据可视化区域*/
function init_data_visualized() {
    var _json = {"flag": "DataVisualized"};
    $.post({
        'url': '/mypage',
        'data': JSON.stringify(_json),
        'success': function (_data) {
            var _returndata = $.parseJSON(_data);
            var arraydata = [];
            for (var i in _returndata) {
                arraydata.push(_returndata[i]);
            }
            var myChart = echarts.init(document.getElementById('DataVisualized'));
            var dateList = arraydata.map(function (item) {
                return item[0];});
            var valueList = arraydata.map(function (item) {
                return item[1];});

            option = {
                // Make gradient line here
                visualMap: [{
                    show: false,
                    type: 'continuous',
                    seriesIndex: 0,
                    min: 0,
                    max: 400
                }],
                title: [{
                    left: 'center',
                    text: '理财产品发行折线图'
                }],
                tooltip: {
                    trigger: 'axis'
                },
                xAxis: [{
                    data: dateList,
                    name: '日期(月份)'
                }],
                yAxis: [{
                    splitLine: {show: false},
                    name: '月发行量'
                }],
                grid: [{
                    bottom: '10%',
                    right: '15%'
                }],
                series: [{
                    type: 'line',
                    showSymbol: false,
                    data: valueList
                }],
                lineStyle: {
                    color: '#ff9e5e'
                }
            };
            myChart.setOption(option);
        },
        'fail': function (error) {
            alert(error);
        }
    });

}


/*初始化资产存续期区域*/
function init_asset_cash_flow() {

    layui.use('table', function () {
        var table = layui.table;
        table.render({
            elem: '#test',
            skin: 'line',
            size: 'lg',
            even: true,
            url: '/mypage',
            where: {flag: 'asset_cash_flow'},
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 80, align: 'center', title: '序号'}
                , {field: 'mission_name', width: 300, align: 'center', title: '任务说明'}
                , {field: 'mission_num', width: 100, align: 'center', title: '数量'}
                , {width: 100, title: '操作', align: 'center', toolbar: '#barDemo'}
            ]]
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            if (obj.event === 'confirm') { //确认
                var _titles = '资产收息到期调整';
                var _url = '/asset_manage/asset_route?flag=asset_interest_confirm_today';
                var _id = new Date().getTime();
                parent.addTab(_titles, _url, _id);
            }
        });
    });
    
}


