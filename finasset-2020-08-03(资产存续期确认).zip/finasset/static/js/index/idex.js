/*页面初始化,增加首页标签
$(function () {
    var content = '<iframe id="iframepage" scrolling="no" frameborder="0" οnlοad="changeFrameHeight()" src="/mypage" style="width:100%;"></iframe>';
    $('#maintab').tabs('add', {
        title: '首页',
        content: content,
        closable: false
    });
});
*/

/*注销*/
function logout(user_id) {
    $.post({
        'url': '/logout',
        'success': function (_data) {
            //do nothing
        },
        'fail': function (error) {
            alert(error);
        }
    });
}


function changeFrameHeight() {
    alert(1);
    var ifm = document.getElementById("iframepage");
    ifm.height = document.documentElement.clientHeight;
}

window.οnresize = function () {
    changeFrameHeight();
}


/*增加标签页
function addTab(title, url) {

    if ($('#maintab').tabs('exists', title)) {
        $('#maintab').tabs('select', title);
    } else {
        var content = '<iframe scrolling="auto" frameborder="0"  src="' + url + '" style="width:100%;height:740px;"></iframe>';
        $('#maintab').tabs('add', {
            title: title,
            content: content,
            closable: true
        });
    }
}
*/