
/*初始载入页面加载数据*/
$(function () {
    flushtable();
});


/*从远端获取数据并填充数据表格*/
function flushtable() {

    layui.use('table', function () {

        var table = layui.table;
        var $obj = $('#asset_code');
        var _asset_code = $obj.val() === null || $obj.val() === '' ? '%' : $obj.val();
        //table初始化
        table.render({
            elem: '#test'
            , toolbar: '#toolbarDemo'
            , skin: 'line'
            , size: 'sm'
            , defaultToolbar: ['filter', 'exports', 'print']
            , url: '/asset_manage/asset_route'
            , where: {asset_code: _asset_code, flag: 'asset_all_info_init'}
            , method: 'post'
            , contentType: 'application/json'
            , cols: [[
                {field: 'rowno', width: 80, title: '', fixed: 'left', align: 'center'}
                , {field: 'asset_code', width: 250, align: 'center', title: '资产代码'}
                , {field: 'asset_name', width: 300, align: 'center', title: '资产名称'}
                , {field: 'asset_type', width: 200, align: 'center', title: '资产类别'}
                , {field: 'asset_bg_interest_date', width: 150, align: 'center', title: '起息日'}
                , {field: 'asset_ov_interest_date', width: 150, align: 'center', title: '到期日'}
                , {field: 'asset_pay_freq', width: 150, align: 'center', title: '付息频率'}
                , {field: 'asset_roce', width: 150, align: 'center', title: '收益率%'}
                , {field: 'asset_adjust_base', width: 150, align: 'center', title: '计息基数'}
                , {fixed: 'right', width: 200, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]]
            , page: true
            , request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            }
            , response: {
                countName: 'total',
                dataName: 'rows'
            }
        });
        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var _asset_code = data['asset_code'];
            var _asset_type = data['asset_type'];
            console.log(obj);
            if (obj.event === 'del') {  //删除事件
                layer.confirm('确认删除?', function (index) {
                    var jsonstr = {'asset_code': _asset_code, 'asset_type': _asset_type};
                    $.post({
                        'url': '/asset_manage/delete_asset_info',
                        'data': JSON.stringify(jsonstr),
                        'success': function (_data) {
                            if (_data == '200') {
                                obj.del();
                                layer.close(index);
                                flushtable();
                            }
                        },
                        'fail': function (error) {
                            alert(error);
                        }
                    });
                });
            } else if (obj.event === 'modify') {  //修改事件
                var _titles = '[修改]' + _asset_type + '信息';
                var _url = '/asset_manage/asset_route?asset_code=' + _asset_code + '&flag=modify&asset_type=' + _asset_type;
                var _id = 'asset_modify'+new Date().getTime();
                parent.addTab(_titles, _url, _id);
            } else if (obj.event === 'copy') {  //复制事件
                var _titles = '[复制]' + _asset_type + '信息';
                var _url = '/asset_manage/asset_route?asset_code=' + _asset_code + '&flag=copy&asset_type=' + _asset_type;
                var _id = 'asset_copy'+new Date().getTime();
                parent.addTab(_titles, _url, _id);
            }
        });

        // 监听头部工具事件
        table.on('toolbar(test)', function (obj) {
            if (obj.event === 'create') { //新建事件 //打开一个弹出层
                layer.open({
                    title: '新建资产信息',
                    type: 1, //基本层类型：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    closeBtn: false,
                    area: '300px;',
                    shade: 0.8,
                    id: 'LAY_layuipro', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;">' +
                        '<select style="height: 40px;width: 100%;" id="asset_code_type">' +
                        '<option value="">----请选择----</option>' +
                        '<option value="1">资产管理计划(信托计划)</option>' +
                        '<option value="2">资产管理计划(券商计划)</option>' +
                        '</select>' +
                        '</div>',
                    yes: function (index, layero) {
                        var asset_type = $('#asset_code_type').val();
                        if (asset_type === "1") {
                            var _titles = '[新建]资管计划(信托计划)';
                            var _url = '/asset_manage/asset_route?flag=asset_type_trusts_plan';
                            var _id = 'new_asset_type_trusts_plan'+new Date().getTime();
                            parent.addTab(_titles, _url, _id);
                        }
                        if (asset_type === "2") {
                            var _titles = '[新建]资管计划(券商计划)';
                            var _url = '/asset_manage/asset_route?flag=asset_type_broker_plan';
                            var _id = 'new_asset_type_broker_plan'+new Date().getTime();
                            parent.addTab(_titles, _url, _id);
                        }
                    }
                });
            }
        });

    });
}



/*单笔查询*/
function search_asset_info() {
    flushtable();
}
