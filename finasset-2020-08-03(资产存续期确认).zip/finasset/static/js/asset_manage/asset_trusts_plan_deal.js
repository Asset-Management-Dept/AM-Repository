/*定义全局变量*/
var _asset_qx_date = undefined; //起息日
var _asset_dq_date = undefined; //到期日
var _asset_first_pay_date = undefined; //首次付息日
var _asset_pay_freq = undefined; //付息频率
var _asset_rate = undefined; //收益率%
var _asset_kj_km = undefined; //核心会计科目
var _asset_adjust_base = undefined; //计息基数


/*获得下拉框值*/
function get_sel_data(id, dict_code) {
    $.ajax({
        url: "/asset_manage/get_sel_data",
        type: "get",
        data: {'dict_code': dict_code},//发送到服务器的数据。
        dataType: "json",//预期服务器返回的数据类型。
        success: function (json) {
            var $sel2 = $('#' + id + '').select2();
            $sel2.select2({data: json});
            $sel2.val(null).trigger("change");
            $sel2.select2("open");
        },
        error: function () {
            alert("获取下拉框数据失败");
        }
    });

}


/*获得资产信息并联动界面其他组件*/
function get_asset_data(id, dict_code) {

    get_sel_data(id, dict_code);

    //select下拉框的选择事件
    $('#' + id + '').on('select2:select', function (e) {
        var data = e.params.data;
        var _asset_code = data['id'];
        $(".asset_info_display").empty();
        var innerHTML = '<table style="table-layout:fixed;">';
        $.ajax({
            url: "/asset_manage/get_asset_trusts_plan_details_data",
            type: "get",
            data: {'asset_code': _asset_code},//发送到服务器的数据。
            dataType: "json",//预期服务器返回的数据类型。
            success: function (json) {
                innerHTML += '<tr>' +
                    '<td>资产代码：' + json['asset_code'] + '</td>' +
                    '<td>资产名称：' + json['asset_name'] + '</td>' +
                    '</tr><tr>' +
                    '<td>核算方式：' + json['asset_hs_fs'] + '</td>' +
                    '<td>付息频率：' + json['asset_pay_freq'] + '</td>' +
                    '</tr><tr>' +
                    '<td>起息日：' + json['asset_qx_date'] + '</td>' +
                    '<td>到期日：' + json['asset_dq_date'] + '</td>' +
                    '</tr><tr>' +
                    '<td>收益率%：' + json['asset_rate'] + '</td>' +
                    '<td>计息基数：' + json['asset_adjust_base'] + '</td>' +
                    '</tr><tr>' +
                    '<td>首次付息日：' + json['asset_first_pay_date'] + '</td>' +
                    '<td>币种：' + json['asset_bz'] + '</td>' +
                    '</tr><tr>' +
                    '<td>核心会计科目：' + json['asset_kj_km'] + '</td>' +
                    '<td>是否穿透：' + json['asset_though'] + '</td>' +
                    '</tr><tr>' +
                    '<td>管理方式：' + json['asset_manage_type'] + '</td>' +
                    '<td>是否有预期收益率：' + json['asset_expect_flag'] + '</td>' +
                    '</tr><tr>' +
                    '<td>管理人名称：' + json['asset_manager_name'] + '</td>' +
                    '<td>托管人：' + json['asset_tg_people'] + '</td>' +
                    '</tr><tr>' +
                    '<td>募集金额：' + json['asset_mj_money'] + '</td>' +
                    '<td>托管费率%：' + json['asset_tg_rate'] + '</td>' +
                    '</tr><tr>' +
                    '<td>报送人行资产代码：' + json['asset_rh_code'] + '</td>' +
                    '<td>发行机构类型：' + json['asset_fxjg_type'] + '</td>' +
                    '</tr><tr>' +
                    '<td>备注：' + json['asset_note'] + '</td>' +
                    '</tr></table>';

                _asset_qx_date = json['asset_qx_date'];
                _asset_dq_date = json['asset_dq_date'];
                _asset_pay_freq = json['asset_pay_freq'];
                _asset_rate = json['asset_rate'];
                _asset_kj_km = json['asset_kj_km'];
                _asset_adjust_base = json['asset_adjust_base'];
                _asset_first_pay_date = json['asset_first_pay_date'];

                $(".asset_info_display").append(innerHTML);
                $('.asset_info_display').hide();
                $('.asset_info_display').toggle('slow');

                //应计利息总额 = ( 交易面额 * 交易收益率 ) / 计息基数 * 持有天数
                //持有天数 = 交易日 - 起息日
                //结算金额  = 交易面额 + 应计利息总额

                var asset_rate = json['asset_rate']; //交易收益率(%)
                var asset_adjust_base = json['asset_adjust_base']; //计息基数
                var asset_mj_money = json['asset_mj_money']; //交易面额
                var deal_date = $('#asset_deal_date').val(); //交易日期
                var asset_qx_date = json['asset_qx_date']; //起息日
                var daymuius = dateDiff(asset_qx_date, deal_date); //持有天数

                //填充交易面额、交易收益率、结算金额、应计利息总额
                $('#asset_deal_rate').val(asset_rate); //交易收益率(%)
                $('#asset_deal_rate').attr("disabled", "disabled");
                $('#asset_deal_rate').css({color: "red"});
                $('#asset_deal_money').val(asset_mj_money);//交易面额
                $('#asset_deal_money').css({color: "red"});
                var invest_total = (asset_mj_money * (asset_rate / 100)) / asset_adjust_base * daymuius;  //应计利息总额
                var js_money = asset_mj_money + invest_total; //结算金额
                $('#asset_intervest_total').val(invest_total.toFixed(2));//应计利息总额
                $('#asset_intervest_total').css({color: "red"});
                $('#asset_js_money').val(js_money.toFixed(2));//结算金额
                $('#asset_js_money').css({color: "red"});
            },
            error: function () {
                alert("获取资产详细信息失败");
            }
        });

    });
}


/*获得产品信息并联动产品余额组件*/
function get_product_data(id, dict_code) {

    get_sel_data(id, dict_code);

    //select下拉框的选择事件
    $('#' + id + '').on('select2:select', function (e) {
        var data = e.params.data;
        var _product_code = data['id'];
        $.ajax({
            url: "/asset_manage/get_product_balance_data",
            type: "get",
            data: {'product_code': _product_code},//发送到服务器的数据。
            dataType: "json",//预期服务器返回的数据类型。
            success: function (json) {
                var _balance = json['pd_balance'];
                $('#asset_product_ye').val(_balance.toFixed(2));
                $('#asset_product_ye').attr("disabled", "disabled");
                $('#asset_product_ye').css({color: "red"});
            },
            error: function () {
                alert("获取产品余额失败");
            }
        });

    });

}


/*保存*/
function save_asset_trusts_plan_deal() {

    /*[交易信息要素]
    * 交易日期 asset_deal_date
    * 交易方向 asset_deal_dirt
    * 资产名称 asset_name
    * 交易对手 opponents_name
    * 交易面额(元) asset_deal_money
    * 交易收益率(%) asset_deal_rate
    * 结算金额(元) asset_js_money
    * 应计利息总额(元) asset_intervest_total
    * 会计分类 kjfl_type
    * 理财产品 asset_product_info
    * 产品余额 asset_product_ye
    * 备注 asset_note
    * */
    var _asset_deal_date = $('#asset_deal_date').val();
    var _asset_deal_dirt = $('#asset_deal_dirt').val();
    var _asset_code = $('#asset_name').val();
    var _opponents_code = $('#opponents_name').val();
    var _asset_deal_money = $('#asset_deal_money').val();
    var _asset_deal_rate = $('#asset_deal_rate').val();
    var _asset_js_money = $('#asset_js_money').val();
    var _asset_intervest_total = $('#asset_intervest_total').val();
    var _kjfl_type = $('#kjfl_type').val();
    var _asset_prod_code = $('#asset_product_info').val();
    var _asset_prod_ye = $('#asset_product_ye').val();
    var _asset_note = $('#asset_note').val();

    /*[资产信息要素]
    * 起息日
    * 到期日
    * 首次付息日
    * 付息频率 -
    * 收益率%
    * 核心会计科目 -
    * 计息基数
    * */



    //判空
    if (_asset_deal_date === null || _asset_deal_dirt === null || _asset_code === null || _opponents_code === null
        || _asset_deal_money === null || _asset_deal_rate === null || _asset_js_money === null || _asset_intervest_total === null
        || _kjfl_type === null || _asset_prod_code === null || _asset_prod_ye === null
    ) {
        $.messager.alert({title: "警告", msg: '请填写完必须采集字段后再提交!', icon: "warning"});
        return;
    }

    //基础判断
    if (_asset_js_money > _asset_prod_ye) {
        $.messager.alert({title: "警告", msg: '产品余额不足,无法完成交易!', icon: "warning"});
        return;
    }

    var pay_freq = _asset_pay_freq.split('-');
    var kj_km = _asset_kj_km.split('-');


    var _asset_trusts_plan_deal_form = new Map();

    //交易要素
    _asset_trusts_plan_deal_form.set('asset_deal_date', _asset_deal_date);//交易日期
    _asset_trusts_plan_deal_form.set('asset_deal_dirt', _asset_deal_dirt);//交易方向
    _asset_trusts_plan_deal_form.set('asset_code', _asset_code);//资产名称
    _asset_trusts_plan_deal_form.set('opponents_code', _opponents_code);//交易面额(元)
    _asset_trusts_plan_deal_form.set('asset_deal_money', _asset_deal_money);//交易收益率(%)
    _asset_trusts_plan_deal_form.set('asset_deal_rate', _asset_deal_rate);//结算金额(元)
    _asset_trusts_plan_deal_form.set('asset_js_money', _asset_js_money);//应计利息总额(元)
    _asset_trusts_plan_deal_form.set('asset_intervest_total', _asset_intervest_total);//
    _asset_trusts_plan_deal_form.set('kjfl_type', _kjfl_type);//会计分类
    _asset_trusts_plan_deal_form.set('asset_prod_code', _asset_prod_code);//理财产品
    _asset_trusts_plan_deal_form.set('asset_prod_ye', _asset_prod_ye);//产品余额
    _asset_trusts_plan_deal_form.set('asset_note', _asset_note);//备注 asset_note

    //资产要素
    _asset_trusts_plan_deal_form.set('asset_qx_date', _asset_qx_date);//起息日
    _asset_trusts_plan_deal_form.set('asset_dq_date', _asset_dq_date);//到期日
    _asset_trusts_plan_deal_form.set('asset_first_pay_date', _asset_first_pay_date);//首次付息日
    _asset_trusts_plan_deal_form.set('asset_pay_freq', pay_freq[0]);//付息频率
    _asset_trusts_plan_deal_form.set('asset_rate', _asset_rate);//收益率%
    _asset_trusts_plan_deal_form.set('asset_kj_km', kj_km[0]);//核心会计科目
    _asset_trusts_plan_deal_form.set('asset_adjust_base', _asset_adjust_base);//计息基数


    let obj = Object.create(null);
    for (let [k, v] of _asset_trusts_plan_deal_form) {
        obj[k] = v;
    }

    /*提交*/
    $.post({
        'url': '/asset_manage/commit_asset_trusts_plan_deal',
        'data': JSON.stringify(obj),
        'success': function (result) {
            reset_asset_trusts_plan_deal();
            $.messager.alert({title: "result", msg: result, icon: "info"});
        },
        'fail': function (error) {
            $.messager.alert({title: "result", msg: error, icon: "warning"});
        }
    });


}


/*重置*/
function reset_asset_trusts_plan_deal() {

    $('#asset_name').val(null).trigger("change");//资产名称
    $('#opponents_name').val(null).trigger("change");//交易对手
    $('#asset_deal_dirt').val(null).trigger("change");//交易方向
    $('#kjfl_type').val(null).trigger("change");//会计分类
    $('#asset_product_info').val(null).trigger("change");//理财产品
    $('.asset_info_display').hide();//资产信息展示区域
    $('#asset_deal_money').val(null);//交易面额(元)
    $('#asset_deal_rate').val(null);//交易收益率(%)
    $('#asset_js_money').val(null);//结算金额(元)
    $('#asset_intervest_total').val(null);//应计利息总额(元)
    $('#asset_product_ye').val(null);//产品余额
    $('#asset_note').val(null);//备注

}


/*计算2个日期相差的天数，不包含今天，如：2016-12-13到2016-12-15，相差2天*/
function dateDiff(startDateString, endDateString) {
    startDateString = startDateString.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3"); //将日期格式从yyyyMMdd转换为yyyy-MM-dd
    endDateString = endDateString.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3");  //将日期格式从yyyyMMdd转换为yyyy-MM-dd
    var separator = "-"; //日期分隔符
    var startDates = startDateString.split(separator);
    var endDates = endDateString.split(separator);
    var startDate = new Date(startDates[0], startDates[1] - 1, startDates[2]);
    var endDate = new Date(endDates[0], endDates[1] - 1, endDates[2]);
    //return parseInt(Math.abs(endDate - startDate) / 1000 / 60 / 60 / 24);//把相差的毫秒数转换为天数
    return parseInt((endDate - startDate) / 1000 / 60 / 60 / 24);//把相差的毫秒数转换为天数
};
