


/*界面初始化*/
$(function () {
   query_asset_interest_confirm();
});


/*获取下拉框数据*/
function get_sel_data(id, dict_code) {
    $('#' + id + '').empty();//清空select框中数据
    $.ajax({
        url: "/asset_manage/get_sel_data",
        type: "get",
        data: {'dict_code': dict_code},//发送到服务器的数据。
        dataType: "json",//预期服务器返回的数据类型。
        success: function (json) {
            $('#' + id + '').select2({
                data: json,
                allowClear: true,//设置allowClear为true，将会在select后加一个X号，可用于快速清空已选项
                placeholder: '-----请选择-----'
            });
            $('#' + id + '').val(null).trigger("change");
            $('#' + id + '').select2("open");
        },
        error: function () {
            alert("获取下拉框数据失败");
        }
    });
}


/*查询数据*/
function query_asset_interest_confirm() {
    var _asset_code = $('#asset_code').val() === null || $('#asset_code').val() === "" ? '%' : $('#asset_code').val(); //资产类型
    var _pay_date = $('#pay_date').val() === null || $('#pay_date').val() === "" ? '%' : $('#pay_date').val(); //交易日期

    layui.use('table', function () {
        var table = layui.table;
        table.render({
            elem: '#test',
            toolbar: true,
            size: 'sm',
            defaultToolbar: ['filter', 'exports', 'print'],
            url: '/asset_manage/asset_interest_confirm_query',
            where: {asset_code: _asset_code, pay_date: _pay_date},
            method: 'post',
            contentType: 'application/json',
            cols: [[
                {field: 'rowno', width: 25, title: '', fixed: 'left', align: 'center'}
                , {field: 'flow_id', width: 25, align: 'center', title: '流水编号', hide: true}
                , {field: 'deal_id', width: 25, align: 'center', title: '交易编号', hide: true}
                , {field: 'reality_cost', width: 150, align: 'center', title: '实际发生金额', edit: 'text',templet: function (d) {
                        return '<span style="color:#f50900;font-weight:bold;">'+d.reality_cost+'</span>'}
                  }
                , {field: 'asset_code', width: 150, align: 'center', title: '资产代码'}
                , {field: 'asset_name', width: 300, align: 'center', title: '资产名称'}
                , {field: 'account_event', width: 200, align: 'center', title: '会计事件'}
                , {field: 'pay_date', width: 100, align: 'center', title: '发生日期'}
                , {field: 'theory_cost', width: 150, align: 'center', title: '理论发生金额'}
                , {field: 'asset_qx_date', width: 100, align: 'center', title: '起息日'}
                , {field: 'asset_dq_date', width: 100, align: 'center', title: '到期日'}
                , {field: 'asset_js_money', width: 150, align: 'center', title: '交易结算金额'}
                , {field: 'asset_rate', width: 150, align: 'center', title: '收益率%'}
                , {field: 'is_confirm', width: 100, align: 'center', title: '现金确认',templet: function (d) {
                        if (d.is_confirm === '未确认') {return '<span style="color:#f50900;font-weight:bold;">'+d.is_confirm+'</span>'
                        } else {return '<span style="color:#0624b3;font-weight:bold;">'+d.is_confirm+'</span>'}}
                  }
                , {field: 'confirm_date', width: 100, align: 'center', title: '确认日期'}
                , {fixed: 'right', width: 200, title: '操作', align: 'center', toolbar: '#barDemo'} //这里的toolbar值是模板元素的选择器
            ]],
            page: true,
            request: {  //用于对分页请求的参数：page、limit重新设定名称
                pageName: 'pageNumber', //页码的参数名称，默认：page
                limitName: 'pageSize' //每页数据量的参数名，默认：limit
            },
            response: {
                countName: 'total',
                dataName: 'rows'
            }
        });

        //监听行工具事件
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            console.log(obj);
            if (obj.event === 'confirm') {  //确认
                var _pay_date = data['pay_date'];
                var _today = get_today_yyyymmdd();
                if (String(_pay_date) != String(_today)) {
                    layui.use('layer', function () {
                        layer.msg('今日不是该笔资产的存续期确认日!', {
                            offset: '200px',
                            time: 3000 //1s后自动关闭
                        });
                    });
                }else {

                }

            } else if (obj.event === 'delay') { //延期
                layer.open({
                    title: '资产收息延期',
                    type: 1, //基本层类型：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    closeBtn: false,
                    offset:'200px',
                    area: '375px;',
                    shade: 0.3,
                    id: 'LAY_layuipro_modify_delay_date', //设定一个id，防止重复弹出
                    btn: ['确认', '取消'],
                    btnAlign: 'c',
                    moveType: 1, //拖拽模式，0或者1
                    content: '<div style="padding: 50px; line-height: 22px; background-color: #fff; color: #393D49; font-weight: 300;">' +
                             '<input name="delay_date" id="delay_date" type="txt" placeholder="请选择延期日期..." style="height: 40px;width: 100%;" autocomplete="off">' +
                             '</div>'+
                             '<script>'+
                             'layui.use(\'laydate\', function () {'+
                                'var laydate = layui.laydate;'+
                                'laydate.render({'+
                                'elem: \'#delay_date\','+
                                'theme: \'molv\','+
                                'format: \'yyyyMMdd\'' +
                                '});});' +
                             '</script>',
                    yes: function (index, layero) {

                        var _today = get_today_yyyymmdd();
                        var _delay_date = $('#delay_date').val();
                        if (parseInt(_delay_date) <= parseInt(_today)) {
                            layui.use('layer', function () {
                                layer.msg('延期日期应大于当前日期!', {
                                    offset: '200px',
                                    time: 3000 //1s后自动关闭
                                });
                            });
                        } else {
                            var _json = {'deal_id': data['deal_id'], 'flow_id': data['flow_id'], 'delay_date': _delay_date};
                            $.post({
                                'url': '/asset_manage/asset_interest_confirm_delayed',
                                'data': JSON.stringify(_json),
                                'success': function (_data) {
                                    alert(_data);
                                    layer.close(index);
                                    table.reload('test', {
                                        url: '/asset_manage/asset_interest_confirm_query',
                                        where: {asset_code: _asset_code, pay_date: _pay_date},
                                    });
                                },
                                'fail': function (error) {
                                    alert(error);
                                }
                            });
                        }
                    }
                });
            }
        });
    });


}