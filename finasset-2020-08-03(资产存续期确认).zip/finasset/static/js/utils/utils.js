


/*
* author:ruanyemao
* date:2020-08-03
* descrip:常用工具js
* */


/*返回yyyyMMdd格式的日期字符串*/
function get_today_yyyymmdd() {

    var tdate = new Date();
    var year = tdate.getFullYear();
    var month = tdate.getMonth() < 10 ? '0' + (tdate.getMonth() + 1) : (tdate.getMonth() + 1);
    var dates = tdate.getDate() < 10 ? '0' + (tdate.getDate()) : (tdate.getDate());

    return year + '' + month + '' + dates;

}