create or replace view v_fas_product_detail_info as
select t.pd_code,
       t.pd_name,
       t.pd_mode || '-' || a1.item_value as pd_mode,
       t.pd_zz_code,
       t.pd_type || '-' || a2.item_value as pd_type,
       t.pd_colect_type || '-' || a3.item_value as pd_colect_type,
       t.pd_risk_level || '-' || a4.item_value as pd_risk_level,
       t.pd_profit_type || '-' || a5.item_value as pd_profit_type,
       t.pd_adjust_type || '-' || a6.item_value as pd_adjust_type,
       t.pd_interest_base || '-' || a7.item_value as pd_interest_base,
       t.pd_rg_bg_date,
       t.pd_rg_ov_date,
       t.pd_fx_b_date,
       t.pd_sy_b_date,
       t.pd_open_b_date,
       t.pd_open_o_date,
       t.pd_ov_date,
       t.pd_df_date,
       t.pd_life_statu || '-' || a8.item_value as pd_life_statu,
       t.pd_verify_person || '-' || a27.item_value as pd_verify_person,
       t.pd_verify_certi,
       t.pd_desiner_name || '-' || a28.item_value as pd_desiner_name,
       t.pd_desiner_certi,
       t.investmanage_name || '-' || a29.item_value as investmanage_name,
       t.investmanage_zj,
       t.ywry_name || '-' || a30.item_value as ywry_name,
       t.ywry_zj_phone,
       t.ywry_yd_phone,
       t.ywry_mail,
       t.zj_tx || '-' || a9.item_value as zj_tx,
       t.lc_fw_type || '-' || a10.item_value as lc_fw_type,
       t.prod_manager_mode || '-' || a11.item_value as prod_manager_mode,
       t.invest_pz_type || '-' || a12.item_value as invest_pz_type,
       t.dj_fs || '-' || a13.item_value as dj_fs,
       t.tz_zc_type || '-' || a14.item_value as tz_zc_type,
       t.hezuo_mode || '-' || a15.item_value as hezuo_mode,
       t.prod_zengxin_flag || '-' || a16.item_value as prod_zengxin_flag,
       t.prod_zengxin_comp || '-' || a17.item_value as prod_zengxin_comp,
       t.prod_zengxin_xingshi || '-' || a18.item_value as prod_zengxin_xingshi,
       t.prod_pingpai,
       t.prod_qishu,
       t.sale_channel_dif || '-' || a19.item_value as sale_channel_dif,
       t.touzi_zhonglei_bili,
       t.jianguan_guanli_fs || '-' || a20.item_value as jianguan_guanli_fs,
       t.jianguan_muji_fs || '-' || a21.item_value as jianguan_muji_fs,
       t.jianguan_kuaijihesuan_fs || '-' || a22.item_value as jianguan_kuaijihesuan_fs,
       t.jianguan_shouyi_bz || '-' || a23.item_value as jianguan_shouyi_bz,
       t.jianguan_benjinbz_bz || '-' || a24.item_value as jianguan_benjinbz_bz,
       t.jianguan_tiqianzhongzhi_bz || '-' || a25.item_value as jianguan_tiqianzhongzhi_bz,
       t.jianguan_shuhui_bz || '-' || a26.item_value as jianguan_shuhui_bz,
       t.jianguan_tuoguan_jwai_daima,
       jianguan_tuoguan_jnei_mc || '-' || a38.eb_name as jianguan_tuoguan_jnei_mc,
       t.jianguan_tuoguan_jwai_gb,
       t.jianguan_tuoguan_jwai_mc,
       t.pd_cpqx || '-' || a31.item_value as pd_cpqx,
       t.pd_tongyezs || '-' || a32.item_value as pd_tongyezs,
       t.pd_setholdtime || '-' || a33.item_value as pd_setholdtime,
       t.pd_holddate,
       t.pd_tzshouy_dzr || '-' || a34.item_value as pd_tzshouy_dzr,
       t.pd_xjmanagertype || '-' || a35.item_value as pd_xjmanagertype,
       t.pd_beginsalemoney,
       t.pd_salerate,
       t.pd_tuoguangrate,
       t.pd_plancolectmoney,
       t.pd_investmanagerate,
       t.pd_tzbenjin_dzr || '-' || a36.item_value as pd_tzbenjin_dzr,
       t.pd_freeback || '-' || a37.item_value as pd_freeback,
       t.pd_base_rate,
       t.pd_mode as pd_mode_condition,
       t.jianguan_muji_fs as jianguan_muji_fs_condition

  from fas_prod_info t,
     (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_mode') a1, --��Ʒģʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_type') a2,--��Ʒ����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_colect_type') a3,--ļ������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_risk_level') a4,--���յȼ�
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_profit_type') a5,--�����ص�
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_adjust_type') a6,--���㷽ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_interest_base') a7,--��Ϣ����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_life_statu') a8,   --��Ʒ����״̬
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'zj_tx') a9,   --�ʽ�Ͷ���
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'lc_fw_type') a10,   --���Ʒ���ģʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_manager_mode') a11,   --��Ʒ����ģʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'invest_pz_type') a12,   --�ʲ����÷�ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'dj_fs') a13,   --��Ʒ���۷�ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'tz_zc_type') a14,   --Ͷ���ʲ�����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'hezuo_mode') a15,   --����ģʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_flag') a16,   --��Ʒ���ű�ʶ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_comp') a17,   --��Ʒ���Ż���
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'prod_zengxin_xingshi') a18,   --��Ʒ������ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'sale_channel_dif') a19,   --������������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_guanli_fs') a20,   --������ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_muji_fs') a21,   --ļ����ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_kuaijihesuan_fs') a22,   --��ƺ��㷽ʽ
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shouyi_bz') a23,   --���汣֤��־
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_benjinbz_bz') a24,   --�����ϱ�־
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_tiqianzhongzhi_bz') a25,   --����ǰ��ֹ��־
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'jianguan_shuhui_bz') a26,    --�����Ȩ��־
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_verify_person') a27,    --����������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_desiner_name') a28,    --���������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'investmanage_name') a29,    --Ͷ�ʾ�������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'ywry_name') a30,    --ҵ����Ա����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_cpqx') a31, --��Ʒ����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tongyezs') a32, --�Ƿ�ͬҵר��
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_setholdtime') a33, --������̳�������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzshouy_dzr') a34, --Ͷ�����浽����
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_xjmanagertype') a35, --�Ƿ��ֽ������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_tzbenjin_dzr') a36, --Ͷ�ʱ�������
       (select a.item_key,a.item_value from fas_sys_dict a where a.dict_code = 'pd_freeback') a37, --������ر�ʶ
       (select a.eb_code,a.eb_name from fas_escrow_bank_info a) a38 --�й���
 where t.pd_mode = a1.item_key(+)
   and t.pd_type = a2.item_key(+)
   and t.pd_colect_type = a3.item_key(+)
   and t.pd_risk_level = a4.item_key(+)
   and t.pd_profit_type = a5.item_key(+)
   and t.pd_adjust_type = a6.item_key(+)
   and t.pd_interest_base = a7.item_key(+)
   and t.pd_life_statu = a8.item_key(+)
   and t.zj_tx = a9.item_key(+)
   and t.lc_fw_type = a10.item_key(+)
   and t.prod_manager_mode = a11.item_key(+)
   and t.invest_pz_type = a12.item_key(+)
   and t.dj_fs = a13.item_key(+)
   and t.tz_zc_type = a14.item_key(+)
   and t.hezuo_mode = a15.item_key(+)
   and t.prod_zengxin_flag = a16.item_key(+)
   and t.prod_zengxin_comp = a17.item_key(+)
   and t.prod_zengxin_xingshi = a18.item_key(+)
   and t.sale_channel_dif = a19.item_key(+)
   and t.jianguan_guanli_fs = a20.item_key(+)
   and t.jianguan_muji_fs = a21.item_key(+)
   and t.jianguan_kuaijihesuan_fs = a22.item_key(+)
   and t.jianguan_shouyi_bz = a23.item_key(+)
   and t.jianguan_benjinbz_bz = a24.item_key(+)
   and t.jianguan_tiqianzhongzhi_bz = a25.item_key(+)
   and t.jianguan_shuhui_bz = a26.item_key(+)
   and t.pd_verify_person = a27.item_key(+)
   and t.pd_desiner_name = a28.item_key(+)
   and t.investmanage_name = a29.item_key(+)
   and t.ywry_name = a30.item_key(+)
   and t.pd_cpqx = a31.item_key(+)
   and t.pd_tongyezs = a32.item_key(+)
   and t.pd_setholdtime = a33.item_key(+)
   and t.pd_tzshouy_dzr = a34.item_key(+)
   and t.pd_xjmanagertype = a35.item_key(+)
   and t.pd_tzbenjin_dzr = a36.item_key(+)
   and t.pd_freeback = a37.item_key(+)
   and t.jianguan_tuoguan_jnei_mc = a38.eb_code(+)
;
