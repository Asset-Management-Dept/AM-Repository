???prompt Importing table FAS_SYS_DICT...
set feedback off
set define off
insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_mode', '产品模式', '03', '开放式净值型', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_mode', '产品模式', '04', '开放式非净值型', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '001', '债券及货币市场类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '002', '债权类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '003', '货币市场类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '004', '股权类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '005', '混合类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '006', '商品及金融衍生品', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '007', '固定收益类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '008', '其他', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '009', '结构性', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_type', '产品类型', '010', 'QDII', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_colect_type', '募集币种', '001', '人民币', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_colect_type', '募集币种', '002', '美元', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_colect_type', '募集币种', '003', '其他', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_risk_level', '风险等级', '01', '一级(低)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_risk_level', '风险等级', '02', '二级(中低)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_risk_level', '风险等级', '03', '三级(中)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_risk_level', '风险等级', '04', '四级(中高)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_risk_level', '风险等级', '05', '五级(高)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_profit_type', '收益特点', '03', '非保本浮动收益', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_profit_type', '收益特点', '02', '保本浮动收益', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_profit_type', '收益特点', '01', '保本收益', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_adjust_type', '核算方式', '001', '按净值', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_adjust_type', '核算方式', '002', '按收益', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_interest_base', '计息基数', '001', '360天', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_interest_base', '计息基数', '002', '365天', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_interest_base', '计息基数', '003', '366天', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_life_statu', '产品状态', '001', '募集', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_life_statu', '产品状态', '002', '成立', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_life_statu', '产品状态', '003', '存续', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_life_statu', '产品状态', '004', '终止', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('sale_channel_dif', '销售渠道划分', '001', '一般个人客户', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('sale_channel_dif', '销售渠道划分', '002', '高资产净值客户', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('sale_channel_dif', '销售渠道划分', '003', '私人银行客户', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('sale_channel_dif', '销售渠道划分', '004', '机构客户专属', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('sale_channel_dif', '销售渠道划分', '005', '金融同业专属', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '001', '银行存款类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '002', '理财直销融资工具类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '003', '新增可投资资产类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '004', '公募基金类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '005', '私募基金类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '006', '产业基金类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '007', '衍生品类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('tz_zc_type', '投资资产类型', '008', '商品类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_comp', '产品增信机构', '001', '广义政府', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_comp', '产品增信机构', '002', '非金融性公司', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_comp', '产品增信机构', '003', '金融性公司', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_comp', '产品增信机构', '004', '住户部门', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_comp', '产品增信机构', '005', '国外部门', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '04', '银基', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '03', '银保', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('invest_pz_type', '资产配置方式', '003', '其他配置(多对多)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('invest_pz_type', '资产配置方式', '002', '资产组合配置(一对多)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('invest_pz_type', '资产配置方式', '001', '单一资产配置(一对一)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_manager_mode', '产品管理模式', '004', '特殊目的载体(SPV)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_manager_mode', '产品管理模式', '003', '资产管理公司', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_manager_mode', '产品管理模式', '002', '其他机构为实际管理人', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_manager_mode', '产品管理模式', '001', '银行为实际管理人', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('lc_fw_type', '理财服务模式', '003', '其他', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('lc_fw_type', '理财服务模式', '002', '理财顾问服务', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('lc_fw_type', '理财服务模式', '001', '综合理财服务', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('zj_tx', '资金投向地', '003', '境内和境外', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('zj_tx', '资金投向地', '002', '境外', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('zj_tx', '资金投向地', '001', '境内', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '02', '银信', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '01', '独立运作', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('dj_fs', '产品定价方式', '03', '综合定价', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('dj_fs', '产品定价方式', '02', '成本法定价', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('dj_fs', '产品定价方式', '01', '公允价值定价', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_xingshi', '产品增信形式', '03', '内外增级', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_xingshi', '产品增信形式', '02', '外部增级', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_xingshi', '产品增信形式', '01', '内部增级', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '07', '混合类', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '99', '其他', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('hezuo_mode', '合作模式', '05', '银证', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_benjinbz_bz', '本金保障标志', '002', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_benjinbz_bz', '本金保障标志', '001', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_shouyi_bz', '收益保证标志', '002', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_shouyi_bz', '收益保证标志', '001', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_kuaijihesuan_fs', '会计核算方式', '002', '表外', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_kuaijihesuan_fs', '会计核算方式', '001', '表内', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_muji_fs', '募集方式', '002', '私募', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_muji_fs', '募集方式', '001', '公募', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_guanli_fs', '管理方式', '002', '单独管理', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_guanli_fs', '管理方式', '001', '集合管理', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_flag', '产品增信标识', '02', '无', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('prod_zengxin_flag', '产品增信标识', '01', '有', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_shuhui_bz', '可赎回权标志', '002', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_shuhui_bz', '可赎回权标志', '001', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_tiqianzhongzhi_bz', '可提前终止标志', '002', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('jianguan_tiqianzhongzhi_bz', '可提前终止标志', '001', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '006', '屈美容', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '005', '欧婉琳', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '004', '陈雅雯', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '003', '阮业茂', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '001', '沈丽娜', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_verify_person', '审批人姓名', '003', '邓黎阳', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_verify_person', '审批人姓名', '002', '段喜生', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_verify_person', '审批人姓名', '001', '王劲华', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '002', '陈晓漫', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('investmanage_name', '投资经理姓名', '001', '沈丽娜', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '006', '屈美容', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '005', '欧婉琳', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '004', '陈雅雯', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '003', '阮业茂', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_desiner_name', '设计人姓名', '002', '陈晓漫', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '006', '屈美容', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '005', '欧婉琳', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '004', '陈雅雯', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '003', '阮业茂', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '002', '陈晓漫', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('ywry_name', '业务人员姓名', '001', '沈丽娜', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_mode', '产品模式', '02', '封闭式非净值型', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_mode', '产品模式', '01', '封闭式净值型', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_freeback', '最短持有期后是否自由赎回', '02', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_freeback', '最短持有期后是否自由赎回', '01', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_setholdtime', '是否设置最短持有期限', '02', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_setholdtime', '是否设置最短持有期限', '01', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tongyezs', '是否同业专属', '02', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tongyezs', '是否同业专属', '01', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '09', '3年以上', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '08', '1-3年(含)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '06', '6-12个月(含)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '05', '3-6个月(含)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '04', '1-3个月(含)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '03', '7天-1个月(含)', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '02', '7天(含)以内', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_cpqx', '产品期限', '01', 'T+0产品', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '06', 'T+5及以上', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '05', 'T+4', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '04', 'T+3', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '03', 'T+2', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '02', 'T+1', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzshouy_dzr', '投资收益到账日', '01', 'T+0', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '06', 'T+5及以上', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '05', 'T+4', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '04', 'T+3', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '03', 'T+2', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '02', 'T+1', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_tzbenjin_dzr', '投资本金到账日', '01', 'T+0', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_xjmanagertype', '是否现金管理类', '02', '否', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_xjmanagertype', '是否现金管理类', '01', '是', 'Y');

insert into FAS_SYS_DICT (DICT_CODE, DICT_NAME, ITEM_KEY, ITEM_VALUE, USE_FLAG)
values ('pd_freeback', '最短持有期后是否自由赎回', '99', '其他', 'Y');

prompt Done.
