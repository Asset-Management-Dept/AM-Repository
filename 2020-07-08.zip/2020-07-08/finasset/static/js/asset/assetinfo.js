

/*从wind咨询上获取债券的基础信息 104506.IB*/
function get_bond_data() {

    var _bond_code = $('#bond_code').val();
    var jsonstr = {"bond_code":_bond_code};
    $.get({
        'url': '/asset_manage/get_bond_info',
        'data':jsonstr,
        'beforeSend' : function(){
            $('#win').window({
                width:200,
                height:70,
                modal:true,
                title:'   ',
                collapsible:false,
                minimizable:false,
                maximizable:false,
                closable:false,
                draggable:false,
                resizable:false,
                content:'正在查询中，请稍等....'
            });
         },
        'success':function (_data) {
            var jsonObject= jQuery.parseJSON(_data);
            for(key in jsonObject) {
                $('#' + key + '').val(jsonObject[key]);
                $('#' + key + '').attr("disabled", true);
            }
         },
        'fail':function(error){
            alert(error);
        },
        'complete': function(){
            $('#win').window('close');
        }
    })
}

function save_bond_data() {
    //do nothing
}



