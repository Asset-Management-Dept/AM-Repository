from flask import Blueprint
from config import templates_dir, static_dir

asset_manage = Blueprint('asset_manage',
                        __name__,
                        template_folder=templates_dir,
                        static_folder=static_dir)  # 创建一个蓝图对象，设置别名，模板文件地址，静态文件地址

from fasset.asset_manage import views  # 这里导入是为了在解释时，蓝图能加载到views文件中的路由数据