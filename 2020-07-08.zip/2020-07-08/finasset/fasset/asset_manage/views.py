from fasset.asset_manage import asset_manage  # 获取蓝图
from flask import render_template, request
from utils.DataTypeEncoder import DateEncoder
import json
from WindPy import w


# 资产信息维护
@asset_manage.route("/assetinfo")
def assetinfo():
    return render_template("asset_manage/assetinfo.html")


# 资产信息维护 - 获取债券信息
@asset_manage.route("/get_bond_info", methods=['POST', 'GET'])
def get_bond_info():

    if request.method == 'GET':
        _bond_code = request.args.get("bond_code")
        # 启动windpy
        w.start()
        if w.isconnected():
            _WindData = w.wss(_bond_code,
                              "fullname,issuerupdated,par,couponrate,latestpar,carrydate,maturitydate,term,interesttype,paymenttype,"
                              "actualbenchmark,coupon,abs_industry,abs_industry1,abs_province,net_cfets,dirty_cfets",
                              "tradeDate=20200701")
            w.stop()
            # 若获取成功则将结果放入队列queque中
            if _WindData.ErrorCode == 0:
                _bond_data = _WindData.Data
                _bond_field = _WindData.Fields
                _bond_data_list = []
                for _i in _bond_data:
                    _bond_data_list.append(_i[0])
                # 将两个列表转化为dict(x,y),x=[x1,x2,x3],y=[y1,y2,y3] -> dict = {"x1":"y1","x2","y2","x3":"y3"}
                _bonddict = dict(zip(_bond_field,_bond_data_list))

                for k, v in _bonddict.items():
                   print('------------',k,':', v)

            else:
                _bonddict = {"wind", "not data"}
        else:
            print('------------未连接---------------')
        _resultjson = json.dumps(_bonddict, cls=DateEncoder)

        return _resultjson
    else:
        return ""



# 资产穿透维护
@asset_manage.route("/assetthrough")
def assetthrough():
    return render_template("asset_manage/assetthrough.html")