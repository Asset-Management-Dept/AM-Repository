from config import db



class FAS_ESCROW_BANK_INFO(db.Model):

    '托管行信息表'  # __doc__属性的值

    # 表名
    __tablename__ = 'fas_escrow_bank_info'

    # 模型对应的字段
    eb_code = db.Column(db.String(40), primary_key=True, autoincrement=True)  # 托管行代码
    eb_name = db.Column(db.String(120))  # 托管行名称
    eb_open_bank_name = db.Column(db.String(120))  # 托管行开户行名称
    eb_account_name = db.Column(db.String(120))  # 开户名
    eb_account_no = db.Column(db.String(120))  # 开户账号
    eb_area = db.Column(db.String(12))  # 所在区域

    # 构造函数
    def __init__(self, eb_code, eb_name, eb_open_bank_name, eb_account_name, eb_account_no, eb_area):
        self.eb_code = eb_code
        self.eb_name = eb_name
        self.eb_open_bank_name = eb_open_bank_name
        self.eb_account_name = eb_account_name
        self.eb_account_no = eb_account_no
        self.eb_area = eb_area
