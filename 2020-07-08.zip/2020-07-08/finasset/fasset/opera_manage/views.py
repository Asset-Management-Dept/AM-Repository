from fasset.opera_manage import opera_manage
from flask import render_template, request
from fasset.opera_manage.SqlConfig import *
from utils.DbUtils import DbUtil
from sqlalchemy import text
from fasset import db
from utils.DataTypeEncoder import DecimalEncoder
import json


# 档案管理界面
@opera_manage.route("/archives_manage_info",methods=['POST','GET'])
def archives_manage_info():

    # 界面首次访问返回
    if request.method == 'GET':
        return render_template("opera_manage/archives_manage_info.html")

    # 界面初始化
    if request.method == 'POST':
        _json_ebcode = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _json_ebcode['pd_code']
        _pageSize = _json_ebcode['pageSize']  # 分页-数据
        _pageNumber = _json_ebcode['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)
        _sql_archives_info_query = SQL_ARCHIVES_INFO_QUERY  # 档案信息查询sql
        _sql_archives_count_query = SQL_ARCHIVES_INFO_COUNT_QUERY  # 档案信息数量count
        _sql_condition = ""

        # 拼接[产品代码]参数条件
        if _pd_code == '%':
            _sql_condition = _sql_condition + ' and t.pd_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.pd_code=:pd_code '

        # 分页SQL语句-详细信息
        _sql_archives_info_query_all = """select * from (select * from (""" \
                                   + _sql_archives_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_archives_count_query + _sql_condition

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_archives_info_query_all), {"pd_code": _pd_code})
            resulttotal = session.execute(text(_sql_count_query_all), {"pd_code": _pd_code})

        except Exception as e:
            print(e)

        _results_prod_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        resList = []
        # 将明细数压入List
        for _rpiq in _results_prod_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
            resList.append(rowDict_info)

        _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

        _result_json = json.dumps(_return_dict,cls=DecimalEncoder)

        print('----------------------------------------------档案管理信息最终查询返回的结果为：' + _result_json)

        return _result_json
