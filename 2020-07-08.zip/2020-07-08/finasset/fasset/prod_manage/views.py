from fasset.prod_manage import prod_manage
from fasset.prod_manage.models import FAS_PROD_INFO, FAS_PROD_SALE_INFO
from flask import render_template, request
from fasset import db
from utils.DbUtils import DbUtil
from utils.DataTypeEncoder import DecimalEncoder
from sqlalchemy import text
from fasset.prod_manage.SqlConfig import *
import json

'''
author:ruanyema
date:2020-06-20
descrip:路由模块
'''


# 模块：产品录入界面
# 1.直接通过菜单访问
# 2.通过产品信息查询-鼠标右键复制其他产品信息来创建产品
# 3.通过产品信息查询-鼠标右键修改产品信息
@prod_manage.route("/prod_info_collect", methods=['POST', 'GET'])
def prod_info_collect():
    _pk = request.args.get("primary_key")
    _request_type = request.args.get("request_type")
    if _pk:
        _sql_copy = SQL_COPY_PRODUCT_INFO + ' and t.pd_code=:pd_code_val'
        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_copy), {"pd_code_val": _pk})
        except Exception as e:
            print(e)

        # 数据结果为元组: (val1,val2,val3,val4,....)
        _results_details_info = resultproxy.fetchall()
        for _rt in _results_details_info:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        # dumps函数是将dict数据转化为str数据,但是dict数据中若包含byte数据、Decimal数据、date数据等等，就会导致json.dumps()转换为JSON格式对象时报错：
        # TypeError: Object of type Decimal is not JSON serializable
        # 新建一个DecimalEncoder类来[Decimal]类型的数据格式化为str

        # 复制产品信息
        if _request_type == 'copy':
            _return_dict["access_flag"] = "copy"

        # 修改产品信息
        if _request_type == 'modify':
            _return_dict["access_flag"] = "modify"

        _result_json = json.dumps(_return_dict, cls=DecimalEncoder)
        return render_template("prod_manage/prodinfo.html", _result_json=_result_json)

    else:

        _result_json = json.dumps({"access_flag": "init"})
        return render_template("prod_manage/prodinfo.html", _result_json=_result_json)


# 产品新增保存
# 产品修改保存
# 产品复制保存
@prod_manage.route("/commit_product_info", methods=['POST', 'GET'])
def commit_product_info():
    if request.method == 'POST':

        _product_form = json.loads(request.get_data(as_text=True))  # 载入json对象

        _operation_type = _product_form['operation_type']  # new:新增产品、copy:复制产品、modify:修改产品

        # 基本信息
        _pd_mode = _product_form['pd_mode']  # 产品模式:01-开放式,02-封闭式
        _pd_code = _product_form['pd_code']  # 产品代码
        _pd_zz_code = _product_form['pd_zz_code']  # 中债编码
        _pd_name = _product_form['pd_name']  # 产品名称
        _pd_type = _product_form['pd_type']  # 产品类型
        _pd_colect_type = _product_form['pd_colect_type']  # 募集币种
        _pd_risk_level = _product_form['pd_risk_level']  # 风险等级
        _pd_profit_type = _product_form['pd_profit_type']  # 收益特点
        _pd_adjust_type = _product_form['pd_adjust_type']  # 核算方式
        _pd_interest_base = _product_form['pd_interest_base']  # 计息基数
        _pd_life_statu = _product_form['pd_life_statu']  # 产品状态
        # 时间信息
        _pd_rg_bg_date = _product_form['pd_rg_bg_date']  # 认购开始日期
        _pd_rg_ov_date = _product_form['pd_rg_ov_date']  # 认购结束日期
        _pd_fx_b_date = _product_form['pd_fx_b_date']  # 发行成立日期
        _pd_sy_b_date = _product_form['pd_sy_b_date']  # 收益起始日期
        _pd_open_b_date = _product_form['pd_open_b_date']  # 开放起始日期
        _pd_open_o_date = _product_form['pd_open_o_date']  # 开放结束日期
        _pd_ov_date = _product_form['pd_ov_date']  # 产品清盘日期
        _pd_df_date = _product_form['pd_df_date']  # 产品兑付日期

        # 中债登信息
        _pd_verify_person = _product_form['pd_verify_person']  # 审批人姓名
        _pd_verify_certi = _product_form['pd_verify_certi']  # 审批人证件
        _pd_desiner_name = _product_form['pd_desiner_name']  # 设计人姓名
        _pd_desiner_certi = _product_form['pd_desiner_certi']  # 设计人证件

        _investmanage_name = _product_form['investmanage_name']
        _investmanage_zj = _product_form['investmanage_zj']
        _ywry_name = _product_form['ywry_name']
        _ywry_zj_phone = _product_form['ywry_zj_phone']
        _ywry_yd_phone = _product_form['ywry_yd_phone']
        _ywry_mail = _product_form['ywry_mail']
        _zj_tx = _product_form['zj_tx']
        _lc_fw_type = _product_form['lc_fw_type']
        _prod_manager_mode = _product_form['prod_manager_mode']
        _invest_pz_type = _product_form['invest_pz_type']
        _dj_fs = _product_form['dj_fs']
        _tz_zc_type = _product_form['tz_zc_type']
        _hezuo_mode = _product_form['hezuo_mode']
        _prod_zengxin_flag = _product_form['prod_zengxin_flag']
        _prod_zengxin_comp = _product_form['prod_zengxin_comp']
        _prod_zengxin_xingshi = _product_form['prod_zengxin_xingshi']
        _prod_pingpai = _product_form['prod_pingpai']
        _prod_qishu = _product_form['prod_qishu']
        _sale_channel_dif = _product_form['sale_channel_dif']
        _touzi_zhonglei_bili = _product_form['touzi_zhonglei_bili']

        # 监管数据信息
        _jianguan_guanli_fs = _product_form['jianguan_guanli_fs']
        _jianguan_muji_fs = _product_form['jianguan_muji_fs']
        _jianguan_kuaijihesuan_fs = _product_form['jianguan_kuaijihesuan_fs']
        _jianguan_shouyi_bz = _product_form['jianguan_shouyi_bz']
        _jianguan_benjinbz_bz = _product_form['jianguan_benjinbz_bz']
        _jianguan_tiqianzhongzhi_bz = _product_form['jianguan_tiqianzhongzhi_bz']
        _jianguan_shuhui_bz = _product_form['jianguan_shuhui_bz']
        _jianguan_tuoguan_jwai_daima = _product_form['jianguan_tuoguan_jwai_daima']
        _jianguan_tuoguan_jnei_mc = _product_form['jianguan_tuoguan_jnei_mc']
        _jianguan_tuoguan_jwai_gb = _product_form['jianguan_tuoguan_jwai_gb']
        _jianguan_tuoguan_jwai_mc = _product_form['jianguan_tuoguan_jwai_mc']

        # 2020-06-30新增13个字段
        _pd_cpqx = _product_form['pd_cpqx']
        _pd_tongyezs = _product_form['pd_tongyezs']
        _pd_setholdtime = _product_form['pd_setholdtime']
        _pd_holddate = _product_form['pd_holddate']
        _pd_tzshouy_dzr = _product_form['pd_tzshouy_dzr']
        _pd_xjmanagertype = _product_form['pd_xjmanagertype']
        _pd_beginsalemoney = _product_form['pd_beginsalemoney']
        _pd_salerate = _product_form['pd_salerate']
        _pd_tuoguangrate = _product_form['pd_tuoguangrate']
        _pd_plancolectmoney = _product_form['pd_plancolectmoney']
        _pd_investmanagerate = _product_form['pd_investmanagerate']
        _pd_tzbenjin_dzr = _product_form['pd_tzbenjin_dzr']
        _pd_freeback = _product_form['pd_freeback']

        # 2020-07-03新增1个字段
        _pd_base_rate = _product_form['pd_base_rate']

        items = _product_form.items()
        for key, value in items:
            print('---------------------------前台传递过来的参数：' + str(key) + '=' + str(value))

        # 新增产品
        if _operation_type == 'new':
            _handle_result = new_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type,
                                              _pd_risk_level, _pd_profit_type,
                                              _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date,
                                              _pd_fx_b_date, _pd_sy_b_date,
                                              _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date,
                                              _pd_life_statu, _pd_verify_person,
                                              _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name,
                                              _investmanage_zj,
                                              _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx,
                                              _lc_fw_type,
                                              _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode,
                                              _prod_zengxin_flag,
                                              _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu,
                                              _sale_channel_dif, _touzi_zhonglei_bili,
                                              _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                                              _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                                              _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima,
                                              _jianguan_tuoguan_jnei_mc, _jianguan_tuoguan_jwai_gb,
                                              _jianguan_tuoguan_jwai_mc,
                                              _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr,
                                              _pd_xjmanagertype,
                                              _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                                              _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate)

        # 复制产品
        if _operation_type == 'copy':
            _handle_result = copy_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type,
                                               _pd_risk_level, _pd_profit_type,
                                               _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date,
                                               _pd_fx_b_date, _pd_sy_b_date,
                                               _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date,
                                               _pd_life_statu, _pd_verify_person,
                                               _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi,
                                               _investmanage_name, _investmanage_zj,
                                               _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx,
                                               _lc_fw_type,
                                               _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode,
                                               _prod_zengxin_flag,
                                               _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu,
                                               _sale_channel_dif, _touzi_zhonglei_bili,
                                               _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                                               _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                                               _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima,
                                               _jianguan_tuoguan_jnei_mc, _jianguan_tuoguan_jwai_gb,
                                               _jianguan_tuoguan_jwai_mc,
                                               _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr,
                                               _pd_xjmanagertype,
                                               _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                                               _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate)

        # 修改产品
        if _operation_type == 'modify':
            _handle_result = modify_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type,
                                                 _pd_risk_level, _pd_profit_type,
                                                 _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date,
                                                 _pd_fx_b_date, _pd_sy_b_date,
                                                 _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date,
                                                 _pd_life_statu, _pd_verify_person,
                                                 _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi,
                                                 _investmanage_name, _investmanage_zj,
                                                 _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx,
                                                 _lc_fw_type,
                                                 _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode,
                                                 _prod_zengxin_flag,
                                                 _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu,
                                                 _sale_channel_dif, _touzi_zhonglei_bili,
                                                 _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                                                 _jianguan_shouyi_bz, _jianguan_benjinbz_bz,
                                                 _jianguan_tiqianzhongzhi_bz,
                                                 _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima,
                                                 _jianguan_tuoguan_jnei_mc, _jianguan_tuoguan_jwai_gb,
                                                 _jianguan_tuoguan_jwai_mc,
                                                 _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr,
                                                 _pd_xjmanagertype,
                                                 _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate,
                                                 _pd_plancolectmoney,
                                                 _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate)

        return _handle_result


# 产品信息查询界面
@prod_manage.route("/prodqury", methods=['POST', 'GET'])
def prodqury():
    if request.method == 'GET':
        return render_template("prod_manage/prodqury.html")

    if request.method == 'POST':
        _query_json = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pageSize = _query_json['pageSize']  # 分页-数据
        _pageNumber = _query_json['pageNumber']  # 分页-页面数
        _prod_code = _query_json['prod_code']  # 产品代码
        _prod_mode = _query_json['prod_mode']  # 产品模式
        _jianguan_muji_fs = _query_json['jianguan_muji_fs']  # 募集方式
        _fx_b_date = _query_json['fx_b_date']  # 发行成立日期

        print('前台传值:pageSize', _pageSize)
        print('前台传值:pageNumber', _pageNumber)
        print('前台传值:prod_code', _prod_code)
        print('前台传值:prod_mode', _prod_mode)
        print('前台传值:jianguan_muji_fs', _jianguan_muji_fs)
        print('前台传值:fx_b_date', _fx_b_date)

        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)

        _sql_prod_info_query = SQL_PRODUCT_INFO_QUERY_NEW  # 产品信息查询sql
        _sql_count_query = SQL_PRODUCT_COUNT_QUERY_NEW  # 产品信息数量count
        _sql_condition = ""

        # 拼接[产品代码]参数条件
        if _prod_code == '%':
            _sql_condition = _sql_condition + ' and pd_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and pd_code=:pd_code_val'
        # 拼接[产品模式]参数条件
        if _prod_mode == '%':
            _sql_condition = _sql_condition + ' and (pd_mode_condition like \'%\' or pd_mode_condition is null) '
        else:
            _sql_condition = _sql_condition + ' and pd_mode_condition =:pd_mode_val'
        # 拼接[募集方式]参数条件
        if _jianguan_muji_fs == '%':
            _sql_condition = _sql_condition + ' and (jianguan_muji_fs_condition like \'%\' or jianguan_muji_fs_condition is null) '
        else:
            _sql_condition = _sql_condition + ' and jianguan_muji_fs_condition=:mjfs_val '

        # 拼接[发行成立日]参数条件
        if _fx_b_date == '%':
            _sql_condition = _sql_condition + ' and (pd_fx_b_date like \'%\' or pd_fx_b_date is null) '
        else:
            _sql_condition = _sql_condition + ' and pd_fx_b_date>=:fxrq_val '

        # 分页SQL语句-详细信息
        _sql_prod_info_query_all = """select * from (select * from (""" \
                                   + _sql_prod_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)

        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_count_query + _sql_condition

        print('----------------------------------------------查询语句[1]：' + _sql_prod_info_query_all)

        print('----------------------------------------------查询语句[2]：：' + _sql_count_query_all)

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_prod_info_query_all),
                                          {"pd_code_val": _prod_code, "pd_mode_val": _prod_mode,
                                           "mjfs_val": _jianguan_muji_fs, "fxrq_val": _fx_b_date})
            resulttotal = session.execute(text(_sql_count_query_all),
                                          {"pd_code_val": _prod_code, "pd_mode_val": _prod_mode,
                                           "mjfs_val": _jianguan_muji_fs, "fxrq_val": _fx_b_date})

        except Exception as e:
            print(e)
        else:
            _results_prod_info = resultproxy.fetchall()
            _results_total = resulttotal.fetchall()

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        resList = []
        # 将明细数压入List
        for _rpiq in _results_prod_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
            resList.append(rowDict_info)

        _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

        _result_json = json.dumps(_return_dict, cls=DecimalEncoder)

        print('----------------------------------------------最终查询返回的结果为：' + _result_json)

        return _result_json


# 动态获得select下拉框数据
@prod_manage.route("/get_sel_data", methods=['POST', 'GET'])
def get_sel_data():
    _dict_code = request.args.get(key='dict_code')

    if _dict_code == 'jianguan_tuoguan_jnei_mc':  # 托管行下拉框数据
        _sql_main = SQL_SEL_ESCROW_BANK_QUERY
        _sql_all = _sql_main
    else:
        _sql_main = SQL_SEL_DATA_QUERY
        _sql_condition = ' where a.dict_code=:val order by a.dict_code,a.item_key '
        _sql_all = _sql_main + _sql_condition

    try:
        session = DbUtil().get_session()
        resultproxy = session.execute(text(_sql_all), {"val": _dict_code})
    except Exception as e:
        print(e)
    else:
        _results = resultproxy.fetchall()

    resList = []
    for _result in _results:
        rowDict = dict(zip(_result.keys(), _result))
        resList.append(rowDict)

    _result_json = json.dumps(resList)

    print('--------------------返回数据：' + _result_json)

    return _result_json


# 删除产品信息
@prod_manage.route("/delete_product_info", methods=['POST', 'GET'])
def delete_product_info():
    if request.method == 'POST':

        _primary_key = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pk = _primary_key['primary_key']
        try:
            db.create_all()  # 创建数据库
            _obj = FAS_PROD_INFO.query.filter(FAS_PROD_INFO.pd_code == _pk).first()
            db.session.delete(_obj)
            db.session.commit()  # 提交到数据库 -->执行
            print('--------------------删除产品成功' + _pk)
            return "200"
        except:
            db.session.rollback()  # 回滚数据  -->执行
            print('--------------------删除产品失败' + _pk)
            return "300"


# 导出产品信息
@prod_manage.route("/export_product_info", methods=['POST', 'GET'])
def export_product_info():
    return ""


# 产品销售信息维护界面
@prod_manage.route("/prod_sale_info", methods=['POST', 'GET'])
def prod_sale_info():
    # 界面首次访问返回
    if request.method == 'GET':
        return render_template("prod_manage/prod_sale_info.html")

    # 界面初始化
    if request.method == 'POST':
        _json_ebcode = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _json_ebcode['pd_code']
        _pageSize = _json_ebcode['pageSize']  # 分页-数据
        _pageNumber = _json_ebcode['pageNumber']  # 分页-页面数
        _begin = (int(_pageNumber) - 1) * int(_pageSize)
        _over = _begin + int(_pageSize)
        _sql_product_sale_info_query = SQL_PRODUCT_SALE_INFO_QUERY  # 产品信息查询sql
        _sql_count_query = SQL_PRODUCT_SALE_INFO_COUNT_QUERY  # 产品信息数量count
        _sql_condition = ""

        # 拼接[产品代码]参数条件
        if _pd_code == '%':
            _sql_condition = _sql_condition + ' and t.pd_code like \'%\' '
        else:
            _sql_condition = _sql_condition + ' and t.pd_code=:pd_code '

        # 分页SQL语句-详细信息
        _sql_prod_info_query_all = """select * from (select * from (""" \
                                   + _sql_product_sale_info_query \
                                   + _sql_condition + """) where rowno > """ \
                                   + str(_begin) + """) where rowno <=""" \
                                   + str(_over)
        # 分页SQL语句-查询总数
        _sql_count_query_all = _sql_count_query + _sql_condition

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_sql_prod_info_query_all), {"pd_code": _pd_code})
            resulttotal = session.execute(text(_sql_count_query_all), {"pd_code": _pd_code})

        except Exception as e:
            print(e)

        _results_prod_info = resultproxy.fetchall()
        _results_total = resulttotal.fetchall()

        # 总结果数
        for _rt in _results_total:
            _return_dict = dict(
                zip(_rt.keys(), _rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        resList = []
        # 将明细数压入List
        for _rpiq in _results_prod_info:
            rowDict_info = dict(zip(_rpiq.keys(), _rpiq))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....}
            resList.append(rowDict_info)

        _return_dict["rows"] = resList  # 将返回的数据整合成datagrid的分页格式：{total:value,rows:[{key,value,key,value,.....}]}

        _result_json = json.dumps(_return_dict, cls=DecimalEncoder)

        print('----------------------------------------------最终查询返回的结果为：' + _result_json)

        return _result_json


# 产品销售信息保存
@prod_manage.route("/save_product_sale_info", methods=['POST', 'GET'])
def save_product_sale_info():
    if request.method == 'POST':
        _post_json_data = json.loads(request.get_data(as_text=True))  # 载入json对象
        _pd_code = _post_json_data['pd_code']
        _pd_colect_money = _post_json_data['pd_colect_money']
        _pd_person_a = _post_json_data['pd_person_a']
        _pd_person_b = _post_json_data['pd_person_b']
        _pd_person_c = _post_json_data['pd_person_c']
        _pd_copr_a = _post_json_data['pd_copr_a']
        _pd_copr_b = _post_json_data['pd_copr_b']
        _pd_copr_c = _post_json_data['pd_copr_c']
        _pd_done_flag = _post_json_data['pd_done_flag']

        items = _post_json_data.items()
        for key, value in items:
            print('---------------------------前台传递过来的参数：' + str(key) + '=' + str(value))
        _existflag = FAS_PROD_SALE_INFO.query.filter_by(pd_code=_pd_code).first()
        if (_existflag == None):
            fas_prod_sale_info = FAS_PROD_SALE_INFO(_pd_code, _pd_colect_money, _pd_person_a, _pd_person_b,
                                                    _pd_person_c, _pd_copr_a, _pd_copr_b, _pd_copr_c, _pd_done_flag)
            db.session.add(fas_prod_sale_info)  # 插入对象
            # 处理异常
            try:
                db.session.commit()  # 提交到数据库 -->执行
                return "200"
            except Exception as e:
                db.session.rollback()  # 回滚数据  -->执行
                print(e)
                return "300"
        else:
            FAS_PROD_SALE_INFO.query.filter(FAS_PROD_SALE_INFO.pd_code == _pd_code).update(
                {"pd_colect_money": _pd_colect_money,
                 "pd_person_a": _pd_person_a,
                 "pd_person_b": _pd_person_b,
                 "pd_person_c": _pd_person_c,
                 "pd_copr_a": _pd_copr_a,
                 "pd_copr_b": _pd_copr_b,
                 "pd_copr_c": _pd_copr_c,
                 "pd_done_flag": _pd_done_flag})

            # 处理异常
            try:
                db.session.commit()  # 提交到数据库 -->执行
                return "400"
            except Exception as e:
                db.session.rollback()  # 回滚数据  -->执行
                print(e)
                return "500"



# 修改产品信息
def modify_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type, _pd_risk_level,
                        _pd_profit_type,
                        _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date, _pd_fx_b_date,
                        _pd_sy_b_date,
                        _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date, _pd_life_statu, _pd_verify_person,
                        _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name, _investmanage_zj,
                        _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx, _lc_fw_type,
                        _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode, _prod_zengxin_flag,
                        _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu, _sale_channel_dif,
                        _touzi_zhonglei_bili,
                        _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                        _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                        _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima, _jianguan_tuoguan_jnei_mc,
                        _jianguan_tuoguan_jwai_gb,
                        _jianguan_tuoguan_jwai_mc,
                        _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr, _pd_xjmanagertype,
                        _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                        _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate):
    # 创建数据库
    db.create_all()

    FAS_PROD_INFO.query.filter(FAS_PROD_INFO.pd_code == _pd_code).update(
        {"pd_name": _pd_name,
         "pd_mode": _pd_mode,
         "pd_zz_code": _pd_zz_code,
         "pd_type": _pd_type,
         "pd_colect_type": _pd_colect_type,
         "pd_risk_level": _pd_risk_level,
         "pd_profit_type": _pd_profit_type,
         "pd_adjust_type": _pd_adjust_type,
         "pd_interest_base": _pd_interest_base,
         "pd_rg_bg_date": _pd_rg_bg_date,
         "pd_rg_ov_date": _pd_rg_ov_date,
         "pd_fx_b_date": _pd_fx_b_date,
         "pd_sy_b_date": _pd_sy_b_date,
         "pd_open_b_date": _pd_open_b_date,
         "pd_open_o_date": _pd_open_o_date,
         "pd_ov_date": _pd_ov_date,
         "pd_df_date": _pd_df_date,
         "pd_life_statu": _pd_life_statu,
         "pd_verify_person": _pd_verify_person,
         "pd_verify_certi": _pd_verify_certi,
         "pd_desiner_name": _pd_desiner_name,
         "pd_desiner_certi": _pd_desiner_certi,
         "investmanage_name": _investmanage_name,
         "investmanage_zj": _investmanage_zj,
         "ywry_name": _ywry_name,
         "ywry_zj_phone": _ywry_zj_phone,
         "ywry_yd_phone": _ywry_yd_phone,
         "ywry_mail": _ywry_mail,
         "zj_tx": _zj_tx,
         "lc_fw_type": _lc_fw_type,
         "prod_manager_mode": _prod_manager_mode,
         "invest_pz_type": _invest_pz_type,
         "dj_fs": _dj_fs,
         "tz_zc_type": _tz_zc_type,
         "hezuo_mode": _hezuo_mode,
         "prod_zengxin_flag": _prod_zengxin_flag,
         "prod_zengxin_comp": _prod_zengxin_comp,
         "prod_zengxin_xingshi": _prod_zengxin_xingshi,
         "prod_pingpai": _prod_pingpai,
         "prod_qishu": _prod_qishu,
         "sale_channel_dif": _sale_channel_dif,
         "touzi_zhonglei_bili": _touzi_zhonglei_bili,
         "jianguan_guanli_fs": _jianguan_guanli_fs,
         "jianguan_muji_fs": _jianguan_muji_fs,
         "jianguan_kuaijihesuan_fs": _jianguan_kuaijihesuan_fs,
         "jianguan_shouyi_bz": _jianguan_shouyi_bz,
         "jianguan_benjinbz_bz": _jianguan_benjinbz_bz,
         "jianguan_tiqianzhongzhi_bz": _jianguan_tiqianzhongzhi_bz,
         "jianguan_shuhui_bz": _jianguan_shuhui_bz,
         "jianguan_tuoguan_jwai_daima": _jianguan_tuoguan_jwai_daima,
         "jianguan_tuoguan_jnei_mc": _jianguan_tuoguan_jnei_mc,
         "jianguan_tuoguan_jwai_gb": _jianguan_tuoguan_jwai_gb,
         "jianguan_tuoguan_jwai_mc": _jianguan_tuoguan_jwai_mc,
         "pd_cpqx": _pd_cpqx,
         "pd_tongyezs": _pd_tongyezs,
         "pd_setholdtime": _pd_setholdtime,
         "pd_holddate": _pd_holddate,
         "pd_tzshouy_dzr": _pd_tzshouy_dzr,
         "pd_xjmanagertype": _pd_xjmanagertype,
         "pd_beginsalemoney": _pd_beginsalemoney,
         "pd_salerate": _pd_salerate,
         "pd_tuoguangrate": _pd_tuoguangrate,
         "pd_plancolectmoney": _pd_plancolectmoney,
         "pd_investmanagerate": _pd_investmanagerate,
         "pd_tzbenjin_dzr": _pd_tzbenjin_dzr,
         "pd_freeback": _pd_freeback,
         "pd_base_rate": _pd_base_rate
         })

    # 处理异常
    try:
        db.session.commit()  # 提交到数据库 -->执行
        return "产品更新成功!"
    except Exception as e:
        db.session.rollback()  # 回滚数据  -->执行
        print(e)
        return "产品更新失败!"


# 复制产品信息
def copy_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type, _pd_risk_level,
                      _pd_profit_type,
                      _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date, _pd_fx_b_date, _pd_sy_b_date,
                      _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date, _pd_life_statu, _pd_verify_person,
                      _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name, _investmanage_zj,
                      _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx, _lc_fw_type,
                      _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode, _prod_zengxin_flag,
                      _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu, _sale_channel_dif,
                      _touzi_zhonglei_bili,
                      _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                      _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                      _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima, _jianguan_tuoguan_jnei_mc,
                      _jianguan_tuoguan_jwai_gb,
                      _jianguan_tuoguan_jwai_mc,
                      _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr, _pd_xjmanagertype,
                      _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                      _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate):

    # 定义模型对象
    fas_prod_info = FAS_PROD_INFO(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type, _pd_risk_level,
                                  _pd_profit_type,
                                  _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date, _pd_fx_b_date,
                                  _pd_sy_b_date,
                                  _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date, _pd_life_statu,
                                  _pd_verify_person,
                                  _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name,
                                  _investmanage_zj,
                                  _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx, _lc_fw_type,
                                  _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode,
                                  _prod_zengxin_flag,
                                  _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu,
                                  _sale_channel_dif, _touzi_zhonglei_bili,
                                  _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                                  _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                                  _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima, _jianguan_tuoguan_jnei_mc,
                                  _jianguan_tuoguan_jwai_gb,
                                  _jianguan_tuoguan_jwai_mc,
                                  _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr,
                                  _pd_xjmanagertype,
                                  _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                                  _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate)

    # 创建数据库
    db.create_all()

    # 插入对象
    db.session.add(fas_prod_info)
    # 处理异常
    try:
        db.session.commit()  # 提交到数据库 -->执行
        return "产品复制成功!"
    except Exception as e:
        db.session.rollback()  # 回滚数据  -->执行
        print(e)
        return "产品复制失败!"


# 新增产品信息
def new_product_info(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type, _pd_risk_level,
                     _pd_profit_type,
                     _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date, _pd_fx_b_date, _pd_sy_b_date,
                     _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date, _pd_life_statu, _pd_verify_person,
                     _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name, _investmanage_zj,
                     _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx, _lc_fw_type,
                     _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode, _prod_zengxin_flag,
                     _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu, _sale_channel_dif,
                     _touzi_zhonglei_bili,
                     _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                     _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                     _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima, _jianguan_tuoguan_jnei_mc,
                     _jianguan_tuoguan_jwai_gb,
                     _jianguan_tuoguan_jwai_mc,
                     _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr, _pd_xjmanagertype,
                     _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                     _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate):

    # 定义模型对象
    fas_prod_info = FAS_PROD_INFO(_pd_code, _pd_name, _pd_mode, _pd_zz_code, _pd_type, _pd_colect_type, _pd_risk_level,
                                  _pd_profit_type,
                                  _pd_adjust_type, _pd_interest_base, _pd_rg_bg_date, _pd_rg_ov_date, _pd_fx_b_date,
                                  _pd_sy_b_date,
                                  _pd_open_b_date, _pd_open_o_date, _pd_ov_date, _pd_df_date, _pd_life_statu,
                                  _pd_verify_person,
                                  _pd_verify_certi, _pd_desiner_name, _pd_desiner_certi, _investmanage_name,
                                  _investmanage_zj,
                                  _ywry_name, _ywry_zj_phone, _ywry_yd_phone, _ywry_mail, _zj_tx, _lc_fw_type,
                                  _prod_manager_mode, _invest_pz_type, _dj_fs, _tz_zc_type, _hezuo_mode,
                                  _prod_zengxin_flag,
                                  _prod_zengxin_comp, _prod_zengxin_xingshi, _prod_pingpai, _prod_qishu,
                                  _sale_channel_dif, _touzi_zhonglei_bili,
                                  _jianguan_guanli_fs, _jianguan_muji_fs, _jianguan_kuaijihesuan_fs,
                                  _jianguan_shouyi_bz, _jianguan_benjinbz_bz, _jianguan_tiqianzhongzhi_bz,
                                  _jianguan_shuhui_bz, _jianguan_tuoguan_jwai_daima, _jianguan_tuoguan_jnei_mc,
                                  _jianguan_tuoguan_jwai_gb,
                                  _jianguan_tuoguan_jwai_mc,
                                  _pd_cpqx, _pd_tongyezs, _pd_setholdtime, _pd_holddate, _pd_tzshouy_dzr,
                                  _pd_xjmanagertype,
                                  _pd_beginsalemoney, _pd_salerate, _pd_tuoguangrate, _pd_plancolectmoney,
                                  _pd_investmanagerate, _pd_tzbenjin_dzr, _pd_freeback, _pd_base_rate)

    # 创建数据库
    db.create_all()

    # 插入对象
    db.session.add(fas_prod_info)
    # 处理异常
    try:
        db.session.commit()  # 提交到数据库 -->执行
        return "产品新增成功!"
    except Exception as e:
        db.session.rollback()  # 回滚数据  -->执行
        print(e)
        return "产品新增失败!"


'''
废弃代码


# 更新产品信息 - 获得产品信息界面
@prod_manage.route("/prod_update_info", methods=['POST', 'GET'])
def prod_update_info():
    if request.method == 'GET':
        _pk = request.args.get("primary_key")
        _prod_details_sql = SQL_PRODUCT_DETAILS_QUERY + ' and pd_code=:pd_code_val '
        #print('--------------------------------[!!!!!更新!!!!!!!产品详细信息]查询语句为:' + _prod_details_sql)

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_prod_details_sql), {"pd_code_val": _pk})

        except Exception as e:
            print(e)
        else:
            _results_details_info = resultproxy.fetchall() #获取所有的数据，返回类型  RowProxy 数组（即列表），列表示例：[RowProxy-obj1,RowProxy-obj2,RowProxy-obj3,RowProxy-obj4.....]

        #开始迭代RowProxy数组，读取每一行RowProxy进行按字段加工。注：RowProxy.key() 提供所有 column_name 的数组，如：[colname1,colname2,colname3,.....]
        for _rt in _results_details_info:
            _return_dict = dict(zip(_rt.keys(),_rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        # dumps函数是将dict数据转化为str数据,但是dict数据中若包含byte数据、Decimal数据、date数据，就会导致json.dumps()转换为JSON格式对象时报错：
        # TypeError: Object of type Decimal is not JSON serializable
        # 新建一个DecimalEncoder类来格式化
        _result_json = json.dumps(_return_dict,cls=DecimalEncoder)

        print('--------------------------------返回数据为:' + _result_json)

        return render_template("prod_manage/produpdate.html",_result_json = _result_json)


# 更新产品信息 - 提交更新
@prod_manage.route("/update_product_info", methods=['POST', 'GET'])
def update_product_info():

    if request.method == 'POST':

        _product_form = json.loads(request.get_data(as_text=True))# 载入json对象

        # 基本信息
        _pd_mode = _product_form['prod_mode']  # 产品模式:01-开放式,02-封闭式
        _pd_code = _product_form['prod_code']  # 产品代码
        _pd_zz_code = _product_form['zz_code']  # 中债编码
        _pd_name = _product_form['prod_name']  # 产品名称
        _pd_type = _product_form['prod_type']  # 产品类型
        _pd_colect_type = _product_form['collect_bz']  # 募集币种
        _pd_risk_level = _product_form['fx_dj']  # 风险等级
        _pd_profit_type = _product_form['sy_td']  # 收益特点
        _pd_adjust_type = _product_form['hs_fs']  # 核算方式
        _pd_interest_base = _product_form['jx_js']  # 计息基数
        _pd_life_statu = _product_form['prod_life_statu']  # 产品状态
        # 时间信息
        _pd_rg_bg_date = _product_form['rg_b_date']  # 认购开始日期
        _pd_rg_ov_date = _product_form['rg_o_date']  # 认购结束日期
        _pd_fx_b_date = _product_form['fx_b_date']  # 发行成立日期
        _pd_sy_b_date = _product_form['sy_b_date']  # 收益起始日期
        _pd_open_b_date = _product_form['open_b_date']  # 开放起始日期
        _pd_open_o_date = _product_form['open_o_date']  # 开放结束日期
        _pd_ov_date = _product_form['prod_o_date']  # 产品清盘日期
        _pd_df_date = _product_form['prod_df_date']  # 产品兑付日期

        # 中债登信息
        _pd_verify_person = _product_form['pd_verify_person']  # 审批人姓名
        _pd_verify_certi = _product_form['pd_verify_certi']  # 审批人证件
        _pd_desiner_name = _product_form['pd_desiner_name']  # 设计人姓名
        _pd_desiner_certi = _product_form['pd_desiner_certi']  # 设计人证件

        _investmanage_name = _product_form['investmanage_name']
        _investmanage_zj = _product_form['investmanage_zj']
        _ywry_name = _product_form['ywry_name']
        _ywry_zj_phone = _product_form['ywry_zj_phone']
        _ywry_yd_phone = _product_form['ywry_yd_phone']
        _ywry_mail = _product_form['ywry_mail']
        _zj_tx = _product_form['zj_tx']
        _lc_fw_type = _product_form['lc_fw_type']
        _prod_manager_mode = _product_form['prod_manager_mode']
        _invest_pz_type = _product_form['invest_pz_type']
        _dj_fs = _product_form['dj_fs']
        _tz_zc_type = _product_form['tz_zc_type']
        _hezuo_mode = _product_form['hezuo_mode']
        _prod_zengxin_flag = _product_form['prod_zengxin_flag']
        _prod_zengxin_comp = _product_form['prod_zengxin_comp']
        _prod_zengxin_xingshi = _product_form['prod_zengxin_xingshi']
        _prod_pingpai = _product_form['prod_pingpai']
        _prod_qishu = _product_form['prod_qishu']
        _sale_channel_dif = _product_form['sale_channel_dif']
        _touzi_zhonglei_bili = _product_form['touzi_zhonglei_bili']

        # 监管数据信息
        _jianguan_guanli_fs = _product_form['jianguan_guanli_fs']
        _jianguan_muji_fs = _product_form['jianguan_muji_fs']
        _jianguan_kuaijihesuan_fs = _product_form['jianguan_kuaijihesuan_fs']
        _jianguan_shouyi_bz = _product_form['jianguan_shouyi_bz']
        _jianguan_benjinbz_bz = _product_form['jianguan_benjinbz_bz']
        _jianguan_tiqianzhongzhi_bz = _product_form['jianguan_tiqianzhongzhi_bz']
        _jianguan_shuhui_bz = _product_form['jianguan_shuhui_bz']
        _jianguan_tuoguan_jwai_daima = _product_form['jianguan_tuoguan_jwai_daima']
        _jianguan_tuoguan_jnei_mc = _product_form['jianguan_tuoguan_jnei_mc']
        _jianguan_tuoguan_jwai_gb = _product_form['jianguan_tuoguan_jwai_gb']
        _jianguan_tuoguan_jwai_mc = _product_form['jianguan_tuoguan_jwai_mc']

        # 2020-06-30新增13个字段
        _pd_cpqx = _product_form['pd_cpqx']
        _pd_tongyezs = _product_form['pd_tongyezs']
        _pd_setholdtime = _product_form['pd_setholdtime']
        _pd_holddate = _product_form['pd_holddate']
        _pd_tzshouy_dzr = _product_form['pd_tzshouy_dzr']
        _pd_xjmanagertype = _product_form['pd_xjmanagertype']
        _pd_beginsalemoney = _product_form['pd_beginsalemoney']
        _pd_salerate = _product_form['pd_salerate']
        _pd_tuoguangrate = _product_form['pd_tuoguangrate']
        _pd_plancolectmoney = _product_form['pd_plancolectmoney']
        _pd_investmanagerate = _product_form['pd_investmanagerate']
        _pd_tzbenjin_dzr = _product_form['pd_tzbenjin_dzr']
        _pd_freeback = _product_form['pd_freeback']

        # 2020-07-03新增1个字段
        _pd_base_rate = _product_form['pd_base_rate']


        items = _product_form.items()
        for key, value in items:
            print('---------------------------[更新]前台传递过来的参数：'+str(key) + '=' + str(value))

        # 创建数据库
        db.create_all()

        FAS_PROD_INFO.query.filter(FAS_PROD_INFO.pd_code == _pd_code).update(
            {"pd_name":_pd_name,
             "pd_mode":_pd_mode,
             "pd_zz_code": _pd_zz_code,
             "pd_type": _pd_type,
             "pd_colect_type": _pd_colect_type,
             "pd_risk_level": _pd_risk_level,
             "pd_profit_type": _pd_profit_type,
             "pd_adjust_type": _pd_adjust_type,
             "pd_interest_base": _pd_interest_base,
             "pd_rg_bg_date": _pd_rg_bg_date,
             "pd_rg_ov_date": _pd_rg_ov_date,
             "pd_fx_b_date": _pd_fx_b_date,
             "pd_sy_b_date": _pd_sy_b_date,
             "pd_open_b_date": _pd_open_b_date,
             "pd_open_o_date": _pd_open_o_date,
             "pd_ov_date": _pd_ov_date,
             "pd_df_date": _pd_df_date,
             "pd_life_statu": _pd_life_statu,
             "pd_verify_person": _pd_verify_person,
             "pd_verify_certi": _pd_verify_certi,
             "pd_desiner_name": _pd_desiner_name,
             "pd_desiner_certi": _pd_desiner_certi,
             "investmanage_name": _investmanage_name,
             "investmanage_zj": _investmanage_zj,
             "ywry_name": _ywry_name,
             "ywry_zj_phone": _ywry_zj_phone,
             "ywry_yd_phone": _ywry_yd_phone,
             "ywry_mail": _ywry_mail,
             "zj_tx": _zj_tx,
             "lc_fw_type": _lc_fw_type,
             "prod_manager_mode": _prod_manager_mode,
             "invest_pz_type": _invest_pz_type,
             "dj_fs": _dj_fs,
             "tz_zc_type": _tz_zc_type,
             "hezuo_mode": _hezuo_mode,
             "prod_zengxin_flag": _prod_zengxin_flag,
             "prod_zengxin_comp": _prod_zengxin_comp,
             "prod_zengxin_xingshi": _prod_zengxin_xingshi,
             "prod_pingpai": _prod_pingpai,
             "prod_qishu": _prod_qishu,
             "sale_channel_dif": _sale_channel_dif,
             "touzi_zhonglei_bili": _touzi_zhonglei_bili,
             "jianguan_guanli_fs": _jianguan_guanli_fs,
             "jianguan_muji_fs": _jianguan_muji_fs,
             "jianguan_kuaijihesuan_fs": _jianguan_kuaijihesuan_fs,
             "jianguan_shouyi_bz": _jianguan_shouyi_bz,
             "jianguan_benjinbz_bz": _jianguan_benjinbz_bz,
             "jianguan_tiqianzhongzhi_bz": _jianguan_tiqianzhongzhi_bz,
             "jianguan_shuhui_bz": _jianguan_shuhui_bz,
             "jianguan_tuoguan_jwai_daima": _jianguan_tuoguan_jwai_daima,
             "jianguan_tuoguan_jnei_mc": _jianguan_tuoguan_jnei_mc,
             "jianguan_tuoguan_jwai_gb": _jianguan_tuoguan_jwai_gb,
             "jianguan_tuoguan_jwai_mc": _jianguan_tuoguan_jwai_mc,
             "pd_cpqx": _pd_cpqx,
             "pd_tongyezs": _pd_tongyezs,
             "pd_setholdtime": _pd_setholdtime,
             "pd_holddate": _pd_holddate,
             "pd_tzshouy_dzr": _pd_tzshouy_dzr,
             "pd_xjmanagertype": _pd_xjmanagertype,
             "pd_beginsalemoney": _pd_beginsalemoney,
             "pd_salerate": _pd_salerate,
             "pd_tuoguangrate": _pd_tuoguangrate,
             "pd_plancolectmoney": _pd_plancolectmoney,
             "pd_investmanagerate": _pd_investmanagerate,
             "pd_tzbenjin_dzr": _pd_tzbenjin_dzr,
             "pd_freeback": _pd_freeback,
             "pd_base_rate":_pd_base_rate
             })

        # 处理异常
        try:
            db.session.commit()  # 提交到数据库 -->执行
            return "产品更新成功!"
        except Exception as e:
            db.session.rollback()  # 回滚数据  -->执行
            print(e)
            return "产品更新失败!"


#获取产品详细信息
@prod_manage.route("/prod_details_info", methods=['POST', 'GET'])
def prod_details_info():

    if request.method == 'GET':
        _pk = request.args.get("primary_key")
        _prod_details_sql = SQL_PRODUCT_DETAILS_QUERY + ' and pd_code=:pd_code_val '
        #print('--------------------------------[获取产品详细信息]查询语句为:' + _prod_details_sql)

        try:
            session = DbUtil().get_session()
            resultproxy = session.execute(text(_prod_details_sql), {"pd_code_val": _pk})

        except Exception as e:
            print(e)
        else:
            _results_details_info = resultproxy.fetchall()


        for _rt in _results_details_info:
            _return_dict = dict(zip(_rt.keys(),_rt))  # 将数据转换为dict字典对象 rowDict_info = {key:value,key:value,.....} -> {"total":value}

        # dumps函数是将dict数据转化为str数据,但是dict数据中若包含byte数据、Decimal数据、date数据等等，就会导致json.dumps()转换为JSON格式对象时报错：
        # TypeError: Object of type Decimal is not JSON serializable
        # 新建一个DecimalEncoder类来[Decimal]类型的数据格式化为str
        _result_json = json.dumps(_return_dict,cls=DecimalEncoder)

        print('--------------------------------返回数据为:' + _result_json)

        return render_template("prod_manage/proddetails.html",_result_json = _result_json)




'''
