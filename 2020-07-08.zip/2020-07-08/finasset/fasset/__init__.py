from flask import Flask
from config import db, SQLALCHEMY_DATABASE_URI, SQLALCHEMY_TRACK_MODIFICATIONS, templates_dir, static_dir

#db = SQLAlchemy()  # 初始化SQLAlchemy


def create_app():

    """ 创建app的方法 """
    app = Flask(__name__,static_folder=static_dir,template_folder=templates_dir)  # 生成Flask对象
    app.config['SQLALCHEMY_DATABASE_URI'] = SQLALCHEMY_DATABASE_URI  # 配置app的URI
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = SQLALCHEMY_TRACK_MODIFICATIONS
    app.jinja_env.auto_reload = True
    app.debug = True

    # SQLAlchemy初始化App
    db.init_app(app=app)

    print('------------------创建app-------------------------')

    # 返回Flask对象app
    return app
