



SQL_MYPAGE_AREA_ONE = """
                select substr(t.pd_fx_b_date, 0, 6) as mont, count(1) as cnt
                  from fas_prod_info t
                 group by substr(t.pd_fx_b_date, 0, 6)
                 order by substr(t.pd_fx_b_date, 0, 6)
                      """