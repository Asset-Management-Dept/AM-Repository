import os
from flask_sqlalchemy import SQLAlchemy

# 基础路径
BASE_DIR = os.getcwd() #os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 页面模板
templates_dir = os.path.join(BASE_DIR, 'templates')
# 静态模板
static_dir = os.path.join(BASE_DIR, 'static')

db = SQLAlchemy()


def get_db_uri(datebase):
    user = datebase.get('USER')
    password = datebase.get('PASSWORD')
    host = datebase.get('HOST')
    port = datebase.get('PORT')
    name = datebase.get('NAME')
    db = datebase.get('DB')
    #driver = datebase.get('DRIVER')

    return '{}://{}:{}@{}:{}/{}'.format(db, user, password, host, port, name)


# 用户-密码-地址-端口-数据库-驱动-数据表名称
DATABASE = {
    'USER': 'fasset',
    'PASSWORD': 'fasset',
    'HOST': '127.0.0.1',
    'PORT': '1521',
    'DB': 'oracle',
    'DRIVER': 'cx-oracle',
    'NAME': 'fassetdb'
}

SQLALCHEMY_DATABASE_URI = get_db_uri(DATABASE) #'oracle+cx-oracle://fasset:fasset@127.0.0.1:1521/fassetdb'  # 数据库URI

SQLALCHEMY_TRACK_MODIFICATIONS = False  # 查询跟踪，不太需要，False，不占用额外的内存

